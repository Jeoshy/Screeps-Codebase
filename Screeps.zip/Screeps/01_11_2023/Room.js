// Chunking
// ---------
const scale = 10 // {2, 5, 10}
const mapSize = 50
const chunkManager = function () {}
chunkManager.chunks = createGrid(mapSize / scale)
let chunks = chunkManager.chunks

function createGrid (gridSize) {
    let grid = []
    for (let i = 0; i < gridSize**2 ; i++) {
        grid.push({})
    }
    grid.getIndex = (x ,y) => Math.floor(x / scale) + Math.floor(y / scale) * gridSize
    grid.get = (x ,y) => grid[grid.getIndex(x, y)]
    return grid
}

chunks.forEach((value, index) =>
{
    if (index % 2 === 0)
    {
        value.color = "red"
    }
    else
    {
        value.color = "blue"
    }

    return value
})

let room = Game.rooms["sim"]
for (let x = 0; x < 50; x++)
{
    for (let y = 0; y < 50; y++)
    {
        let color = chunks.get(x, y).color
        room.visual.circle(x, y, {fill: color})
    }
}
