Object.defineProperty(Spawn.prototype, "heapMemory", {
    get: function () {
        if (_.isUndefined(global.heapMemory.spawns)) {
            global.heapMemory.spawns = {}
        }
        if (!_.isObject(global.heapMemory.spawns)) {
            return undefined
        }

        return global.heapMemory.spawns[this.id] = global.heapMemory.spawns[this.id] || {}
    },
    set: function(value) {
        if (_.isUndefined(global.heapMemory.spawns)) {
            global.heapMemory.spawns = {}
        }
        if (!_.isObject(global.heapMemory.spawns)) {
            throw new Error('Could not set room heapMemory');
        }

        global.heapMemory.spawns[this.id] = value
    },
    configurable:true,
})

