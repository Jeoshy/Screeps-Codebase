require("spawn")
require("Room")

global.heapMemory = []


