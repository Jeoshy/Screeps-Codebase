const C = require("creeps");
const Actions = require("pt_processManager");
const Checks = require("pt_checks")

let print = function (_) {
    console.log(_)
}

module.exports.loop = function () {
    let harvester = Game.creeps["Mia"]
    let carrier = Game.creeps["Keira"]
    let builder = Game.creeps["Bob"]

    if (harvester && harvester.memory && !harvester.memory.process) {
        harvester.memory.process = C.HARVESTER.MOVE
        harvester.memory.tracker = []
        harvester.memory.temp = {
            loc: "20x20"
        }
    }

    if (carrier && carrier.memory && !carrier.memory.process) {
        carrier.memory.process = C.CARRIER.DEFAULT
        carrier.memory.tracker = []
    }

    if (builder && builder.memory && !builder.memory.process) {
        builder.memory.process = C.WORKER.BUILDER
        builder.memory.tracker = []
        builder.memory.temp = {
            loc: "25x25"
        }
    }

    if (harvester) {
        Actions.run(harvester)
    }
    if (carrier) {
        Actions.run(carrier)
    }
    if (builder) {
        Actions.run(builder)
    }
}