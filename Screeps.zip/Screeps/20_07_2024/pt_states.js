/**
 * Purpose: changes the process of the object
 * Additionally, adds or removes memory
 */

const CREEP = require("creeps")

module.exports = {
    [STATE.PULL](object) {
        object.memory.process = CREEP.CARRIER.PULL
        return OK
    },
    [STATE.TRANSPORT](object) {
        object.memory.process = CREEP.CARRIER.TRANSPORT
        return OK
    },
    [STATE.CARRIER](object) {
        object.memory.process = CREEP.CARRIER.DEFAULT
        return OK
    },
    [STATE.HARVEST](object) {
        object.memory.process = CREEP.HARVESTER.HARVEST
        return OK
    },
    [STATE.BUILDER](object) {
        object.memory.process = CREEP.WORKER.BUILDER
        return OK
    },
    [STATE.UPGRADER](object) {
        object.memory.process = CREEP.WORKER.UPGRADER
        return OK
    },
    [STATE.WORKER](object) {
        object.memory.process = CREEP.WORKER.DEFAULT
        return OK
    }
}