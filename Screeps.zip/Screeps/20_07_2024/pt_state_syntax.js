global.STATE = {
    HARVEST: "state_harvest",
    BUILDER: "state_builder",
    UPGRADER: "state_upgrader",
    WORKER: "worker",
    CARRIER: "state_carrier",
    TRANSPORT: "state_transport",
    ARRIVED: "state_arrived",
    PULL: "state_pull",
}

global.CHECK = {
    WAIT: "wait",
    EMPTY: "empty",
    LOCKED: "locked",
    SWITCH: "switch",
    RE_ENGAGE: "re-engage",
    ARRIVED: "arrived",
    PULL: "pull",
    BUILD: "build",
    UPGRADE: "upgrade",
    PULLED: "pulled",
    EXTRACTABLE: "extractable",
    EXTRACT: "extract",
    DEFAULT: "default",
    NONE: "none",
    DONE: "done",
    PERMISSION: "permission"
}

global.ACTION = {
    PULL: "move_by_pull",
    HARVEST: "harvest",
    EMPTY: "empty",
    ENERGY: "energy",
    BUILD: "build",
    MOVE: "move"
}

global.REQUEST = ACTION

global.INPUT = {}
global.OUTPUT = {}

for (let action in ACTION) {
    INPUT[action] = "i_" + ACTION[action]
    OUTPUT[action] = "o_" + ACTION[action]
}
