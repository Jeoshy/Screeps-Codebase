/**
 * Purpose: what does the object perform
 * Input: object
 * Output: functionality
 */

module.exports = {
    [ACTION.EMPTY](object) {
    },
    [ACTION.MOVE](creep) {
        const job = creep.memory.temp

        // TODO: Make it generic for locations and objects
        const target = Game.getObjectById(job.id)

        creep.moveTo(target)
    },
    [ACTION.PULL](creep) {
        const job = creep.memory.temp
        const target = Game.getObjectById(job.id)
        const [x, y] = job.loc.split("x")
        const loc = creep.room.getPositionAt(x, y)

        creep.moveTo(loc)
        creep.pull(target)
        target.move(creep)
    },
    [ACTION.HARVEST](creep) {
        console.log("add functionality to ACTION.HARVEST")
    },
    [ACTION.BUILD](creep) {
        /**
         * INTENT:
         * Simple building
         */

        const job = creep.memory.temp
        const construction = Game.getObjectById(job.id)

        creep.build(construction)
    },
    [INPUT.PULL](creep) {
        const info = function (creep) {
            return {
                id: creep.id,
                loc: creep.memory.temp.loc
            }
        }
        post(creep, REQUEST.PULL, info)

        creep.memory.process[0] = ACTION.EMPTY
    },
    [INPUT.ENERGY](creep) {
        const info = function (creep) {
            return {
                id: creep.id,
                resource: RESOURCE_ENERGY,
            }
        }

        // TODO: Post requests to get filled based on: (capacity creep) / (capacity transporters)

        post(creep, REQUEST.ENERGY, info)
        creep.memory.process[0] = ACTION.EMPTY
    },


}