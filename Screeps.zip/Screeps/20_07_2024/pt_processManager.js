const C = require("creeps")
require("pt_state_syntax")
if (!Memory.requests) {
    Memory.requests = {}
}
const requests = Memory.requests
const CHECKS = require("pt_checks")
const ACTIONS = require("pt_actions")
const STATES = require("pt_states")

global.post = function (creep, name, info) {
    if (requests[name] === undefined) {
        requests[name] = []
    }

    requests[name].push(info(creep))
}

global.request = function (creep, name) {
    if (requests[name] === undefined || requests[name].length === 0) { return -1}

    let jobs = requests[name]

    creep.memory.temp = jobs.pop()

    return OK
}

global.next_step = function (object) {
    let state = object.memory.process
    state.shift()
    state.shift()
    object.memory.process = state
}

global.create = function (object, name, info) {
    // Creates two list for each specified name
    // The first list is to note id of creep
    // The second list is to store info for each job
    // The lists are linked by index
    // TODO: program

    return false
}

global.fill_in = function (object, name) {
    // Loop over list of jobs in the specified name
    // A spot is available if spot is empty or assigned creep is dead
    // No spot awarded, return false
    // Spot awarded, note spot with id, assign info, break loop, return OK
    // TODO: program

    return false
}

module.exports = {
    run (object) {
        const action = object.memory.process[0]
        const check = object.memory.process[1]
        const last_action = object.memory.last_action

        /**
         * Special case
         * If action is a state, run state and change process.
         */
        if (STATES[action] && STATES[action](object) === OK) {
            object.memory.tracker.push(action)
            this.run(object)
            return
        }

        /**
         * Runs current action in the process at front
         */
        if (ACTIONS[action]){
            ACTIONS[action](object)
        }

        /**
         * Checks whether it is a SUM OPERATOR
         * SUM OPERATOR are implied by a list of checks in the process
         */
        let check_i = "none"
        if (typeof check === "object") {
            for (let index in check) {
                let check_i = check[index]

                if (CHECKS[check_i](object)) {
                    object.memory.tracker.push(check_i)

                    if (typeof object.memory.process[2][index] === "string") {
                        object.memory.process = [object.memory.process[2][index]]
                        this.run(object)
                        break;
                    }

                    object.memory.process = object.memory.process[2][index]
                    this.run(object)
                    break;
                }
            }
            return;
        }

        /**
         * Each action comes with its associated check.
         * This signals the action finished
         */
        if (CHECKS[check] && CHECKS[check](object)) {
            object.memory.tracker.push(check)
            next_step(object)
            if (check !== CHECK.PERMISSION) {this.run(object)}
        }

    },
}