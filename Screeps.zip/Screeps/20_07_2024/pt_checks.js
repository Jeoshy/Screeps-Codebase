/**
 * Purpose: signal that the action is finished or checks whether synchronization is possible.
 * Additionally, it can add or remove memory and
 * - determine by position - signal which path to take.
 *
 * Input: object
 * Output: true or false
 */

module.exports = {

    /**
     * Section of checks that forward processes
     */

    [CHECK.NONE]() {
        /**
         * INTENT:
         * Signal that the check is exhausted
         * Exhausted checks only need to occur ones
         */
        return false
    },
    [CHECK.WAIT](creep) {
        /**
         * INTENT:
         * Waiting on synchronization.
         * An ACTION needs to forward this creep
         */
        return false
    },
    [CHECK.EMPTY](creep) {
        /**
         * INTENT:
         * Creep does not have (all) the specified resources anymore
         * These specified resources can be found in the job
         */

        const job = creep.memory.temp

        if (job.resource) {
            return creep.store[job.resource] === 0
        }

        if (job.resources) {
            let emptiness = true

            for (let resource of job.resources) {
                if (creep.store[resource] > 0) {
                    emptiness = false
                }
            }

            return emptiness
        }

    },
    [CHECK.LOCKED](creep) {
        /**
         * INTENT:
         * Check whether the creep can start pulling the target
         */

        const job = creep.memory.temp
        const target = Game.getObjectById(job.id)
        const index = creep.pull(target)
        creep.cancelOrder("pull")

        return index === OK
    },
    [CHECK.PERMISSION](creep) {
        return true
    },
    [CHECK.SWITCH](creep) {
        /**
         * INTENT:
         * Specific for pulling creeps.
         * Puts the target on their destination
         */

        const job = creep.memory.temp
        const target = Game.getObjectById(job.id)

        if (creep.moveTo(target) === OK && creep.pull(target) === OK && target.move(creep) === OK){
            target.memory.process[1] = CHECK.PERMISSION
            return true
        }

        return false
    },

    /**
     * Section of checks that synchronize with other processes
     */

    [CHECK.DEFAULT](creep) {
        /**
         * INTENT:
         * When all other paths in a process are needed
         * Default to this path
         */
        return true
    },
    [CHECK.DONE](creep) {
        const job = creep.memory.temp
        return Game.getObjectById(job.id) === undefined
    },
    [CHECK.ARRIVED](creep) {
        /**
         * INTENT:
         * Has the creep arrived to the specified location in the job
         */

        const job = creep.memory.temp
        const [x, y] = job.loc.split("x")
        const loc = creep.room.getPositionAt(x, y)

        return creep.pos.x === loc.x && creep.pos.y === loc.y
    },
    [CHECK.PULLED](creep) {
        /**
         * INTENT:
         * Counterpart of CHECK.ARRIVED.
         * Don't take this path if the creep is on its destination
         */

        return this[CHECK.ARRIVED](creep) === false
    },
    [CHECK.RE_ENGAGE](creep) {
        /**
         * INTENT:
         * The counterpart of CHECK.LOCKED
         *
         */

        const job = creep.memory.temp
        const target = Game.getObjectById(job.id)
        const index = creep.pull(target)
        // creep.cancelOrder("pull")

        return index === ERR_NOT_IN_RANGE
    },
    [CHECK.BUILD](creep) {
        return request(creep, REQUEST.BUILD) === OK
    },
    [CHECK.UPGRADE](creep) {
        return fill_in(creep, REQUEST.UPGRADE) === OK
    },
    [CHECK.PULL](creep) {
        return request(creep, REQUEST.PULL) === OK
    },
    [CHECK.EXTRACTABLE](creep) {

    }
}
