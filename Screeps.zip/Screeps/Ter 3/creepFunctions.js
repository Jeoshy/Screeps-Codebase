var reverse = {
    1: BOTTOM,
    2: BOTTOM_LEFT,
    3: LEFT,
    4: TOP_LEFT,
    5: TOP,
    6: TOP_RIGHT,
    7: RIGHT,
    8: BOTTOM_RIGHT
}

module.exports = {
    pull: function(task){
        const {setup, check, path, creepID} = task

        if (setup != true){
            const {index} = moveInTargetRange.call(this, creepID, 1)
            if (index == ERR_INVALID_TARGET){
                task.done = true
                return true
            }
            if (index == OK){
                task.setup = true
            }
        } else {
            const target = Game.getObjectById(creepID)
            if (!this.pos.inRangeTo(target, 1)){
                task.setup = false
                return false
            }

            const index = moveInPosRange.call(this, check, 0)
            if (index == OK){
                if (this.move(reverse[path[path.length-1].direction]) == OK){
                    this.pull(target)
                    target.move(this)
                    task.done = true
                    return true
                }
            } else {
                this.pull(target)
                target.move(this)
            }
        }
    },

    harvest: function(task){
        this.harvest(Game.getObjectById(task.source))
    },

    upgrade: function(task){
        const {uPos, cPos, containerID, droppedID, full} = task

        const index = moveInPosRange.call(this, uPos, 0)

        if (index == OK){
            if (full){
                const controller = Game.rooms[this.memory.born].controller
                
                if (this.store.energy == 0){
                    task.full = false
                    return false
                }

                this.upgradeController(controller)

            } else {
                if (containerID == undefined){
                    const {x, y, roomName} = cPos
                    const roomPosition = Game.rooms[roomName].getPositionAt(x, y)
                    const container = roomPosition.lookFor(LOOK_STRUCTURES).find((structure) => {
                        return structure.structureType == STRUCTURE_CONTAINER
                    })
    
                    if (container != undefined){
                        task.containerID = container.id
                        return false
                    }
                    
                    const dropped = Game.getObjectById(droppedID)
                    if (dropped == undefined){
                        const dropped = roomPosition.lookFor(LOOK_ENERGY)[0]
                        if (dropped != undefined){
                            task.droppedID = dropped.id
                        }
                        return false
                    }
                    if (this.pickup(dropped) == OK){
                        task.full = true
                    }
    
                } else {
    
                }
            }
        }
    },

    energy: function(task){
        const {full, nothingToFill, idToFill, type} = task

        if (full){
            if (this.store.energy == 0){
                task.full = false
            }

            if (idToFill == undefined && !nothingToFill){
                const room = this.memory.born
                const used = this.store.energy
                const cavities = Memory.rooms.claimed[room].capacity
                if (cavities.length != 0){
                    const id = cavities[0]
                    const object = Game.getObjectById(id)
                    if (object.store.getFreeCapacity(RESOURCE_ENERGY) < used){
                        Memory.rooms.claimed[room].capacity.shift()
                    }
                    task.idToFill = object.id
                } else {
                    task.nothingToFill = true
                }
            } else if(!nothingToFill){
                const {index, target} = moveInTargetRange.call(this, idToFill, 1)
                if(index == ERR_INVALID_TARGET){
                    task.idToFill = undefined
                    return false
                }

                if (target.store.getFreeCapacity(RESOURCE_ENERGY) == 0){
                    task.nothingToFill = true
                    return false
                }

                let index2 = this.transfer(target, RESOURCE_ENERGY)
                if(index == OK && index2 == OK){
                    task.full = false
                }
            } else {
                //TO DO: NEED MORE ELEGANT SOLUTION FOR CLOGS UP AT UPGRADER PIT

                const {x, y} = Memory.rooms.claimed[this.memory.born].centralUpgraderPosition
                // const roomPosition = Game.rooms[this.memory.born].getPositionAt(x, y)
                if(moveInPosRange.call(this, {x, y}, 0) == OK){
                    this.drop(RESOURCE_ENERGY)
                    task.nothingToFill = false
                    task.full = false
                }
                //  else {
                //     if (roomPosition.lookAtArea(y - 1, x - 1, y + 1, x + 1, true).some(({type}) => {
                //         return type == "creep"
                //     })) {
                //         moveInTargetRange.call(this, this.room.controller.id, 1)
                //     }
                // }
            }
        } else {
            const index = Game.cF[type].call(this, task)
            if (index == true){
                return true
            }
        }
    },

    dropped: function(task){
        const {droppedID} = task
        const {index, target} = moveInTargetRange.call(this, droppedID, 1)
        if (index == ERR_INVALID_TARGET){
            task.done = true
            return true
        }
        const index2 = this.pickup(target)
        if (index == OK && index2 == OK){
            task.full = true
        }

        return index
    }
}

const moveInTargetRange =  function(id, range){
    let target = Game.getObjectById(id)
    if (target == null){
        return {index: ERR_INVALID_TARGET}
    }

    var task = this.memory.task
    if (task.path == undefined || task.previousID != id || Game.time % 100 == 0){
        task.path = this.pos.findPathTo(target)
    }
    task.previousID = id

    if (!(this.pos.getRangeTo(target) <= range)){
        this.moveByPath(task.path)
        return {index: ERR_NOT_IN_RANGE, target: target}
    }

    return {index: OK, target: target}
}

const moveInPosRange =  function({x, y}, range){
    var task = this.memory.task
    if ((task.path == undefined || task.previousID != 0) || Game.time % 100 == 0){
        task.path = this.pos.findPathTo(x, y)
    }
    task.previousID = 0

    if (!(this.pos.getRangeTo(x, y) <= range)){
        this.moveByPath(task.path)
        return ERR_NOT_IN_RANGE
    }

    return OK
}