module.exports = {
    creepCheck: function(c){
        if(c.memory.task == undefined){
            Game.tM.getTask(c)
            return
        }
        
        if(Game.cF[c.memory.task.core].call(c, c.memory.task)){
            Game.dM.defaultTask(c.memory)
            return
        }
        
        if(c.memory.initialized != true && c.memory.task){
            c.memory.initialized = true
            Game.cI[c.memory.role](c)
        }

    },

    harvester: function(c){
        Game.tM.addToTaskList(
            c.memory.born,
            "carrier",
            {core: "pull", creepID: c.id, check: c.memory.task.hPos},
            "unshift"
            )
    },
    
    carrier: function(c){
    },

    upgrader: function(c){
    },

    explorer: function(c){
    },
}