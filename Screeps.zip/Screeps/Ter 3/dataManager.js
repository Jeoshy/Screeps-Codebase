

module.exports = {
    update: function(){
        checkFlags()
    },

    getBody: function(creepType, roomName){
        let room = Game.rooms[roomName]
        let body = []
        let basicBody = Memory.creepBodies[creepType][room.controller.level]
        let cost = 0

        _.forEach(basicBody, function(bPart){
            cost += BODYPART_COST[bPart]
        })

        let count = Math.floor(room.energyAvailable / cost)
        while (count--){
            body.push(basicBody)
        }
        return [].concat(...body)
    },

    checkCavities: function(room){
        let list = Game.rooms[room].find(FIND_MY_STRUCTURES)

        _.forEach(list, function(s){
            let type = s.structureType
            if (type != STRUCTURE_CONTROLLER && s.store.getFreeCapacity(RESOURCE_ENERGY) > 0){
                if (type == STRUCTURE_SPAWN || type == STRUCTURE_EXTENSION){
                    Memory.rooms.claimed[room].capacity.unshift(s.id)
                } else {
                    Memory.rooms.claimed[room].capacity.push(s.id)
                }
            }
        })
    },

    deleteCreep: function(creepName){
        console.log("activated")
        let creepMemory = Memory.creeps[creepName]
        console.log(creepMemory)
        Memory.rooms.claimed[creepMemory.born].creepCounts[creepMemory.role] -= 1
        Game.dM.defaultTask(creepMemory)
        delete Memory.creeps[creepName]
    },

    defaultTask: function(creepMemory){
        //Find task in roomMemory
        if (creepMemory.task != undefined){
            var taskRoom = Game.dM.findTask(creepMemory)
            if (creepMemory.task.done){
                delete creepMemory.task
                return
            }
        }

        //Done is a way to avoid looping tasks
        delete creepMemory.task

        for (let key in taskRoom){
            let elem = taskRoom[key]
            if (typeof elem == "boolean"){
                taskRoom[key] = false
            }

            if (typeof elem == "string" && key.search("id") != -1){
                taskRoom[key] = undefined
            }
        }
    },

    findTask: function(creepMemory){
        let roomName = creepMemory.born
        let role = creepMemory.role
        let taskID = creepMemory.task.taskID
        let taskList = Memory.rooms.claimed[roomName].taskLists[role]
        return taskList.find((task) => taskID === task.taskID)
        
        // for (let index in taskList){
        //     let task = taskList[index]
        //     if (taskCreep.taskID == task.taskID){
        //         return task
        //     }
        // }
    }
}

var checkFlags = function(){
    _.forEach(Game.flags, function(f){
        f.remove()
        switch (f.color){
            case COLOR_WHITE:
                //Makes memory aka start flag
                //RawMemory.set("{}");
                Memory.creeps = {}
                Memory.spawns = {}
                Memory.rooms = {enemies: [], claim: [], claimed: {}}
                Memory.flags = {}
                Memory.creepBodies = {}
                f.pos.createFlag("", COLOR_GREEN)
                initializeBody()
                break;
            case COLOR_RED:
                //Adds room to enemy list
                Memory.rooms.enemies.push(f.room.name)
                break;
            case COLOR_ORANGE:
                //Adds room to claim list
                Memory.rooms.claim.push(f.room.name)
                break;
            case COLOR_GREEN:
                //Removes from claim list
                //Adds to claimed list
                InitializeClaimedRoom(f);
                break;
        }
    })
}

function initializeBody(){
    //TO DO: MOVE THIS PLACE TO CONSTANTS
    //TO DO: MAKE IT SO THAT SPAWNING CAN CHOOSE FROM MULTIPLE OPTIONS ACCORDING TO ENERGY AVAILIABLE

    console.log("--------------------")
    _.forEach(Game.creepTypes, function(t){
        Memory.creepBodies[t] = {}
    })

    for (let i = 1; i <= 8; i++){
        Memory.creepBodies['harvester'][i] = [WORK, WORK]
        Memory.creepBodies["carrier"][i] = [CARRY, MOVE]
    }

    let i = 0
    Memory.creepBodies["upgrader"][i++] = [WORK, WORK, CARRY, MOVE]
    Memory.creepBodies["upgrader"][i++] = [WORK, WORK, CARRY, MOVE]
    Memory.creepBodies["upgrader"][i++] = []
    Memory.creepBodies["upgrader"][i++] = []
    Memory.creepBodies["upgrader"][i++] = []
    Memory.creepBodies["upgrader"][i++] = []
    Memory.creepBodies["upgrader"][i++] = []
    Memory.creepBodies["upgrader"][i++] = []
}

function InitializeClaimedRoom(f) {
    console.log("New room has been claimed");
    delete Memory.rooms.claim[f.room.name];
    delete Memory.rooms.claimed[f.room.name];
    const roomMemory = Memory.rooms.claimed[f.room.name] = {}
    roomMemory.name =  f.room.name;

    //Initialize resources in room
    roomMemory.dropped = []
    roomMemory.capacity = []
    roomMemory.spawnList = []

    roomMemory.spawns = f.room.find(FIND_MY_SPAWNS).map((spawn) => {
        return spawn.id
    })

    roomMemory.sources = {}
    _.forEach(f.room.find(FIND_SOURCES), function (s) {
        const x = s.pos.x;
        const y = s.pos.y;
        const positions = [];
        _.forEach(f.room.lookAtArea(y - 1, x - 1, y + 1, x + 1, true), function (t) {
            if (t.type == "terrain" && (t.terrain == "swamp" || t.terrain == "plain")) {
                positions.push(f.room.getPositionAt(t.x, t.y));
            }
        });
        if (positions.length > 3){
            positions.length = 3
        }
        roomMemory.sources[s.id] = positions
    });

    roomMemory.centralUpgraderPosition = {}
    const controller = f.room.controller
    if (true){
        const {x, y} = controller.pos
        const goodPositions = f.room.lookAtArea(y - 2, x - 2, y + 2, x + 2, true).filter(({type, terrain}) =>{
            return type == "terrain" && (terrain == "swamp" || terrain == "plain")
        })

        const excellentPosition = goodPositions.find(({x, y}) => {
            return f.room.lookAtArea(y - 1, x - 1, y + 1, x + 1, true).every((pos) => {
                return pos.type == "terrain" && (pos.terrain == "swamp" || pos.terrain == "plain")
            })
        })

        roomMemory.centralUpgraderPosition = excellentPosition
    }

    if(true){
        const {x, y} = roomMemory.centralUpgraderPosition
        let positions = f.room.lookAtArea(y - 1, x - 1, y + 1, x + 1, true).filter((pos) => {
            return !(x == pos.x && y == pos.y)
        })

        const ranges = positions.map((pos) => {
            return controller.pos.getRangeTo(pos)
        })

        const indexFarthest = positions.indexOf(Math.max(...ranges))
        positions.splice(indexFarthest, 1)
        roomMemory.centralUpgraderPosition.positions = positions
    }


    roomMemory.creepCounts = {}
    _.forEach(Game.creepTypes, function(type){
        roomMemory.creepCounts[type] = 0
    })

    //Adds creepLimits and taskList depending on controller level
    Game.iTL.general(f.room.name)
}