Game.dM = require("dataManager")
Game.tM = require("taskManager")
Game.cI = require("creepInitialization")
Game.cF = require("creepFunctions")
Game.iTL = require("initializeTaskList")

console.log(Game.time)

for(let name in Memory.creeps){
    let creep = Game.creeps[name]  
    if(creep == undefined){
        Game.dM.deleteCreep(name)
        break;
    }
    
    if(!creep.spawning){
        Game.cI.creepCheck(creep)
    }
}

Game.dM.update()
Game.tM.update()
