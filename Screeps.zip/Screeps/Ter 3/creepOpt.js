module.exports = {
    general: function(role){
        let opt = {memory: {role: role}, priority: "push"}
        if (this[role] != undefined){
            this[role](opt)
        }
        return opt
    },

    harvester: function(opt){
        opt.priority = "unshift"
    },

    carrier: function(opt){
        opt.priority = "unshift"
    },
}