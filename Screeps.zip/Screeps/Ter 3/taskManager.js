var getOpt = require("creepOpt")

module.exports = {
    update: function(){
        this.checkTasks()
        this.checkSpawning()
        this.checkDropped()
    },

    checkTasks: function(){
        _.forEach(Memory.rooms.claimed, function(roomMemory){
            let creepLimits = roomMemory.creepLimits
            let creepCounts = roomMemory.creepCounts
    
            _.forEach(Game.creepTypes, function(type){
                if (creepCounts[type] < creepLimits[type]){
                    let tasks = roomMemory.taskLists[type]
                    _.forEach(tasks, function(task){
                        if(!task.occupied && !task.done && !task.spawned){
                            task.spawned = true
                            Game.tM.addToSpawnList(roomMemory.name, getOpt.general(type))
                        }
                    })
                }
            })        
        })
    },

    checkSpawning: function(){
        _.forEach(Memory.rooms.claimed, function(roomMemory){
            if (roomMemory.spawnList.length != 0){
                const creep = roomMemory.spawnList[0]
                for (var i in roomMemory.spawns){
                    const s = Game.getObjectById(roomMemory.spawns[i])
                    if (s.spawning == null){
                        const role = creep.opt.memory.role
                        const body = Game.dM.getBody(role, creep.room)
                        creep.opt.memory.born = creep.room
                        if (s.spawnCreep(body, role + Game.time, creep.opt) == 0){
                            roomMemory.spawnList.shift()
                            Game.dM.checkCavities(creep.room)
                            break;
                        } else {
                            console.log("TaskManager - Checkspawning: Something wrong with spawning\n body:", body, "\n creep:", creep.room, role)
                        }
                    }
                }
            }
        })
    },

    addToTaskList: function(room, whichCreepType, task, priority){
        let taskList = Memory.rooms.claimed[room].taskLists[whichCreepType]
        this.addTask(task, taskList.length)
        taskList[priority](task)
    },

    addTask: function(task, length){
        task.occupied = false
        task.done = false
        task.spawned = false
        task.taskID = Game.time + length
        return task
    },

    addToSpawnList: function(roomName, opt){
        let roomMemory = Memory.rooms.claimed[roomName]
        roomMemory.creepCounts[opt.memory.role] += 1
        roomMemory.spawnList[opt.priority]({room: roomName, opt: opt})
    },

    getTask: function(creep){
        let room = creep.memory.born
        let role = creep.memory.role
        let tasks = Memory.rooms.claimed[room].taskLists[role]

        for (let index in tasks){
            let task = tasks[index]

            if(!task.occupied && !task.done){
                task.occupied = true
                creep.memory.task = task
                break;
            }
        }
    },

    checkDropped: function(){
        
        for (let roomName in Memory.rooms.claimed){
            let room = Game.rooms[roomName]
            let {dropped: droppedMemory, sources} = Memory.rooms.claimed[roomName]
            let dropped = room.find(FIND_DROPPED_RESOURCES)

            if (dropped.length == 0){
                dropped.length = 0
                continue;
            }
            
            const sourceIDs = Object.keys(sources)
            sourceIDs.forEach((sourceID) => {
                const source = Game.getObjectById(sourceID)
                const droppedNearby = source.pos.findInRange(FIND_DROPPED_RESOURCES, 1)
                droppedNearby.forEach((resource) => {
                    if (!droppedMemory.includes(resource.id)){
                        Game.tM.addToTaskList(
                            roomName,
                            "carrier",
                            {core: "energy", type: "dropped", droppedID: resource.id, full: false},
                            "unshift"
                        )
                        Memory.rooms.claimed[roomName].dropped.push(resource.id)
                    }
                })
            })
        }
    }
}