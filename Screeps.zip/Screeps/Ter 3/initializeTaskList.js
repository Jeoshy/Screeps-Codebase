Game.creepTypes = ["harvester", "carrier", "upgrader", "explorer"]  

module.exports = {
    general: function(roomName){
        const level = Game.rooms[roomName].controller.level
        const roomMemory = Memory.rooms.claimed[roomName]
        let taskList = newTaskList()
        let creepLimits = newCreepLimits()
        Game.iTL[level](roomMemory, taskList, creepLimits, roomName)
    },

    1: function(roomMemory, taskList, creepLimits, roomName){
        const {x, y, positions: centralPositions} = roomMemory.centralUpgraderPosition
        const centralRoomPosition = Game.rooms[roomName].getPositionAt(x, y)
        creepLimits["explorer"] = 1
        
        for (const sourceID in roomMemory.sources){
            const sourcePositions = roomMemory.sources[sourceID]
            _.forEach(sourcePositions, function(pos){

                //creepLimits["harvester"] is to make a unique index needed for a task
                taskList["harvester"].push(Game.tM.addTask({
                    core: "harvest",
                    source: sourceID,
                    hPos: pos
                }, creepLimits["harvester"]))

                //Adds an upgrader task
                taskList["upgrader"].push(Game.tM.addTask({
                    core: "upgrade",
                    cPos: centralRoomPosition,
                    uPos: centralPositions[creepLimits["upgrader"]]
                }, creepLimits["upgrader"]))

                creepLimits["harvester"] += 1
                creepLimits["carrier"] += 1
                creepLimits["upgrader"] += 1
            })
        }

        fininalizeMemory(roomMemory, taskList, creepLimits)
    },

    2: function(roomMemory, taskList, creepLimits){
        Game.iTL[1](roomMemory, taskList, creepLimits)
    },

    3: function(roomMemory, taskList, creepLimits){
        fininalizeMemory(roomMemory, taskList, creepLimits)
    },

    4: function(roomMemory, taskList, creepLimits){
        fininalizeMemory(roomMemory, taskList, creepLimits)
    },

    5: function(roomMemory, taskList, creepLimits){
        fininalizeMemory(roomMemory, taskList, creepLimits)
    },

    6: function(roomMemory, taskList, creepLimits){
        fininalizeMemory(roomMemory, taskList, creepLimits)
    },

    7: function(roomMemory, taskList, creepLimits){
        fininalizeMemory(roomMemory, taskList, creepLimits)
    },

    8: function(roomMemory, taskList, creepLimits){
        fininalizeMemory(roomMemory, taskList, creepLimits)
    }
}

var fininalizeMemory = function(roomMemory, taskList, creepLimits){
    roomMemory.taskLists = taskList
    roomMemory.creepLimits = creepLimits
}

var newCreepLimits = function(){
    let creepLimits = {}
    _.forEach(Game.creepTypes, function(type){
        creepLimits[type] = 0
    })
    return creepLimits
}

var newTaskList = function(){
    let taskList = {}
    _.forEach(Game.creepTypes, function(type){
        taskList[type] = []
    })
    return taskList
}