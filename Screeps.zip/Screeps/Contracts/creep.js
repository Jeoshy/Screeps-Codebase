let getContract = require("Contract")
const {creepROLES} = require("./constants");

function AbstractCreep () {
    /* Common found in creep
    /* BaseBody
    /* Role
    /* Memory
    /* Default task - run
     */

    if (!this.baseBody && !global.debugMODE) {
        throw new error ("BaseBody has not been decided")
    }
    if (!this.role && !global.debugMODE) {
        throw new error ("Role has not been decided")
    }

    this.initialBody = []
    this.memory = {}
    this.additionalMemory = function () {}
    this.maxBodySegmentCount = {
        1: 99
    }

    this.createBody = function (room) {
        let initialCost = this.calculateBodySegmentCost(this.initialBody)
        let capacity = room.energyCapacityAvailable - initialCost
        let limitBodySegment = this.calculateBodySegmentCount(capacity, this.baseBody)
        let energy = room.energyAvailable - initialCost
        let currentBodySegments = this.calculateBodySegmentCount(energy, this.baseBody)
        let maxBodySegment = this.getBodySegmentCount(room.controller.level)
        let N = limitBodySegment > maxBodySegment ? maxBodySegment : limitBodySegment
        N = this.bodyHeuristic(N, {limit: limitBodySegment, current: currentBodySegments, max: maxBodySegment, room: room})
        let body = this.initialBody
        _.times(N, () => {body = body.concat(this.baseBody)})

        // Naïve approach of sorting
        body.sort((a, b) => BODYPART_COST[a] - BODYPART_COST[b])

        return body
    }

    this.calculateBodySegmentCount = function (energy, body) {
        let bodyCost = this.calculateBodySegmentCost(body)

        return Math.floor(energy / bodyCost)
    }

    this.calculateBodySegmentCost = function (body) {
        return body.reduce((acc, b) => acc + BODYPART_COST[b], 0)
    }

    this.getBodySegmentCount = function (roomLevel) {
        let count = 0
        for (let index in this.maxBodySegmentCount) {
            if (index <= roomLevel) {
                count = this.maxBodySegmentCount[index]
                continue
            }
            return count
        }
    }

    this.bodyHeuristic = function (N, params) {
        return N
    }

    this.createMemory = function (room, creepName) {
        this.memory.role = this.role
        this.memory.roomName = room.name
        this.additionalMemory.call(this, room, creepName)

        return this.memory
    }
}
function Harvester () {
    this.baseBody = [WORK]
    this.role = creepROLES.HARVESTER
    AbstractCreep.apply(this, arguments)

    this.maxBodySegmentCount[1] = 2
    this.maxBodySegmentCount[2] = 5
    this.maxBodySegmentCount[3] = 6

    this.additionalMemory = function (room, creepName) {
        this.memory.harvestSpot = room.freeHarvestSpot(creepName)
    }
}
function Carrier () {
    this.baseBody = [MOVE, CARRY]
    this.role = creepROLES.CARRIER
    AbstractCreep.apply(this, arguments)

    this.bodyHeuristic = function (N, params) {
        let creepCount = params.room.find(FIND_MY_CREEPS)
        if (creepCount < 3) {
            N = 1
        }
        return N
    }

    this.additionalMemory = function (room, creepName) {
        this.memory.harvestSpot = room.freeTask(creepName, this.role)
    }
}
function Upgrader () {
    this.baseBody = [WORK, CARRY]
    this.role = creepROLES.UPGRADER
    AbstractCreep.apply(this, arguments)

    this.additionalMemory = function (room, creepName) {
        this.memory.harvestSpot = room.freeUpgradeSpot(creepName)
    }
}

module.exports = {
    spawnToken: function (creepRole) {
        if (!Memory.creepCounts) {
            Memory.creepCounts = {}
        }
        if (!Memory.creepCounts[creepRole]) {
            Memory.creepCounts[creepRole] = 0
        }

        Memory.creepCounts[creepRole] += 1
        return [creepRole, `${creepRole}${Memory.creepCounts[creepRole]}`]
    },
    createCreep: function (creepRole) {
        switch(creepRole) {
            case (creepROLES.HARVESTER):
                return new Harvester()
            case (creepROLES.UPGRADER):
                return new Upgrader()
            case (creepROLES.CARRIER):
                return new Carrier()
        }
    },
    dead: function (creepMemory) {
        let name = creepMemory.name
        let role = creepMemory.role
        let room = Game.rooms[creepMemory.roomName]

        console.log(`${name} died`)

        if (!room) {
            return OK
        }

        room.freeCreepPosition(role)

        delete Memory.creeps[name]

        return OK
    }
}

Creep.prototype.done = function () {
    console.log(`${this.name} finished its task`)

    this.room.removeTask(this.memory.task.id)

    this.memory.task = undefined
}

// Object.defineProperty(Creep.prototype, "role", {
//     get: function () {
//         if (!this.memory.role) {
//             this.memory.role = undefined
//         }
//
//         return this.memory.role
//     },
//     set: function (role) {
//         this.memory.role = role
//     },
//     enumerable: false,
//     configurable: true
// })

// module.exports = {
//     [creepROLES.HARVESTER]: require("harvester"),
//     [creepROLES.CARRIER]: require("carrier"),
//     [creepROLES.UPGRADER]: require("upgrader"),
//     dead: function (creepMemory) {
//         let name = creepMemory.name
//         let role = creepMemory.role
//         let room = Game.rooms[creepMemory.roomName]
//
//         console.log(`${name} died`)
//
//         if (!room) {
//             return OK
//         }
//
//         room.freeCreepPosition(role)
//
//         delete Memory.creeps[name]
//
//         return OK
//     }
// }
