const {registerTypes} = require("./constants");

Room.prototype.energyInRegister = function (collection, registerType) {
    return abstractRegistry.call(this, [registerType, registerTypes.ENERGY_IN], collection)
}

Room.prototype.energyOutRegister = function (collection, registerType) {
    return abstractRegistry.call(this, [registerType, registerTypes.ENERGY_OUT], collection)
}

Room.prototype.constructionRegister = function (collection) {
    return abstractRegistry.call(this, registerTypes.CONSTRUCTION, collection)
}

Room.prototype.harvestRegister = function (collection) {
    abstractRegistry.call(this, registerTypes.HARVESTSPOTS, collection)
}

Room.prototype.upgradeRegister = function (collection) {
    abstractRegistry.call(this, registerTypes.UPGRADER, collection)
}

function abstractRegistry (elemClass, collection) {
    let register = function (elem) {
        let id = ""
        if (elem instanceof RoomPosition) {
            id = global.serializePosition(elem)
        }
        else {
            id = elem.id
        }


        this.register[id] = elemClass
    }

    collection.forEach((elem) => register.call(this, elem))
}

// function abstractProcess (collection, checkFunc, getId = function (elem) {return elem.id}) {
//     if (!(collection instanceof Array)) {
//         collection = [collection]
//     }
//
//     for (let elem of collection) {
//         let id = getId(elem)
//
//         if (!Game.getObjectById(id)) {
//             delete collection[id]
//             continue;
//         }
//
//         if (checkFunc.call(this, id) === OK) {
//             collection[id] = true
//         }
//     }
// }
