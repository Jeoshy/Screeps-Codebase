module.exports = {
    roomTypes: {
        LONGDISTANCEHARVESTING: "longdistanceharvesting",

    },
    taskTYPES: {
        DEFAULT: "default",
        PULL: "pull",
        BUILD: "build",
    },
    creepROLES: {
        HARVESTER: "harvester",
        CARRIER: "carrier",
        UPGRADER: "upgrader",
    },
    creepMETHODS: {
        WITHDRAW: "withdraw",
        TRANSFER: "transfer"

    },
    direction: {
        IN: 0,
        OUT: 1
    },
    registerTypes: {
        CONSTRUCTION: "construction",
        ENERGY_IN: "energyIn",
        ENERGY_OUT: "energyOut",
        HARVESTSPOTS: "harvestspots",
        UPGRADESPOTS: "upgradespots"
    },
    DEBUG: true,
    NORMAL: false
}