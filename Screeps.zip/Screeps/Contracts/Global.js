global.heapMemory = {}

global.cpuCost = function () {
    let cpuCost = Game.cpu.getUsed() - global.cost
    global.cost = Game.cpu.getUsed()
    return cpuCost
}

let layer1 = "/"
let layer2 = "."
global.parsePosition = function (string) {
    let [x, y, roomName] = string.split(layer2)
    return Game.rooms[roomName].getPositionAt(parseInt(x), parseInt(y))
}

global.serializePosition = function () {
    if (arguments.length === 1) {
        let roomPosition = arguments[0]
        return `${roomPosition.x}${layer2}${roomPosition.y}${layer2}${roomPosition.roomName}`
    }
    let [x, y, roomName] = arguments
    return `${x}${layer2}${y}${layer2}${roomName}`
}

global.decompressPositions = function (string) {
    return string.split(layer1).map((s) => global.parsePosition(s))
}

global.compressPositions = function (positions, roomName) {
    let string = ""
    positions.forEach((pos) => {
        let x = pos.x
        let y = pos.y
        string += `${global.serializePosition(x, y, roomName)}${layer1}`
    })
    // Remove last s with slice
    return string.slice(0, -1)
}

if (!Memory.i) {
    Memory.i = 0
}

global.debugLog = function (string) {
    global.debugMode ? console.log(string) : false
}