let role = require("creep")
let register = require("Register")
require("Room")
require("Source")
require("Global")

let {NORMAL, DEBUG} = require("constants")
const {creepROLES} = require("./constants");

global.debugMode = DEBUG

module.exports.loop = function () {
    global.cost = 0
    console.log(Game.time)
    console.log("The requires have used:", global.cpuCost())
    Memory
    console.log("The memory parse has used:", global.cpuCost())

    for (let roomName in Game.rooms) {
        let room = Game.rooms[roomName]

        if (Game.time % 100 === 0 || room.checkLevel() || true) {
            room.harvestSpots
            room.checkToBuild()
            room.creeps
        }

        global.debugLog(` Every 100 tick logic used: ${global.cpuCost()}`)

        // TODO: Visual script that makes tasks and visualizes on map

        // TODO: Make better spawn script with heuristics when to spawn


        // TODO: Make the spawn work with heapmemory - by updating .spawning on right time
        if (room.spawns[0].spawning === null && room.queue[0]) {
            let [creepRole, creepName] = room.getCreep()
            let creep = role.createCreep(creepRole)
            let body = creep.createBody(room)
            let index = room.spawns[0].spawnCreep(body, creepName, {dryRun: true})

            if (index === 0) {
                let memory = creep.createMemory(room, creepName)
                let index = room.spawns[0].spawnCreep(body, creepName, {memory: memory})
                room.removeLastCreep()
            }
        }
        global.debugLog(` Spawn logic used: ${global.cpuCost()}`)

        console.log(`${roomName} has used ${global.cpuCost()} CPU time`);
    }

// for (let creepName in Memory.creeps) {
//     let creep = Game.creeps[creepName]
//
//     if (!creep) {
//         if (role.dead(Memory.creeps[creepName]) === OK) {
//             delete Memory.creeps[creepName]
//         }
//         continue;
//     }
//
//     if (!creep.id){
//         continue;
//     }
//
//     const startCpu = Game.cpu.getUsed();
//     // TODO: Make the task assign for every creep but only every 100 ticks
//
//
//     role[creep.memory.role].run(creep)
//
//     // TODO: Have every task have a debug
//     global.debugMODE ? role[creep.memory.role].debug(creep) : false
//     const elapsed = Game.cpu.getUsed() - startCpu;
//     console.log(`${creepName} has used ${elapsed} CPU time`);
// }

    console.log(`Totalling ${Game.cpu.getUsed()}`)
}
