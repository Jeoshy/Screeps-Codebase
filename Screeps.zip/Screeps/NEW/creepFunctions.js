var creepMemory = require("creepMemory")
var creepAction = require("creepAction")

module.exports = {
    //ms1mc2ashact
    order(orderString, creep, roomBoolean){
        var orderIndex = [];
        var stage = creep.memory.stage
        var skipNow;
        var breakNow;
        var letter;
        var number;
        var addToStage = 0;
        var skipCollumn = false;
        var highestNumber = 0
        for(var index in orderString){
            skipNow = false;
            breakNow = false;
            letter = orderString[index]
            for(var i = 0; i < 9; i++){
                if(letter == i){
                    var number = letter
                    highestNumber = number
                    if(number < stage){
                        skipCollumn = true
                    }
                    else if(number == stage){
                        skipNow = true;
                        skipCollumn = false
                    }
                    else{
                        skipCollumn = false
                        breakNow = true;
                    }
                    break;
                }
            }

            if(skipCollumn == true){
                continue;
            }
            else if(skipNow == true){
                continue;
            }
            else if(breakNow == true){
                break;
            }
            //console.log(letter + creep)
            switch(letter){
                case "m":
                    addToStage = creepMemory.memoryUpdate(orderString[parseFloat(index) +1], creep)
                    break;
                case "a":
                    addToStage = creepAction.actionUpdate(orderString[parseFloat(index) +1], orderString[parseFloat(index) +2], creep)
            }
            if(addToStage != 0){
                break;
            }
        }
        if(roomBoolean == true){
            addToStage = 0
        }
        creep.memory.stage += parseFloat(addToStage)
    },
    moveToTarget(creep, objectID){
        if(creep.memory.currentMoveTo != objectID){
            creep.memory.currentMoveTo = objectID
            creep.memory.path = creep.room.findPath(creep.pos, Game.getObjectById(objectID).pos)
        }
        creep.moveByPath(creep.memory.path)
    }
};