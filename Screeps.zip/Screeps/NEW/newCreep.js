var functionTree = require("creepFunctions")

module.exports = {
    creepChoose(creep, identifier){
        var orderString = "";
        var indexCreep = creep.name[0]
        switch(identifier){
            case "harvester":
                orderString = "0ms1mc2amc3ahs"
                functionTree.order(orderString, creep, false)
                break;
            case "builder":
                orderString = "0mc1awc2apr3abC"
                functionTree.order(orderString, creep, false)
                if(creep.memory.constructionSite == undefined){
                    orderString = "0mc1awc2apr3auh"
                    functionTree.order(orderString, creep, false)
                }
                break;
            case "carrier":
                orderString = "0mc1awc2apr3atn"
                functionTree.order(orderString, creep, false)
                break;
            case "upgrader":
                orderString = "0mc1awc2apr3amh4auh"
                functionTree.order(orderString, creep, false)
                break;
            case "repairer":
                creep.memory.toRepair = undefined
                orderString = "0mc1awc2apr3arR"
                functionTree.order(orderString, creep, false)
                /*if(creep.memory.toRepair == undefined){
                    creep.memory.identifier = "builder"
                    Memory.creepsList[creep.memory.nameRoom][creep.name].identifier = "builder"
                    creep.memory.lastIdentifier = "repairer"
                    creep.memory.stage = 0
                }*/
                
                /*if(creep.memory.toRepair == undefined){
                    orderString = "0mc1awc2apr3abC"
                    functionTree.order(orderString, creep, false)
                }*/
                break;
            case "distributer":
                //creep.memory.stage = 0
                orderString = "0mf1amp2aLf3mc4awc5atd"
                functionTree.order(orderString, creep, false)
                break;
                break;
        }
    }
};