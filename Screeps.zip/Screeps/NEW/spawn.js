var creep = require("data")

module.exports = {
    spawnFunction(nameCreep, roomMemory, identifier){
        var bodyArray = creep.bodyFunction(identifier)
        var maxEnergy = creep.maxEnergy(identifier)
        var energyCost = 0;
        var bodyFinal = [];
        for(var body of bodyArray){
            switch(body){
                case TOUGH:
                    energyCost += 10;
                    break;
                case MOVE:
                    energyCost += 50;
                    break;
                case CARRY:
                    energyCost += 50;
                    break;
                case WORK:
                    energyCost += 100;
                    break;
                case ATTACK:
                    energyCost += 80;
                    break;
                case RANGED_ATTACK:
                    energyCost += 150;
                    break;
                case HEAL:
                    energyCost += 250;
                    break;
                case CLAIM:
                    energyCost += 600;
                    break;
            }
        }
        
        for(var spawnCreep of roomMemory.spawnList){
            var creepName = spawnCreep.nameCreep
            if(nameCreep == creepName){
                return;
            }
        }
        
        roomMemory.spawnList.push({nameCreep: nameCreep, maxEnergy: maxEnergy, bodyArray: bodyArray, energyCost: energyCost, identifier})
    },
    
    spawningFunction(spawnList0, room, id){
        var energy = room.energyAvailable;
        var nameRoom = room.name
        var bodyFinal = [];
        var nameCreep = spawnList0.nameCreep
        var nameCreepM = nameCreep.substring(1)
        var identifier = spawnList0.identifier
        if(energy < spawnList0.energyCost){
            return false;
        }
        
        if(energy > spawnList0.maxEnergy){
            energy = spawnList0.maxEnergy
        }
        
        var numberParts = Math.floor(energy/spawnList0.energyCost)
        for(var bodyPart of spawnList0.bodyArray){
            for(var i = 0; i < numberParts; i++){
                bodyFinal.push(bodyPart);
            }
        }
        
        if(identifier == 'distributer'){
            bodyFinal.splice(0,1)
            bodyFinal.push(MOVE)
        }
        
        var index = Game.getObjectById(id).spawnCreep(bodyFinal, nameCreep, {memory: {nameRoom: nameRoom, name: nameCreepM, stage: 0, identifier: identifier}}/*, directions: direction*/)
        if(index == 0){
            var creep = Memory.creepsList[nameRoom][nameCreep]
            if(creep != undefined){
                creep.alive = "true"
            }
            return true;
        }
        else if(index == -3){
            return true;
        }
        else {
            return false;
        }
    }
};