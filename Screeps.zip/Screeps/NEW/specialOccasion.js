module.exports = {
    moveCreep(x, y, nameRoom){
        var room = Game.rooms[nameRoom]
        var moveCreep = room.lookForAt(LOOK_CREEPS, x,y)
        var creep = Game.creeps[moveCreep[0].name]
        creep.move(TOP)
    }
};