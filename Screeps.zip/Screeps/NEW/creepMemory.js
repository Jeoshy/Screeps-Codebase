module.exports = {
    memoryUpdate(letter, creep){
        var creepIndex = creep.name[0]
        var roomMemory = Memory.rooms[creep.memory.nameRoom]
        switch(letter){
            case "s":
                creep.memory.source = roomMemory.sources[creepIndex];
                return 1;
            case "c":
                if(creep.memory.identifier == "distributer"){
                    var room = Game.rooms[creep.memory.nameRoom]
                    var pos = room.getPositionAt(creep.memory.creepPos.x, creep.memory.creepPos.y)
                    var array = pos.findInRange(FIND_STRUCTURES, 1, {
                        filter: function(object){
                            return object.structureType == STRUCTURE_CONTAINER || object.structureType == STRUCTURE_STORAGE
                        }
                    })
                    if(array[0] == undefined){
                        return 2;
                    }
                    creep.memory.container = array[0].id
                    return 1;
                }
                if(creep.memory.identifier == "upgrader" || creep.memory.identifier == "builder"){
                    creep.memory.container = roomMemory.containers[0]
                    if(creep.memory.container == undefined){
                        return 2;
                    }
                    return 1;
                }
                if(creep.memory.identifier == "repairer"){
                    creep.memory.container = Memory.flags[creep.memory.nameRoom]["0" + creep.memory.nameRoom].container
                    if(creep.memory.container == undefined){
                        return 2;
                    }
                    return 1;
                }
                creep.memory.container = roomMemory.containers[parseFloat(creepIndex) +1];
                if(creep.memory.container == undefined){
                    switch(creep.memory.identifier){
                        case "carrier":
                            return 2;
                            break;
                    }
                    creep.memory.container = roomMemory.containers[1];
                }
                return 1;
            case "p":
                creep.memory.pos = roomMemory.managerPos[creepIndex]
                return 1;
            case "f":
                var flagMemory = Memory.flags[creep.memory.nameRoom]
                var creepMemory = Memory.creepsList[creep.memory.nameRoom][creep.name]
                switch(creep.memory.identifier){
                    case "distributer":
                        creep.memory.creepPos = flagMemory.managerPos[creepIndex]
                        console.log(flagMemory[creepMemory.flagIndex + creep.memory.nameRoom])
                        creep.memory.container = flagMemory[creepMemory.flagIndex + creep.memory.nameRoom].container
                        break;
                }
                return 1;
        }
        return 0;
    }
};