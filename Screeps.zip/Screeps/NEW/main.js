var math = require("test")
var functionsG = require("functions")
var functionsR = require("room")
var functionsC = require("newCreep")
var spawnD = require("spawn")
var creepMemoryUpdate = require("creepMemory")
var special = require("specialOccasion")

for(var flag in Game.flags){
    switch(flag){
        case "RESTART":
            functionsG.restart("mainMemory", Memory);
            console.log("Beep, beep erasing data... succeeded")
            break;
    }
}

module.exports.loop = function () {
    console.log("---------------------------------------------------")
    
    for(var name in Game.rooms) {
        var room = Game.rooms[name];
        var memoryRoom = Memory.rooms[name];
        
        var creepHostile = room.find(FIND_HOSTILE_CREEPS)
        Game.getObjectById("60eef05dc2cec82f398964b7").attack(creepHostile[0])

        //room.controller.activateSafeMode()
        //memoryRoom.stage = 2

        if(functionsG.random(100) == 0){
            
            functionsR.stage2(room)
            functionsR.stage6(room)
            functionsR.roomFind(name, FIND_DROPPED_RESOURCES, true, "resourceList")
            
            if(memoryRoom.containers[0] != undefined && room.controller.level < 6 && Game.getObjectById(memoryRoom.containers[0]).store.getUsedCapacity(RESOURCE_ENERGY) > 1800){
                var nameCreepRandom = "upgrader" + functionsG.random(11) + 4
                spawnD.spawnFunction(nameCreepRandom, memoryRoom, "upgrader")
            }
            
            var maxIndex = 0;
            
            for(var index in Memory.flags[name]){
                var flagMemory = Memory.flags[name][index]
                if(index == "managerPos"){
                    continue
                }
                
                for(var indexconstructionSite in flagMemory.buildList){
                    var constructionSite = flagMemory.buildList[indexconstructionSite]
                    var posX = constructionSite.x
                    var posY = constructionSite.y
                    var structureType = constructionSite.structureType
                    var index = room.createConstructionSite(posX, posY, structureType)
                    if(index == -8){
                        break;
                    }
                }
                
                if(flagMemory.level > room.controller.level || flagMemory.container == undefined){
                    break;
                }

                maxIndex = (flagMemory.index * 2)
            }
            for(var indexCreep in Memory.flags[name].managerPos){
                console.log(indexCreep + " " + maxIndex)
                if(indexCreep > maxIndex +1){
                    break;
                }
                var identifier = "distributer"
                var creepMemory = Memory.creepsList[name][indexCreep + identifier + name]
                if(creepMemory == undefined){
                    Memory.creepsList[name][indexCreep + identifier + name] = {}
                    var creepMemoryNew = Memory.creepsList[name][indexCreep + identifier + name]
                    creepMemoryNew.alive = "false"
                    creepMemoryNew.roomName = name;
                    creepMemoryNew.identifier = identifier
                    creepMemoryNew.flagIndex = Math.floor(indexCreep/2)
                }
            }
            
            /*for(var i = 2; i < 12; i++){
                Memory.creepsList[name][i + "distributer" + name] = undefined
            }*/
            
            var constructionSites = room.find(FIND_MY_CONSTRUCTION_SITES)
            constructionSites.forEach(function(constructionSite){
                if(constructionSite.progress == 0 && constructionSite.structureType == STRUCTURE_ROAD){
                    constructionSite.remove()
                }
            })
            
            for(var nameCreep in Memory.creepsList[name]){
                creep = Game.creeps[nameCreep]
                var memoryCreep = Memory.creepsList[name][nameCreep]
                if(creep != undefined && memoryCreep.alive == "true"){
                    creepMemoryUpdate.memoryUpdate("c", creep)
                    if(creep.memory.identifier == "harvester" || creep.memory.identifier == "distributer" || creep.memory.identifier == "repairer"){
                        creep.memory.stage = 2
                    }
                    if(creep.memory.lastIdentifier != undefined){
                        memoryCreep.identifier = creep.memory.lastIdentifier
                        creep.memory.identifier = creep.memory.lastIdentifier
                        creep.memory.lastIdentifier = undefined
                    }
                }
                else {
                    memoryCreep.alive == "true"
                }
            }
        }
        
        if(room && memoryRoom != undefined){
            memoryRoom.stage += functionsR["stage" + memoryRoom.stage](room)
        }
        else {
            Memory.rooms[name] = {}
            Memory.rooms[name].stage = 0;
            continue;
        }
        
        /*var structures = room.find(FIND_STRUCTURES)
        var objectToCheck = ["transferListPseudo", "repairListPseudo", "buildListPseudo"]
        var whichList
        for(var struc of structures){
            
            
            
            var list = memoryRoom[whichList]
            if(list.length > 1){
                list.push
            }
        }*/

        for(var nameCreep in Memory.creepsList[name]){
            creep = Game.creeps[nameCreep]
            //Memory.creeps[nameCreep].stage = 0
            var memoryCreep = Memory.creepsList[name][nameCreep]
            //Memory.creeps[nameCreep].identifier = memoryCreep.identifier
            if(!creep && memoryCreep.alive == "true") {
                memoryCreep.alive = "false"
                memoryRoom.stage = 7
                delete Memory.creeps[nameCreep];
            }
            else if(memoryCreep.alive == "true"){
                functionsC.creepChoose(creep, memoryCreep.identifier);
            }
            else if(creep){
                memoryCreep.alive = "true"
            }
        }
        
        for(var nameCreep in Memory.creeps){
            creep = Game.creeps[nameCreep]
            var memoryCreep = Memory.creepsList[name][nameCreep]
            if(memoryCreep == undefined){
                if(!creep){
                    delete Memory.creeps[nameCreep];
                    continue
                }
                functionsC.creepChoose(creep, creep.memory.identifier);
            }
        }
    }
}