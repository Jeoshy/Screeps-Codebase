module.exports = {
    mainMemory(){
        //This line explains which flag to remove to avoid looping over and over
        Game.flags["RESTART"].remove();
        //fundaments of Memory
        return ["creepsList", "rooms", "flags", "claimableRooms", "creeps", "flags"];
    },
    roomMemory(){
        //fundaments for every room memory (aka rooms[...])
        return ["sourcesA", "spawnsA", "controllerRoomO", "containersA", "creepLimit", "spawnListA", "buildListA", "resourceListA", "transferListA", "repairListA", "managerPosA"];
    },
    maxEnergy(nameCreep){
        switch(nameCreep){
            case 'harvester':
                return 750
            case 'builder':
                return 1500
            case 'carrier':
                return 1000
            case 'upgrader':
                return 1000;
            case 'repairer':
                return 2000
            case 'distributer':
                return 400
        }
    },
    bodyFunction(nameCreep){
        switch(nameCreep){
            case 'harvester':
                return [WORK, WORK, MOVE]
            case 'builder':
                return [WORK, MOVE, MOVE, CARRY]
            case 'carrier':
                return [MOVE, CARRY]
            case 'upgrader':
                return [WORK, MOVE, CARRY]
            case 'repairer':
                return [WORK, MOVE, MOVE, CARRY]
            case 'distributer':
                return [CARRY, CARRY]
        }
    }
};