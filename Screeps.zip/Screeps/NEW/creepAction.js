var functionsR = require("room")
var special = require("specialOccasion")

module.exports = {
    actionUpdate(firstOrder, secondOrder, creep){
        var creepIndex = creep.name[0]
        var resource = false
        var creepMemory = creep.memory
        var whichList;
        var whatToFind;
        var filterBoolean = false;
        var thirdOrder = undefined;
        switch(firstOrder){
            case "h":
                firstOrder = "harvest"
                break;
            case "b":
                firstOrder = "build"
                break;
            case "t":
                firstOrder = "transfer"
                resource = RESOURCE_ENERGY
                break;
            case "w":
                firstOrder = "withdraw"
                resource = RESOURCE_ENERGY
                break;
            case "p":
                firstOrder = "pickup"
                break;
            case "r":
                firstOrder = "repair"
                break;
            case "u":
                firstOrder = "upgradeController"
                break;
            case "m":
                firstOrder = "moveTo"
                break;
            case "L":
                firstOrder = "creepPos"
                thirdOrder = FIND_MY_STRUCTURES
                break;
        }
        switch(secondOrder){
            case "s":
                secondOrder = "source"
                resource = RESOURCE_ENERGY
                break;
            case "c":
                secondOrder = "container"
                break;
            case "h":
                secondOrder = "controller"
                creepMemory[secondOrder] = creep.room.controller.id
                break;
            case "C":
                whichList = "buildList"
                whatToFind = FIND_MY_CONSTRUCTION_SITES
                filterBoolean = true
                secondOrder = "constructionSite"
                break;
            case "n":
                whichList = "transferList"
                whatToFind = FIND_MY_STRUCTURES
                filterBoolean = true
                secondOrder = "inNeed"
                resource = RESOURCE_ENERGY
                break;
            case "r":
                whichList = "resourceList"
                whatToFind = FIND_DROPPED_RESOURCES
                filterBoolean = true
                secondOrder = "resource"
                break;
            case "R":
                whichList = "repairList"
                whatToFind = FIND_STRUCTURES
                filterBoolean = true
                secondOrder = "toRepair"
                break;
            case "f":
                secondOrder = "findInRange"
                break;
            case "p":
                var pos = creep.memory.creepPos
                var creepPos = creep.pos
                if(creepPos.x == pos.x && creepPos.y == pos.y){
                    return 1;
                }
                else {
                    creep[firstOrder](pos.x, pos.y, pos.roomName)
                    return 0;
                }
                break;
            case "d":
                secondOrder = "distribute"
                if(creep.memory.list == undefined){
                    creep.memory.stage = 2
                    break;
                }
                var arrayMemoryDistribute = creep.memory.list
                var distrIDK = undefined
                for(var distrID of arrayMemoryDistribute){
                    var objectDistr = Game.getObjectById(distrID)
                    if(objectDistr == null){
                        creepMemory.stage = 2
                        break;
                    }
                    if(objectDistr.store.getFreeCapacity(RESOURCE_ENERGY) > 0){
                        distrIDK = distrID
                        break;
                    }
                }
                if(distrIDK == undefined){
                    return 0;
                }
                creepMemory[secondOrder] = distrID
                break;
        }
        console.log(creep + "[" + firstOrder + "]" + "[" + secondOrder + "]"  )
        var objectID = creepMemory[secondOrder]
        if(whichList != undefined && objectID == undefined){
            var roomMemory = Memory.rooms[creepMemory.nameRoom]
            var list = roomMemory[whichList]
            if(list.length == 0){
                functionsR.roomFind(creepMemory.nameRoom, whatToFind, filterBoolean, whichList)
                if(firstOrder == "pickup"){
                    return 1;
                }
                else {
                    return 0;
                }
            }

            var ID = list[creepIndex]
            //console.log(list)
            if(ID == undefined){
                functionsR.roomFind(creepMemory.nameRoom, whatToFind, filterBoolean, whichList)
                ID = list[0]
            }
            creepMemory[secondOrder] = ID
        }
        
        objectID = creepMemory[secondOrder]
        
        if(objectID == undefined && thirdOrder == undefined){
            if(creepMemory.identifier == "harvester" || creepMemory.identifier == "distributer"){
                return 1;
            }
            return 0
        }

        var object = Game.getObjectById(objectID)
        if(object == null && thirdOrder == undefined){
            creepMemory[secondOrder] = undefined
            functionsR.roomFind(creepMemory.nameRoom, whatToFind, filterBoolean, whichList)
            creepMemory.stage = 0
            return 0
        }
        
        if(thirdOrder != undefined){
            var room = Game.rooms[creep.memory.nameRoom]
            var pos = room.getPositionAt(creep.memory[firstOrder].x, creep.memory[firstOrder].y)
            var array = pos[secondOrder](thirdOrder, 1, {
                filter: function(object){
                    return object.structureType == STRUCTURE_EXTENSION || object.structureType == STRUCTURE_SPAWN || object.structureType == STRUCTURE_TOWER
                }
            })
            var arrayList = []
            for(var objectArray of array){
                arrayList.push(objectArray.id)
            }
            creep.memory["list"] = arrayList
            return 1;
        }
        else{
            if(resource != false){
                var index = creep[firstOrder](object, resource)
            }
            else {
                var index = creep[firstOrder](object)
            }
        }
        console.log("Index number is here " + index)

        if(index == -9){
            if(creepMemory.currentMoveTo != objectID || creepMemory.length <= 0){
                creepMemory.currentMoveTo = objectID
                creepMemory.path = creep.room.findPath(creep.pos, Game.getObjectById(objectID).pos)
                creepMemory.length = creepMemory.path.length
            }
            creepMemory.length--
            if(creep.moveByPath(creepMemory.path) == -11 && creepMemory.identifier != "harvester" && creepMemory.identifier != "distributer" && creepMemory.identifier != "upgrader"){
                Game.rooms[creep.memory.nameRoom].createConstructionSite(creep.pos, STRUCTURE_ROAD)
            }
        }
        else if(index == -7 && creepMemory.identifier != "builder"){
            creepMemory[secondOrder] = undefined
            functionsR.roomFind(creepMemory.nameRoom, whatToFind, filterBoolean, whichList)
            creepMemory.stage = 0
            return 
        }
        switch(creepMemory.identifier){
            case "harvester":
                switch(index){
                    case 0:
                        if(creepMemory.stage < 3){
                            return 1;
                        }
                        break;
                }
                break;
            case "carrier":
                switch(index){
                    case 0:
                        if(firstOrder == "withdraw"){
                            return 2;
                        }
                        if(firstOrder == "transfer"){
                            functionsR.roomFind(creepMemory.nameRoom, whatToFind, filterBoolean, whichList)
                            creepMemory[secondOrder] = undefined
                            return 0
                        }
                        break;
                    case -8:
                        if(firstOrder == "transfer"){
                            functionsR.roomFind(creepMemory.nameRoom, whatToFind, filterBoolean, whichList)
                            creepMemory[secondOrder] = undefined
                            return 0
                        }
                        if(firstOrder == "withdraw"){
                            return 2;
                        }
                        if(firstOrder == "pickup"){
                            return 1;
                        }
                        break;
                    case -6:
                        if(firstOrder == "withdraw"){
                            return 1;
                        }
                        creepMemory.stage = 0
                        break;
                    case -12:
                        if(firstOrder == "transfer"){
                            functionsR.roomFind(creepMemory.nameRoom, whatToFind, filterBoolean, whichList)
                            creepMemory[secondOrder] = undefined
                            return 0
                        }
                        break;
                }
                break;
            case "builder":
                switch(index){
                    case 0:
                        if(firstOrder == "withdraw"){
                            return 2;
                        }
                        break;
                    case -8:
                        if(firstOrder == "withdraw"){
                            return 2;
                        }
                        if(firstOrder == "pickup"){
                            return 1;
                        }
                        break;
                    case -6:
                        if(firstOrder == "withdraw"){
                            return 1;
                        }
                        creepMemory.stage = 0
                        break;
                    case -7:
                        special.moveCreep(object.pos.x, object.pos.y, creep.memory.nameRoom)
                        break;
                }
                break;
            case "upgrader":
                switch(index){
                    case 0:
                        if(firstOrder == "withdraw"){
                            return 2;
                        }
                        if(firstOrder == "moveTo"){
                            return 1;
                        }
                        break;
                    case -8:
                        if(firstOrder == "withdraw"){
                            return 2;
                        }
                        if(firstOrder == "pickup"){
                            return 1;
                        }
                        break;
                    case -6:
                        if(firstOrder == "withdraw"){
                            return 1;
                        }
                        creepMemory.stage = 0
                        break;
                }
                break;
            case "repairer":
                switch(index){
                    case 0:
                        if(firstOrder == "withdraw"){
                            return 2;
                        }
                        if(firstOrder == "repair"){
                            if(object.hits > 3000){
                                console.log("hello" + creepMemory.nameRoom + whatToFind + filterBoolean + whichList)
                                functionsR.roomFind(creepMemory.nameRoom, whatToFind, filterBoolean, whichList)
                                creepMemory[secondOrder] = undefined
                            }
                        }
                        break;
                    case -8:
                        if(firstOrder == "withdraw"){
                            return 2;
                        }
                        if(firstOrder == "pickup"){
                            return 1;
                        }
                        break;
                    case -6:
                        if(firstOrder == "withdraw"){
                            return 1;
                        }
                        creepMemory.stage = 0
                        break;
                }
                break;
            case "distributer":
                switch(index){
                    case 0:
                        if(firstOrder == "transfer"){
                            return 0;
                        }
                        break;
                    case -8:
                        return 1;
                        break;
                    break;
                    case -6:
                        if(firstOrder == "transfer"){
                            return -1
                        }
                        if(firstOrder == "withdraw"){
                            return 1
                        }
                        break;
                }
        }
        return 0;
    }
};