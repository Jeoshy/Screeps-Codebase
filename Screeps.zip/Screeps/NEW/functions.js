var data = require("data")

module.exports = {
    restart(name, memoryType){
        
        var listOfMemory = data[name]()

        for(var memory in memoryType){
            delete memoryType[memory];
        }
        
        for(var nameMemory of listOfMemory){
            if(nameMemory[nameMemory.length -1] == "A"){
                nameMemory = nameMemory.substring(0, nameMemory.length -1)
                memoryType[nameMemory] = [];
            }
            else if(nameMemory[nameMemory.length -1] == "O"){
                nameMemory = nameMemory.substring(0, nameMemory.length -1)
                memoryType[nameMemory] = "";
            }
            else{
                memoryType[nameMemory] = {};
            }
        }
    },
    
    idStore(memoryParent, toStore, memoryName){
        for(var index in toStore){
            var store = toStore[index];
            memoryParent[memoryName].push(store.id)
        }
    },
    random(number){
        return Game.time % number
    }
};