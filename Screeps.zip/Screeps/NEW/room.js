var functionsG = require("functions")
var spawnD = require("spawn")

module.exports = {
    roomFind(name, whatToFind, filterBoolean, whichList){
        var objectArray = Game.rooms[name].find(whatToFind)

        if(filterBoolean == true){
            switch(whichList){
                case "buildList":
                    objectArray0 = _.filter(objectArray, function(resourceS){
                        return resourceS.structureType == STRUCTURE_EXTENSION
                    })
                    if(objectArray0[0] != undefined){
                        objectArray[0] = objectArray0[0]
                    }
                    break;
                case "resourceList":
                    objectArray = _.filter(objectArray, function(resourceS){
                        return resourceS.resourceType == RESOURCE_ENERGY
                    })
                    break;
                case "transferList":
                    objectArray = []
                    var flagMemories = Memory.flags[name]
                    var objectContainer = null
                    var flagMemory = undefined
                    
                    for(var indexFlag in flagMemories){
                        flagMemory = flagMemories[indexFlag]
                        if(flagMemory.container != undefined){
                            var object = Game.getObjectById(flagMemory.container)
                            if(object == null){
                                flagMemory.container = undefined
                                continue;
                            }
                            if(object.store.getUsedCapacity(RESOURCE_ENERGY) < 100000){
                                objectContainer = object
                                break;
                            }
                        }
                    }
                    
                    var room = Game.rooms[name]
                    var creeps = room.find(FIND_MY_CREEPS)
                    creepsDistributers = _.filter(creeps, function(creep){
                        return creep.memory.identifier == "distributer"
                    })
                    if(objectContainer != null && creepsDistributers.length > 0){
                        objectArray[0] = object
                    }
                    else{
                        var distributerAlive = false
                        for(var index in creepsDistributers){
                            var creepDistributer = creepsDistributers[index]
                            if(creepDistributer != undefined){
                                if(creepDistributer.store.getFreeCapacity(RESOURCE_ENERGY) > 50){
                                    objectArray.push(creepDistributer)
                                }
                                distributerAlive = true
                            }
                        }

                        if(distributerAlive == false){
                            objectArray = Game.rooms[name].find(whatToFind)
                            objectArray = _.filter(objectArray, function(struc){
                                return (struc.structureType == STRUCTURE_SPAWN || struc.structureType == STRUCTURE_EXTENSION || struc.structureType == STRUCTURE_EXTENSION) && struc.store.getFreeCapacity(RESOURCE_ENERGY) > 0
                            })
                            break;
                        }
                    }
                    var containerId = Memory.rooms[name].containers[0]
                    object = Game.getObjectById(containerId)
                    if(object != null && object.store.getFreeCapacity(RESOURCE_ENERGY) > 0){
                        objectArray.push(object)
                        break;
                    }
                    creepsBuilders = _.filter(creeps, function(creep){
                        return creep.memory.identifier == "builder"
                    })
                    for(var builder of creepsBuilders){
                        if(builder.store.getFreeCapacity(RESOURCE_ENERGY) > 0){
                            objectArray.push(builder)
                        }
                    }
                    break;
                case "repairList":
                    objectArray = _.filter(objectArray, function(struc){
                        return struc.hits < struc.hitsMax
                    })
                    var temporaryObject = {}
                    var temporaryArray = []
                    for(var object of objectArray){
                        var ratio = Math.floor((object.hits/object.hitsMax) * 100) /100
                        //ratio = Math.floor(ratio)
                        temporaryArray.push(ratio)
                        temporaryObject[ratio] = object.id
                    }
                    temporaryArray.sort()
                    var objectID = temporaryObject[temporaryArray[0]]
                    Memory.rooms[name][whichList] = []
                    Memory.rooms[name][whichList].push(objectID)
                    return;
                    break;
            }
        }

        Memory.rooms[name][whichList] = []
        for(var object of objectArray){
            Memory.rooms[name][whichList].push(object.id)
        }
    },
    stage0(room){
        var name = room.name
        var roomMemory = Memory.rooms[name]
//-----------------------------------------------------------------------------------------------------------------------------------------------------        
        var creeps = room.find(FIND_MY_CREEPS)
        creeps.forEach(function(creep){
            creep.suicide()
        })
        var constructionSites = room.find(FIND_MY_CONSTRUCTION_SITES)
        constructionSites.forEach(function(constructionSite){
            constructionSite.remove()
        })
        var flags = room.find(FIND_FLAGS)
        flags.forEach(function(flag){
            flag.remove()
        })
        functionsG.restart("roomMemory", roomMemory);
        return 1;
    },
    stage1(room){
        var name = room.name
        var roomMemory = Memory.rooms[name]
//-----------------------------------------------------------------------------------------------------------------------------------------------------
        var sources = room.find(FIND_SOURCES);
        functionsG.idStore(roomMemory, sources, "sources")
        //This also gives the order which the things spawn in
        roomMemory.creepLimit.harvester = sources.length;
        roomMemory.creepLimit.carrier = sources.length;
        roomMemory.creepLimit.distributer = 2;
        roomMemory.creepLimit.builder = 1;
        roomMemory.creepLimit.upgrader = 1;
        roomMemory.creepLimit.repairer = 1;
        return 1;
    },
    stage2(room){
        var name = room.name
        var roomMemory = Memory.rooms[name]
//-----------------------------------------------------------------------------------------------------------------------------------------------------
        var flags = room.find(FIND_FLAGS)

        flags = _.filter(flags, function(flag){
            return flag.color == COLOR_WHITE && (flag.name[0] == "m" || flag.name[0] == "M")
        })
        if(flags.length < 6){
            return 0;
        }
        
        var flagsMemory = Memory.flags[name] = {}
        flagsMemory["managerPos"] = {}
        
        for(var index in flags){
            var flag = flags[index]
            var flagMemory = Memory.flags[name][index + name] = {}
            var flagPosX = flag.pos.x
            var flagPosY = flag.pos.y
            var posList = [{dx: -1, dy: -1},{dx: -2, dy: -1},{dx: -2, dy: 0},{dx: -2, dy: 1},{dx: -1, dy: 1},
                           {dx: 1,  dy: -1},{dx: 2,  dy: -1},{dx: 2,  dy: 0},{dx: 2,  dy: 1},{dx: 1,  dy: 1}]
            var array = flag.pos.findInRange(FIND_STRUCTURES, 1, {
                filter: function(object){
                    return object.structureType == STRUCTURE_CONTAINER || object.structureType == STRUCTURE_STORAGE
                }
            })
            if(array[0] != undefined){
                flagMemory.container = array[0].id
            }
            flagMemory.index = index
            flagMemory.buildList = []
            for(var extensionPos of posList){
                var dx = extensionPos.dx
                var dy = extensionPos.dy
                flagMemory.buildList.push({x: flagPosX + dx, y: flagPosY + dy, structureType: STRUCTURE_EXTENSION})
            }
            flagMemory.buildList.push({x: flagPosX, y: flagPosY -1, structureType: STRUCTURE_CONTAINER})
            switch(parseFloat(index)){
                case 0:
                    flagMemory.level = 0
                    flagsMemory["managerPos"][0] = {x: flagPosX -1, y: flagPosY}
                    flagsMemory["managerPos"][1] = {x: flagPosX +1, y: flagPosY}
                    break;
                case 1:
                    flagMemory.level = 4
                    flagMemory.buildList.push({x: flagPosX, y: flagPosY +1, structureType: STRUCTURE_TOWER})
                    flagMemory.buildList.push({x: flagPosX, y: flagPosY +1, structureType: STRUCTURE_RAMPART})
                    flagsMemory["managerPos"][2] = {x: flagPosX -1, y: flagPosY}
                    flagsMemory["managerPos"][3] = {x: flagPosX +1, y: flagPosY}
                    break;
                case 2:
                    flagMemory.level = 5
                    flagMemory.buildList.push({x: flagPosX, y: flagPosY +1, structureType: STRUCTURE_STORAGE})
                    flagsMemory["managerPos"][4] = {x: flagPosX -1, y: flagPosY}
                    flagsMemory["managerPos"][5] = {x: flagPosX +1, y: flagPosY}
                    break;
                case 3:
                    flagMemory.level = 6
                    flagsMemory["managerPos"][6] = {x: flagPosX -1, y: flagPosY}
                    flagsMemory["managerPos"][7] = {x: flagPosX +1, y: flagPosY}
                    break;
                case 4:
                    flagMemory.level = 7
                    flagsMemory["managerPos"][8] = {x: flagPosX -1, y: flagPosY}
                    flagsMemory["managerPos"][9] = {x: flagPosX +1, y: flagPosY}
                    break;
                case 5:
                    flagMemory.level = 8
                    flagsMemory["managerPos"][10] = {x: flagPosX -1, y: flagPosY}
                    flagsMemory["managerPos"][11] = {x: flagPosX +1, y: flagPosY}
                    break;
            }

        }
        return 1
    },
    stage3(room){
        var name = room.name
        var roomMemory = Memory.rooms[name]
//-----------------------------------------------------------------------------------------------------------------------------------------------------
        var controller = room.controller;
        roomMemory.controllerRoom = controller.id
        return 1;
    },
    stage4(room){
        var name = room.name
        var roomMemory = Memory.rooms[name]
//-----------------------------------------------------------------------------------------------------------------------------------------------------
        var spawns = room.find(FIND_MY_SPAWNS)
        functionsG.idStore(roomMemory, spawns, "spawns")
        return 1;
    },
    stage5(room){
        var name = room.name
        var roomMemory = Memory.rooms[name]
//-----------------------------------------------------------------------------------------------------------------------------------------------------
        Memory.creepsList[name] = {}
        for(var nameCreep in roomMemory.creepLimit){
            var limit = roomMemory.creepLimit[nameCreep]
            for(var i = 0; i < limit; i++){
                var nameCreepM = i + nameCreep + name
                var creepMemory = Memory.creepsList[name][nameCreepM] = {}
                creepMemory.alive = "false"
                creepMemory.roomName = name;
                creepMemory.identifier = nameCreep
                creepMemory.flagIndex = Math.floor(parseFloat(i)/2)
            }
        }
        return 1;
    },
    stage6(room){
        var name = room.name
        var roomMemory = Memory.rooms[name]
//-----------------------------------------------------------------------------------------------------------------------------------------------------
        var arrayWithSpawnAndController = [room.controller.id]
        for(var source of roomMemory.sources){
            arrayWithSpawnAndController.push(source)
        }
        for(var index in arrayWithSpawnAndController){
            var id = arrayWithSpawnAndController[index]
            //search source and first spawn to make a container that is optimal placed
            var source = Game.getObjectById(id)
            var spawn = Game.getObjectById(roomMemory.spawns[0])
            //The actual path to the source
            var path = spawn.pos.findPathTo(source, {ignoreCreeps: true, ignoreDestructibleStructures: true})
            if(path.length > 0){
                var posContainer = room.getPositionAt(path[path.length -2].x,path[path.length -2].y)
            }
            var container = source.pos.findInRange(FIND_STRUCTURES, 1, {
                filter: function(object){
                    return object.structureType == STRUCTURE_CONTAINER
                }
            })
            if(container[0] != null){
                roomMemory.containers[index] = container[0].id
                continue;
            }
            else {
                roomMemory.containers[index] = undefined
            }
            if(spawn.id == id){
                continue;
            }
            room.createConstructionSite(posContainer , STRUCTURE_CONTAINER)
        }
        return 1;
    },
    stage7(room){
        var name = room.name
        var roomMemory = Memory.rooms[name]
//-----------------------------------------------------------------------------------------------------------------------------------------------------
        for(var nameCreep in Memory.creepsList[name]){
            var creep = Memory.creepsList[name][nameCreep]
            var identifier = creep.identifier
            if(creep.alive == "false"){
                spawnD.spawnFunction(nameCreep, roomMemory, identifier);
            }
        }
        return 1;
    },
    stage8(room){
        var name = room.name
        var roomMemory = Memory.rooms[name]
//-----------------------------------------------------------------------------------------------------------------------------------------------------
        for(var index in roomMemory.spawns){
            if(roomMemory.spawnList.length == 0){
                return 0;
            }
            if(index != functionsG.random(69)){
                var spawnID = roomMemory.spawns[index]
                var spawn = Game.getObjectById(spawnID)
                if(spawn == null){
                    continue
                }
                var creeps = spawn.pos.findInRange(FIND_MY_CREEPS, 1)
                creeps = _.filter(creeps, function(creep){
                    return creep.ticksToLive < 1400
                })
                spawn.renewCreep(creeps[0])
                continue;
            }
            var spawnID = roomMemory.spawns[index]
            var boolean = spawnD.spawningFunction(roomMemory.spawnList[0], room, spawnID)
            if(boolean == true){
                console.log("A new creep has been born " + name )
                roomMemory.spawnList.splice(0,1)
            }
        }
        return 0;
    }
};