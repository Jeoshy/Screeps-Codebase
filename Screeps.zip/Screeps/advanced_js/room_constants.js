Room.prototype.roomLevel = function () {
    const {level, jobs, creepList} = this.memory
    var reset = false

    // reset = true
    if (level != this.controller.level || reset) {
        console.log("Room went up a level \n", level, "=>", this.controller.level, this.name)
        
        // // Reset all memory of creeps stored in the creepList of the room (some might be dead)
        // if (creepList != undefined) {
        //     for (let creep_id of creepList) {
        //         let creep = Game.getObjectById(creep_id)
                
        //         if (!creep) {
        //             continue
        //         }
                
        //         // The false is for initialized
        //         creep.resetMemory(false)
        //     }
        // }
        
        let creeps = _.filter(Game.creeps, (creep) => {
            return creep.memory.roomName == this.name
        })
        
        for (let creep of creeps) {
            // Set initialized on false
            creep.resetMemory(false)
        }
        
        // Reset memory of room
        this.memory = {}
        
        // this.memory = {jobs: jobs}
        
        // Values / arrays to always include in every level
        this.center = new RoomPosition(25, 25, this.name)
        
        this.memory.level = this.controller.level
        this.memory.hobbys = [new CleanUp(), new Builder()]
        this.memory.spawnList = []
        this.memory.dropPoints = {}
        this.memory.upgradeSpots = []
        this.memory.creepList = []
        this.memory.jobLists = [{jobs: [], creepList: []}, {jobs: [], creepList: []}, {jobs: [], creepList: []}, {jobs: [], creepList: []}, {jobs: [], creepList: []}, {jobs: [], creepList: []}]
        
        // Functions that stay the same every level


        this.switchedLevel(this.memory.level)
    }
}

Room.prototype.switchedLevel = function (level) {
    switch (level) {
        case 1:

            // HarvestSpots ------------------------------------------------
            
            this.harvestSpots(3)
            
            
            // UpgradeSpots -----------------------------------------
            
            this.upgradeSpots(this.memory.harvestSpots.length - 1)
            
            
            // CreateJobs ------------------------------------------------
            
            // Add a harvest job for every spot: spot is an object containing Roomposition and a source_id
            // Add a lookUp for job for every harvestSpot: spot is a harvestSpot
            this.memory.harvestSpots.forEach((spot) => {
                this.addJob(new Harvest(spot))
                this.addJob(new LookFor(spot, "cclean", 5, false))
            })
            
            // Add a upgrader job for every spot: spot is a RoomPosition object
            this.memory.upgradeSpots.forEach((spot) => {
                this.addJob(new Upgrader(spot))
            })
            
            
            
            
            // CreateSpawnlist ------------------------------------------------
            this.addToSpawnList(["harvester", "carrier"], this.memory.harvestSpots.length)
            this.addToSpawnList(["upgrader"], this.memory.upgradeSpots.length)
            
            break;
        case 2:
                        
            // HarvestSpots ------------------------------------------------
            
            this.harvestSpots(3)
            
            
            // UpgradeSpots -----------------------------------------
            
            this.upgradeSpots(this.memory.harvestSpots.length - 1)
            
            
            // CreateJobs ------------------------------------------------
            
            // Add a harvest job for every spot: spot is an object containing Roomposition and a source_id
            this.memory.harvestSpots.forEach((spot) => {
                this.addJob(new Harvest(spot))
                this.addJob(new LookFor(spot, "cclean", 5, false))
            })
            
            // Add a upgrader job for every spot: spot is a RoomPosition object
            this.memory.upgradeSpots.forEach((spot) => {
                this.addJob(new Upgrader(spot))
            })
            
            
            // CreateSpawnlist ------------------------------------------------
            this.addToSpawnList(["harvester", "carrier"], this.memory.harvestSpots.length)
            this.addToSpawnList(["upgrader"], this.memory.upgradeSpots.length)
            this.addToSpawnList(["builder"], 1)
            
            break;
        case 3:
            this.switchedLevel(2)
            break;
        case 4:
            this.switchedLevel(1)
            break;
    }
}

Room.prototype.harvestSpots = function (range) {
    var harvestSpots = []
    var sources = this.find(FIND_SOURCES).sort((a, b) => a.pos.findPathTo(this.center).length - b.pos.findPathTo(this.center).length)
    
    // Find up to range tiles closest to this.center next to each source to harvest from
    for (let source of sources) {
        let tiles = source.pos.tileInArea()
        
        // Filter out the harvestSpots we cannot reach, if empty, then continue
        tiles = tiles.filter((tile) => {
            return tile.findPathTo(this.center).length >= tile.getRangeTo(this.center)
        })
        
        if (tiles.length == 0) {
            continue
        }
        
        // Sort whose closest. Btw a and b are already RoomPositions contrary to the sources sort
        tiles = tiles.sort((a, b) => a.findPathTo(this.center).length - b.findPathTo(this.center).length)
        
        // Then limit to range tiles per source
        if (tiles.length > range) {
            tiles.length = range
        }
        
        // Then transform it in object with the source id
        tiles = tiles.map((tile) => {
            return {pos: tile, source_id: source.id}
        })

        harvestSpots = harvestSpots.concat(tiles)
    }
    this.memory.harvestSpots = harvestSpots
}

Room.prototype.upgradeSpots = function (range) {
    for (let tile of this.controller.pos.tileInArea(2)) {
        let workable = tile.tileInArea()
        if (workable.length == 9) {
            this.memory.dropPoints.upgrader = tile
            
            // Remove the one where resources are dropped
            workable.splice(4, 1)
            workable = workable.sort((a, b) => a.getRangeTo(this.controller) - b.getRangeTo(this.controller))
            workable.length = range
            this.memory.upgradeSpots = workable
            break;
        }
    }
}

Room.prototype.addToSpawnList = function (creepNames, n) {
    for (i = 0; i < n; i++) {
        for (let name of creepNames) {
            //console.log(new global[name](this.name, i).name, i)
            this.memory.spawnList.push(new global[name](this.name, i))
        }
    }
}