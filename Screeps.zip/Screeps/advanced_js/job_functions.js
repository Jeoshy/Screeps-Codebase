if (!Memory.jobCount) {
    Memory.jobCount = 0
}


function Job (creepType, core, priority = 5) {
    this.checks = []
    this.memory = {}
    this.creepType = creepType
    this.core = core
    this.priority = priority
    this.creep_id = undefined
    
    Memory.jobCount += 1
    this.id = Memory.jobCount
}


// Jobs ----------------------

global.Harvest = function ({pos, source_id}) {
    Job.call(this, "harvester", "charvest", 5)
    this.memory.pos = pos
    this.memory.source_id = source_id
}

global.LookFor = function ({pos}, core, priority, temp = true) {
    Job.call(this, "carrier", core, priority)
    this.memory.pos = pos
    this.memory.temp = temp
}

global.Upgrader = function (pos) {
    Job.call(this, "upgrader", "cupgrade", 5)
    this.memory.pos = pos
}


// Creep created jobs ---------------------------------------

global.CreepMove = function (creep_id, moveTo_pos, range = 0) {
    Job.call(this, "carrier", "cmoveTo", 0)
    this.memory.creep_id = creep_id
    this.memory.moveTo_pos = moveTo_pos
    this.memory.range = range
}


// Hobbys ---------------------------

global.CleanUp = function () {
    Job.call(this, "carrier", "cclean")
}

global.Builder = function () {
    Job.call(this, 'builder', 'cbuild', 5)
}