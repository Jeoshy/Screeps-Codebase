Room.prototype.eventBasedJobs = function () {
    
    // Every resource created under a harvester or tombstone needs to be picked up
    
}