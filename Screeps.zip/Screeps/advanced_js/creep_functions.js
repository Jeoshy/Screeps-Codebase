Creep.prototype.main = function () {
    
}

Creep.prototype.charvest = function ({source_id, pos: position}, job) {
    
    // Phase 2: harvest resource
    if (this.harvest(Game.getObjectById(source_id)) == OK){
        return
    }
    
    // Phase 1: go to spot
    if (this.pos.x == position.x && this.pos.y == position.y) {
        this.memory.createJobToMove = true
        return
    }
    
    if (!this.memory.createJobToMove) {
        this.room.addJob(new CreepMove(this.id, position))
        this.memory.createJobToMove = true
    }
    //this.moveTo(position.x, position.y)
}

Creep.prototype.cbuild = function({}, job) {
    let buildAt = this.room.getBuild()

    if (!buildAt) {
        return
    }
    
    // Phase 2: build
    let index = this.build(buildAt)
    if (index == OK || index == ERR_NOT_ENOUGH_RESOURCES) {
        this.memory.busy = true
    }
    
    // Phase 1: go to construction site
    if (buildAt.id != this.memory.id) {
        this.room.addJob(new CreepMove(this.id, buildAt.pos, 3))
        this.memory.busy = false
        this.memory.id = buildAt.id
    }
    
}

Creep.prototype.cmoveTo = function ({creep_id, moveTo_pos, range}, job) {
    let creep = Game.getObjectById(creep_id)
    
    if (!creep) {
        job.done = true
        return
    }
    
    let index1 = creep.move(this)
    let index2 = this.pull(creep)
    
    if (!moveTo_pos) {
        job.done = true
        return
    }
    
    if (index1 == OK && index2 == OK) {
        if (this.memory.reached == OK && this.moveTo(creep) == OK) {
            job.done = true
            return
        }
        
        if (this.pos.inRangeTo(moveTo_pos.x, moveTo_pos.y, range)) {
            this.memory.reached = OK
            return
        }
        
        this.moveTo(moveTo_pos.x, moveTo_pos.y)
        return
    }
    
    this.moveTo(creep)
}

Creep.prototype.cupgrade = function ({pos: position}, job) {
    
    // Phase 3: upgrade controller
    if (this.memory.busy) {
        let index = this.upgradeController(this.room.controller)
        if (index == ERR_NOT_ENOUGH_RESOURCES) {
            this.memory.busy = false
        }
        
        return
    }
    
    // Phase 2: pickup resource
    let {x, y} = this.room.memory.dropPoints["upgrader"]
    let resource = this.room.lookForAt(LOOK_RESOURCES, x, y)[0]
    let index = this.pickup(resource)
    
    if (index == OK || index == ERR_FULL){
        this.memory.busy = true
        return
    }
    
    // Phase 1: go to spot
    if (this.pos.x == position.x && this.pos.y == position.y) {
        this.memory.createJobToMove = true
        return
    }
    
    if (!this.memory.createJobToMove) {
        this.room.addJob(new CreepMove(this.id, position))
        this.memory.createJobToMove = true
    }
}

Creep.prototype.cclean = function ({pos, temp}, job) {
    
    // Make sure they don't constantly switch
    let dropAt = this.room.getEmpty()
    let {x, y, roomName} = this.room.getDropPoints()
    
    // If resources acquired choose between spawn or extension or upgrading
    if (this.memory.busy) {
        if (dropAt != undefined) {
            let index = this.transfer(dropAt, RESOURCE_ENERGY)
            if (index == ERR_NOT_IN_RANGE) {
                this.moveTo(dropAt)
            }
        } else {
            let drop = new RoomPosition(x, y, roomName)
            if (!this.pos.inRangeTo(drop, 0)) {
                this.moveTo(drop)
            } else {
                this.drop(RESOURCE_ENERGY)
            }
        }
        
        if (this.store.getUsedCapacity() == 0) {
            this.memory.busy = false
        }
        return
    }
    
    let resource = this.room.lookForAt(LOOK_RESOURCES, pos.x, pos.y, )[0]
    
    // Not busy or occupied, find resources
    if (!resource) {
        if (temp) {
            job.done = true
        }
        
        return
    }
    
    if (temp) {
        let index = this.pickup(resource)
        if (index == ERR_NOT_IN_RANGE) {
            this.moveTo(resource)
        }
        
        if (index == OK) {
            this.memory.busy = true
        }
    } else {
        if (!this.pos.inRangeTo(resource, 1)) {
            this.moveTo(resource)
        }
        
        if (resource.amount > this.store.getFreeCapacity()) {
            this.pickup(resource)
        }
        
        if (this.store.getFreeCapacity() == 0) {
            this.memory.busy = true
        }
    }
}









