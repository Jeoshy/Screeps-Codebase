function MyCreep (body, type, roomName, maxCost, name = Game.time) {
    this.body = body
    this.maxCost = maxCost
    this.name = type + name + roomName
    this.memory = {type: type, roomName: roomName, name: this.name}
    this.bodyCost = _.reduce(body, (total, part) => {return total + BODYPART_COST[part]}, 0)
    this.spawned = false
}


// Creep templates -------------

global.harvester = function (roomName, random) {
    MyCreep.call(this, [WORK, WORK], "harvester", roomName, 600, random)
}

global.carrier = function (roomName, random) {
    MyCreep.call(this, [CARRY, MOVE], "carrier", roomName, 2000, random)
}

global.upgrader = function (roomName, random) {
    MyCreep.call(this, [WORK, CARRY, WORK, CARRY], "upgrader", roomName, 1500, random)
}

global.builder = function (roomName, random) {
    MyCreep.call(this, [WORK, CARRY, WORK, CARRY], "builder", roomName, 1500, random)
}


// General creep functions ---------------------

Creep.prototype.resetMemory = function(initialized = true) {
    this.memory = {type: this.memory.type, roomName: this.memory.roomName, initialized: initialized, id: this.memory.id}
}