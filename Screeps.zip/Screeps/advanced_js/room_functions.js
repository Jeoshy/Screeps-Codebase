Room.prototype.main = function () {
    this.roomLevel()
    this.eventBasedJobs()
    
    if (this.memory.level > 0){
        this.jobs()
        this.creepSpawn()
    }
}

Room.prototype.jobs = function () {
    const {jobLists, hobbys} = this.memory
    
    for (let priorityArray of jobLists) {
        for (let job of priorityArray.jobs) {
            let {creep_id, memory, creepType, core, done, level, id: job_id} = job
            
            // If job has no creep, then choose a creep from the creepList
            if (!creep_id && priorityArray.creepList.length != 0) {
                job.creep_id = priorityArray.creepList.find((creep_id) => {
                    let creep = Game.getObjectById(creep_id)
                    if (!creep) {
                        let index = priorityArray.creepList.indexOf(job.creep_id)
                        priorityArray.creepList.splice(index, 1)
                        return false
                    }
                    return creep.memory.type == creepType && !creep.memory.busy
                })
                
                // No creep_id gotten? Try next time
                if (!job.creep_id) {
                    continue
                }
                
                let index = priorityArray.creepList.indexOf(job.creep_id)
                priorityArray.creepList.splice(index, 1)
            }
            
            // Check whether creep_id still alive
            let my_creep = Game.getObjectById(creep_id)
            if (!my_creep && creep_id != undefined) {
                console.log("creep died in \n", this.name)
                
                job.creep_id = undefined
                continue;
            }
            
            // Still no creep_id? 
            if (!creep_id) {
                continue
            }
            
            // If job done, then resetMemory of creep, take the job away from jobs and add the creep back to creepList
            if (done) {
                console.log("Task done \n", core, this.name)
                priorityArray.creepList.push(creep_id)
                
                let index = priorityArray.jobs.indexOf(job)
                priorityArray.jobs.splice(index, 1)
                
                let my_creep = Game.getObjectById(creep_id)
                if (my_creep != undefined) {
                    my_creep.resetMemory()
                }
                
                continue
            }
            
            // If creep has no id, then we need to add id for priority
            if (!my_creep.job_id) {
                my_creep.job_id = job_id
            }
            
            // If creep doesn't have this job_id, then skip the job for now
            if (my_creep.job_id != job_id) {
                continue
            }

            my_creep[core](memory, job)
        }
    }
    
    // for (let hobby of hobbys) {
    //     let {memory, creepType, core} = hobby
        
    //     let creeps = this.find(FIND_MY_CREEPS, {
    //         filter: function (creep) {
    //             return creep.memory.type == creepType && !creep.memory.occupied
    //         }
    //     })
        
    //     for (let creep of creeps) {
    //         creep[core](memory, hobby)
    //     }
    // }
}

Room.prototype.addJob = function (job) {
    job.level = this.memory.level
    this.memory.jobLists[job.priority].jobs.push(job)
}

Room.prototype.addHobby = function (hobby) {
    hobby.level = this.memory.level
    this.memory.hobbys.push(hobby)
}

Room.prototype.creepSpawn = function () {
    const spawns = this.find(FIND_MY_SPAWNS)
    const spawn = spawns.find((s) => {return s.spawning == null})
    
    if (!spawn) {
        return
    }
    
    let creep = this.memory.spawnList.find((c) => {return !c.spawned})
    if (!creep){
        return
    }
    
    let {body, bodyCost, maxCost, memory, name} = creep
    if (Game.creeps[name] != undefined) {
        creep.spawned = true
        return
    }

    let full_body = []
    let energy = this.energyAvailable
    
    if (this.energyCapacityAvailable < maxCost) {
        maxCost = this.energyCapacityAvailable
    }
    
    let minimalCost = (this.find(FIND_MY_CREEPS).length - 1) * this.controller.level * 100
    
    if (this.energyCapacityAvailable < minimalCost) {
        minimalCost = this.energyCapacityAvailable
    }
    
    if (energy < minimalCost) {
        return
    }
    
    if (energy < bodyCost) {
        return
    }
    
    if (energy > maxCost) {
        energy = maxCost
    }
    
    for (i = 0; i < Math.floor(energy / bodyCost); i++) {
        full_body = full_body.concat(body)
    }
    
    let index = spawn.spawnCreep(full_body, name, {memory})
    console.log(index, name)
    if (index == OK) {
        creep.spawned = true
    }
}


// Getters ---------------------

Room.prototype.getResources = function () {
    if (!this.resources) {
        let resources = this.find(FIND_DROPPED_RESOURCES, {
            filter: function(resource) {
                return !resource.pos.inRangeTo(resource.room.controller, 3)
            }
        })
        resources = resources.sort((a, b) => b.pos.getRangeTo(this.controller) - a.pos.getRangeTo(this.controller))
        this.resources = resources
    }
    
    return this.resources.pop()
}

Room.prototype.getEmpty = function () {
    if (!this.empty) {
        this.empty = this.find(FIND_MY_STRUCTURES, {
            filter: function (structure) {
                return (structure.structureType == STRUCTURE_EXTENSION || structure.structureType == STRUCTURE_SPAWN) && structure.store.getFreeCapacity(RESOURCE_ENERGY) > 10
            }
        })
        
        // this.empty = this.empty.concat(this.find(FIND_MY_CREEPS, {
        //     filter: function (creep) {
        //         return creep.memory.type == "builder" && creep.memory.busy && creep.store.energy == 0
        //     }
        // }))
    }
    
    if (this.empty.length == 1) {
        return this.empty[0]
    }
    
    return this.empty.pop()
}

Room.prototype.getBuild = function () {
    if (!this.build) {
        let build = this.find(FIND_MY_CONSTRUCTION_SITES)
        this.build = build
    }
    
    return this.build.pop()
}

Room.prototype.getDropPoints = function () {
    if (!this.dropPoints || this.dropPoints.length == 0) {
        this.dropPoints = Object.values(this.memory.dropPoints)
    }
    
    return this.dropPoints.pop()
}























