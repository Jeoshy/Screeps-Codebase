require ("object_functions")
require ("job_functions")
require ("room_constants")
require ("room_events")
require ("room_functions")
require ("creep_constants")
require ("creep_functions")
const profiler = require('screeps-profiler');
profiler.enable();


// Game.reset = true
if (Game.reset) {
    console.log("Memory has been reset")
    RawMemory.set("{}")
    Memory = {rooms: {}, creeps: {}, flags: {}, spawns: {}}
}

module.exports.loop = function () {
    profiler.wrap(function() {
        for (let creepName in Memory.creeps) {
            let creep = Game.creeps[creepName]
            
            // Creep is dead so creep needs to be respawned again
            if (!creep) {
                let creepMemory = Memory.creeps[creepName]
                let roomMemory = Memory.rooms[creepMemory.roomName]
        
                if (!roomMemory || !roomMemory.spawnList) {
                    continue
                }
                
                let index = roomMemory.creepList.indexOf(creepMemory.id)
                roomMemory.creepList.splice(index, 1)
                
                for (let priorityArray of roomMemory.jobLists) {
                    for (let creepList of priorityArray.creepList) {
                        let index = creepList.indexOf(creepMemory.id)
                        if (index == -1) {
                            continue
                        }
                        priorityArray.creepList.splice(index, 1)
                    }
                }
        
                let spawnCreep = roomMemory.spawnList.find((c) => {
                    return c.name == creepName
                })
                
                if (!spawnCreep) {
                    continue
                }
                
                spawnCreep.spawned = false
                
                delete Memory.creeps[creepName]
                
                console.log("Creep died in \n", creepMemory.roomName)
                
                continue;
            }
            
            let {initialized, roomName} = creep.memory
            
            // Add the creep id to every creepList in every priorityArray
            if (!initialized) {
                creep.memory.initialized = true
                
                creep.memory.id = creep.id
            
                let {jobLists} = Memory.rooms[creep.memory.roomName]
                for (let priorityArray of jobLists) {
                    priorityArray.creepList.push(creep.id)
                }
                
                Memory.rooms[creep.memory.roomName].creepList.push(creep.id)
                
                console.log("Initialized \n", creep.name, creep.memory.roomName)
            }
        }
    
        _.forEach(Game.rooms, (room) => room.main())  
    })
}


