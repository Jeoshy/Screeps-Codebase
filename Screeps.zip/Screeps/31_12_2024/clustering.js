/*
Input: locations
Locations not in proximity of cluster become a cluster
When location is added, loop through whole dictionary and check with every location
if in distance of a location: give it label of a cluster
If not in distance: increment cluster count and give it this cluster number
Output: cluster memory adjusted
*/

Room.prototype.areObjectsInClusters = function (objects) {
    const objectsInCluster = objects.map(object => {return object.pos.toString() in this.memory.coreCluster || object.pos.toString() in this.clusters})
    if (objectsInCluster.includes(false)) {return false}
    return true
}

Room.prototype.addObjectsToClusters = function (objects) {
    const locations = objects.map(object => object.pos)
    this.addLocationsToClusters(locations)
}

Room.prototype.addLocationsToClusters = function (locations) {
    if (checks.apply(this, [locations])) {throw new Error(`Something wrong in the checks for room ${this.name}`)}
    if (addLocations.apply(this, [locations])) {throw new Error(`Something wrong in addLocations for room ${this.name}`)}
    const clusterToLocations = calculateClusters.apply(this, [])
    calculatePaths.apply(this, [clusterToLocations])
}
const checks = function (locations) {
    if (locations.length === undefined) {
        throw new Error("Expected array not " + String(typeof locations))
    }
    if (locations.length === 0) {
        console.log("No locations are added. Array is empty")
        return true
    }
    console.log("Locations are valid")
}
const addLocations = function (locations) {
    const clusters = this.clusters
    const list = this.memory.coreCluster
    const previous = Object.keys(list).length
    for (let location of locations) {
        if (list[location.toString()] === undefined) {
            list[location.toString()] = -1
        }
    }
    const total = Object.keys(list).length
    const added = total - previous

    if (added <= 0) {
        console.log("No locations are added. Already in memory")
        return false
    }
    console.log(added + " locations are added. Bringing total to " + total)
}
const calculateClusters = function () {
    const distance = 1

    const locationToCluster = {}
    const filteredClusters = {}
    const locationToClusterWithSurroundings = {}
    const centersOfCluster = {}
    const clusterToLocations = {}
    const locations = []

    for (let string in this.memory.coreCluster) {
        locations.push(string.toPos(this))
    }
    for (let index in locations) {
        const location = locations[index]

        clusterToLocations[index] = [location]
        locationToCluster[location.toString()] = index
    }

    for (let index in locations) {
        const location = locations[index]

        for (let i in locations) {
            const comparedLocation = locations[i]
            const comparedLocationString = comparedLocation.toString()
            const comparedLocationCluster = locationToCluster[comparedLocationString]
            const locationsOfCluster = clusterToLocations[comparedLocationCluster]

            if (index === i || locationsOfCluster === undefined || comparedLocationCluster === index) {
                continue
            }

            if (location.inRangeTo(comparedLocation, distance)) {
                clusterToLocations[index].push(...locationsOfCluster)

                for (let loc of locationsOfCluster) {
                    locationToCluster[loc.toString()] = index
                }
            }
        }
    }

    for (let string in locationToCluster) {
        const cluster = locationToCluster[string]

        if (filteredClusters[cluster] === undefined) {
            filteredClusters[cluster] = clusterToLocations[cluster]
        }
    }

    this.memory.coreCluster = Object.assign({}, locationToCluster)

    // For each location, add the surrounding locations to the cluster
    for (let string in locationToCluster) {
        const cluster = locationToCluster[string]
        const location = string.toPos(this)
        let x = location.x
        let y = location.y

        if (x - distance < 0) {x = 1}
        if (x + distance > 49) {x = 48}
        if (y - distance < 0) {y=1}
        if (y + distance > 49) {y=48}

        const surroundingLocations = []
        for (let i = x - distance; i <= x + distance; i += 1) {
            for (let j = y - distance; j <= y + distance; j += 1) {
                const pos = new RoomPosition(i, j, this.name)
                locationToClusterWithSurroundings[pos.toString()] = cluster
                clusterToLocations[cluster].push(pos)
            }
        }
    }

    this.memory.clusters = Object.assign({}, locationToClusterWithSurroundings)

    for (let cluster in filteredClusters) {
        const locations = filteredClusters[cluster]
        const sumX = locations.reduce((sum, location) => {return sum + location.x}, 0)
        const sumY = locations.reduce((sum, location) => {return sum + location.y}, 0)
        const length = locations.length

        const center = new RoomPosition(Math.floor(sumX / length), Math.floor(sumY / length), this.name)

        centersOfCluster[cluster] = center.toString()
    }

    this.memory.centerClusters = Object.assign({}, centersOfCluster)

    console.log("Clusters have been calculated")

    return clusterToLocations
}
const calculatePaths = function (clusterToLocations) {
    const paths = {}
    const centers = this.memory.centerClusters

    // Determine paths from center to center
    for (let clusterFrom in centers) {
        let path = undefined

        paths[clusterFrom] = {}

        for (let clusterTo in centers) {
            if (clusterFrom === clusterTo) {
                continue
            }

            const centerFrom = centers[clusterFrom].toPos(this)
            const centerTo = centers[clusterTo].toPos(this)
            const closestFrom = centerTo.findClosestByPath(clusterToLocations[clusterFrom])
            const closestTo = closestFrom.findClosestByPath(clusterToLocations[clusterTo])

            path = this.findPath(closestFrom, closestTo, {
                maxOps: 1000,
                ignoreCreeps: true,
                serialize:true,
                plainCost: 3,
                range:1
            })

            paths[clusterFrom][clusterTo] = path
        }
    }

    this.memory.pathClusters = Object.assign({}, paths)

    console.log("Paths have been calculated")

}