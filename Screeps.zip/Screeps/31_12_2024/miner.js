const states = require("states")

const miner = {}

const HARVEST = "harvest"

miner.createBody = function (room) {
    return [WORK, WORK, MOVE, MOVE]
}

miner.createMemory = function (harvestSpot, source) {
    const state1 = ["make_path", {headingTo: harvestSpot.toString()}]
    const state2 = ["move_by_path", {}]
    const state3 = [HARVEST, {source}]

    return {stateStack: [state3, state2, state1]}
}

miner.additionalSpawnTime = function (room, body, memory, name, spawn) {
    const path = room.make_path(spawn.pos, memory.stateStack[memory.stateStack.length -1][1]["headingTo"])
    return path.length
}

states[HARVEST] = function () {
    const source = Game.getObjectById(this.stateMemory().source)

    const index = this.harvest(source)

    if (index === ERR_NOT_ENOUGH_RESOURCES) {
        this.idle(source.ticksToRegeneration)
    }
}

module.exports = miner
