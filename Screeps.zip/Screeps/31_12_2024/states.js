const states = {
    "idle": function () {
        return Game.time >= this.stateMemory().idle
    },
    "move_by_path": function () {
        return this.moveByPath(this.stateMemory().path) === -5
    },
    "make_path": function () {
        // const room = this.room
        // const locationToCluster = room.clusters
        // const clusterToPath = room.memory.pathClusters
        // const locationFrom = this.pos
        // const stringLocationFrom = locationFrom.toString()
        // const stringLocationTo = this.stateMemory.headingTo
        // const locationTo = stringLocationTo.toPos(room)
        // const opt = {
        //     maxOps:500
        // }
        //
        // let clusterFrom = -1
        // let clusterTo = -1
        // let pathFromToCluster = ""
        // let middlePath = []
        // let first = {}
        // let last = {}
        // let firstPath = []
        // let lastPath = []
        // let path = []
        //
        // // Find clusterFrom and clusterTo
        // clusterFrom = locationToCluster[stringLocationFrom]
        //
        // clusterTo = locationToCluster[stringLocationTo]
        // if (clusterFrom === clusterTo) {
        //     path = locationFrom.findPathTo(locationTo, opt)
        // }
        // else if (clusterFrom === undefined || clusterTo === undefined) {
        //     path = locationFrom.findPathTo(locationTo)
        // }
        // else {
        //     // Find path from cluster combination
        //     pathFromToCluster = clusterToPath[clusterFrom][clusterTo]
        //
        //     // Deserialize path
        //     middlePath = Room.deserializePath(pathFromToCluster)
        //
        //     // Get first and last position of path
        //     first = middlePath[0]
        //     last = middlePath[middlePath.length - 1]
        //
        //     // Make positions
        //     first = new RoomPosition(first.x, first.y, room.name)
        //     last = new RoomPosition(last.x, last.y, room.name)
        //
        //     // Make path from current location to first position
        //     firstPath = this.pos.findPathTo(first, opt)
        //
        //     // Make path from last position to locationTo
        //     lastPath = last.findPathTo(locationTo, opt)
        //
        //     // Stitch all paths together
        //     middlePath.shift()
        //     path.push(...firstPath)
        //     path.push(...middlePath)
        //     path.push(...lastPath)
        // }

        const path = this.room.make_path(this.pos, this.stateMemory().headingTo, this.stateMemory().opt)

        this.stateMemory(2).path = Room.serializePath(path)

        return true
    }
}

module.exports = states

Object.defineProperty(Room.prototype, "stateStack", {
    get: function () {
        if (this.memory.stateStack === undefined) {
            this.memory.stateStack = []
        }

        return this.memory.stateStack
    }
})

Object.defineProperty(Creep.prototype, "stateStack", {
    get: function () {
        if (this.memory.stateStack === undefined) {
            this.memory.stateStack = []
        }

        return this.memory.stateStack
    }
})

Creep.prototype.state = function (number = 1) {
    const length = this.stateStack.length
    if (length === 0) {
        return undefined
    }

    return this.stateStack[length - number]
}

Creep.prototype.stateMemory = function (number = 1) {
    return this.state(number)[1]
}

Creep.prototype.stateName = function (number = 1) {
    return this.state(number)[0]
}

Creep.prototype.run = function () {
    if (this.state() === undefined) {
        // console.log(`${this.name} is doing nothing`)
    }
    else
    {
        const index = states[this.stateName()].apply(this, [])
        if (index === "busy") {
            console.log(`${this.name} finished ${this.stateName()}`)
            this.stateStack.pop()
        }

        if (index === true) {
            console.log(`${this.name} finished ${this.stateName()}`)
            this.stateStack.pop()
            this.run()
        }
    }
}

Creep.prototype.addState = function (state, memory = {}) {
    if (states[state] === undefined) {
        throw new Error(`${this.name} received an unknown state ${state}`)
    }

    this.stateStack.push([state, memory])
}



Room.prototype.run = Creep.prototype.run
Room.prototype.addState = Creep.prototype.addState
Room.prototype.state = Creep.prototype.state
Room.prototype.stateMemory = Creep.prototype.stateMemory
Room.prototype.stateName = Creep.prototype.stateName