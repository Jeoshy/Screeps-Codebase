const creep = require("creep")

Room.prototype.plan = function () {
    if (this.memory.planPassed === true) {
        return true
    }

    this.memory.debugged = 0

    const checks = [
        spawnPlan.apply(this, []),
        debugg.apply(this, []),
        controllerPlan.apply(this, []),
        debugg.apply(this, []),
        harvestPlan.apply(this, []),
        debugg.apply(this, []),
    ]


    if (checks.includes(false)) {
        console.log(checks)
        return false
    }
    else
    {
        this.memory.planPassed = true
    }

    return true
}

const debugg = function () {
    this.memory.debugged += 1

    console.log(`Check ${this.memory.debugged} `)
    return true
}

const harvestPlan = function () {
    const sources = this.find(FIND_SOURCES)
    const spawns = this.find(FIND_MY_SPAWNS)

    if (spawns.length === 0) {
        return false
    }

    const controller = this.controller
    const distanceOptimizer = controller
    const MAX_SPOTS_PER_SOURCE = 3

    sources.forEach((source) => {
        source.distance = distanceOptimizer.pos.getRangeTo(source)
    })
    sources.sort((a, b) => a.distance - b.distance)

    this.addObjectsToClusters(sources)

    for (let source of sources) {
        const harvestSpots = source.harvestSpots

        this.addLocationsToClusters(harvestSpots)

        // Add the closest harvestSpots to spawn up to 3 to the list
        harvestSpots.forEach((harvestSpot) => {
            harvestSpot.distance = distanceOptimizer.pos.getRangeTo(harvestSpot)
        })

        harvestSpots.sort((a, b) => a.distance - b.distance)
        harvestSpots.length = MAX_SPOTS_PER_SOURCE

        // Each harvestSpot gets a harvester
        const MINER = "miner"
        const CARRIER = "carrier"
        const MINERBody = creep[MINER].createBody()
        const CARRIERBody = creep[CARRIER].createBody(this)

        harvestSpots.forEach((harvestSpot) => {
            this.addHarvestSpot(harvestSpot)

            const MINERMemory = creep[MINER].createMemory(harvestSpot, source.id)
            this.addCreepToSpawnQueue(MINER, MINERMemory, MINERBody)

            const CARRIERMemory = creep[CARRIER].createMemory(harvestSpot)
            this.addCreepToSpawnQueue(CARRIER, CARRIERMemory, CARRIERBody)
        })

    }

    // --- Checks --- //
    return this.areObjectsInClusters(sources);
}

const spawnPlan = function () {
    const spawns = this.find(FIND_MY_SPAWNS)

    this.addObjectsToClusters(spawns)

    this.memory.stateStack = []
    this.addState("normalState")
    this.addState("startState2")
    this.addState("startState1")

    // --- Checks --- //
    return this.areObjectsInClusters(spawns);
}

const controllerPlan = function () {
    const controller = this.controller

    this.addObjectsToClusters([controller])

    // --- Checks --- //
    return this.areObjectsInClusters([controller]);
}