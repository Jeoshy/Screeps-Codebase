const states = require("states")

const carrier = {}

const CARRIER = "carrier"
const CLAIM_ENERGY_SOURCE = "claimEnergySource"
const FREE_TIME = "freeTime"
const GET_ENERGY = "getEnergy"
const MOVE_AND_TRANSFER = "moveAndTransfer"
const CLAIM_LIST_TRANSFERS = "claimListTransfers"
const DISMANTLE = "dismantle"

const DISMANTLE_TIME = 50

carrier.createBodySegment = function (room) {
    /**
     * return body based on conditions
     */
    const roadless = [CARRY, MOVE]
    const road = [CARRY, CARRY, MOVE]

    if (room.memory.roadBuild === true) {
        return road
    }

    return roadless
}

carrier.createBody = function (room) {
    const bodySegment = carrier.createBodySegment(room)
    const energy = room.energyCapacityAvailable
    const countSegment = Math.ceil(energy / room.bodyCosts(bodySegment))
    return Array(countSegment).fill(bodySegment).flat()
}

carrier.createMemory = function (harvestSpot) {
    const stateName = CARRIER
    const state = [stateName, {harvestSpot: harvestSpot.toString()}]

    return {stateStack: [state]}
}

carrier.additionalSpawnTime = function (room, body, memory, name, spawn) {
    return DISMANTLE_TIME
}

states[DISMANTLE] = function () {
    const spawn = this.room.find(FIND_MY_SPAWNS)[0]

    this.say("I will recycle myself")
    if (spawn) {
        const index = spawn.recycleCreep(this)

        if (index === ERR_NOT_IN_RANGE) {
            this.customMoveTo(spawn.pos.toString(), {range: 1})
            return
        }

    }

}

states[CARRIER] = function () {
    const harvestSpot = this.stateMemory().harvestSpot

    this.addState(MOVE_AND_TRANSFER)
    this.addState(CLAIM_LIST_TRANSFERS)
    this.addState(GET_ENERGY, {harvestSpot: harvestSpot})
    this.addState(FREE_TIME, {harvestSpot: harvestSpot})
    this.run()
}

states[FREE_TIME] = function () {
    const location = this.stateMemory().harvestSpot
    const pos = location.toPos(this.room)
    const energy = this.room.lookForAt(LOOK_ENERGY, pos)[0]

    if (this.ticksToLive <= DISMANTLE_TIME) {
        this.addState(DISMANTLE)
        return
    }

    if (energy === undefined || energy.amount - 50 < this.store.getCapacity()) {

        // TODO: program what to do in free time
        return false
    }
    console.log(this.name, energy?.amount + 5, this.store.getCapacity())

    return true
}

states[GET_ENERGY] = function () {
    const location = this.stateMemory().harvestSpot
    const pos = location.toPos(this.room)

    if (this.pos.inRangeTo(pos, 1) === false) {
        this.customMoveTo(location, {range: 1})
        return
    }
    const ID = undefined

    let object = Game.getObjectById(ID)
    if (object === undefined || object === null) {
        const energy = this.room.lookForAt(LOOK_ENERGY, pos)[0]

        if (energy === undefined) {
            return false
        }

        if (energy.amount >= this.store.getCapacity()) {
            this.pickup(energy)
            return true
        }
    }

    // TODO: ADD a state that makes it do something else, when in about so many ticks the source has recovered

    const index = this.withdraw(object, RESOURCE_ENERGY)
    return index === OK || index === ERR_FULL
}

states[MOVE_AND_TRANSFER] = function () {
    const object = Game.getObjectById(this.stateMemory().transferTo)
    const index = this.transfer(object, RESOURCE_ENERGY)

    if (index === ERR_NOT_IN_RANGE) {
        this.customMoveTo(object.pos.toString(), {range: 1})
        return
    }

    if (index === OK && object.store.getFreeCapacity() > this.store.energy) {
        return true
    }

    if (index === -8) {
        this.drop(RESOURCE_ENERGY)
        return true
    }

    if (index === -6) {
        return true
    }
}

states[CLAIM_LIST_TRANSFERS] = function () {
    this.stateMemory(2).transferTo = this.room.find(FIND_MY_SPAWNS)[0].id

    if (this.stateMemory(2).transferTo === undefined) {
        return false
    }

    return true

}

module.exports = carrier