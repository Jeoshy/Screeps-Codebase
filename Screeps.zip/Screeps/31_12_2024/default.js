Object.defineProperty(Room.prototype, "energyCapacityPotential", {
    get: function() {
        const level = this.controller.level
        const potential = {
            0: 0,
            1: 300,
            2: 550,
            3: 800,
            4: 1300,
            5: 1800,
            6: 2300,
            7: 5600,
            8: 12900
        }
        return potential[level]
    }
})

const cost = Object.freeze({
    "tough": 10,
    "move": 50,
    "work": 100,
    "carry": 50,
    "heal": 250,
    "claim": 600
})

Room.prototype.bodyCosts = function (body) {
    if (Array.isArray(body) === false) {
        throw new Error(`Body is being undefined thrown into bodyCosts probably - ${body}`)
    }

    const totalCost = body.reduce((accumulatedSum, bodyPart) => accumulatedSum + cost[bodyPart], 0)
    return totalCost
}

String.prototype.toPos = function (room) {
    if (room === undefined) {
        throw new Error("Expected a room as input for toPos(), got " + room)
    }

    const xy = this.split("x")
    return new RoomPosition(xy[0], xy[1], room.name)
}

RoomPosition.prototype.toString = function () {
    return String(this.x) + "x" + String(this.y)
}

Object.defineProperty(Room.prototype, "clusters", {
    get: function () {
        if (!this.memory.clusters) {
            console.log("Set cluster memory of room ", this.name)
            this.memory.clusters = {}
            this.memory.coreCluster = {}
            this.memory.centerClusters = {}
            this.memory.pathClusters = {}
        }

        return this.memory.clusters
    },
    set: function (object) {
        if (typeof object !== Object) {
            throw new Error("New value of clusters is not an object, but ", typeof dict)
        }
        this.memory.clusters = object
    }
})

Object.defineProperty(Source.prototype, "memory", {
    configurable:true,
    get: function () {
        if (_.isUndefined(Memory.sources)) {
            Memory.sources = {}
        }
        if (!_.isObject(Memory.sources)) {
            return undefined
        }

        return Memory.sources[this.id] = Memory.sources[this.id] || {}
    },
    set: function(value) {
        if (_.isUndefined(Memory.sources)) {
            Memory.sources = {}
        }
        if (!_.isObject(Memory.sources)) {
            throw new Error('Could not set source memory');
        }

        Memory.sources[this.id] = value
    }
})

Object.defineProperty(Source.prototype, "harvestSpots", {
    get: function () {
        const harvestSpots = []

        if (!this.memory.harvestSpots) {
            this.memory.harvestSpots = ""
            const x = this.pos.x
            const y = this.pos.y
            const stringifiedPositions = []

            let tiles = this.room.lookAtArea(y - 1, x - 1, y + 1, x + 1, true)
            tiles = tiles.filter((tile) => (tile.type === "terrain" && tile.terrain !== "wall"))
            tiles.forEach((tile) => stringifiedPositions.push(tile.x + "x" + tile.y))

            this.memory.harvestSpots = stringifiedPositions
        }

        this.memory.harvestSpots.forEach((spot) => harvestSpots.push(spot.toPos(this.room)))

        return harvestSpots
    },
    enumerable: true,
    configurable: true
})

Object.defineProperty(Source.prototype, "highest", {
    get: function () {

    }
})