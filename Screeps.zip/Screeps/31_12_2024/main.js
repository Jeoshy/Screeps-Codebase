console.log("Caching...")

require("creep")
require("default")
require("clustering")
require("room")
require("id_system")
const planning = require("planning")
const states = require("states")

console.log("Caching done")

module.exports.loop = function () {
    console.log(Game.time)
    if (Memory.resetted === undefined) {
        Memory = {
            creeps: {},
            rooms: {},
            spawns:{}
        }
        Memory.resetted = true

        for (let roomName in Game.rooms) {
            Memory.rooms[roomName] = {}
        }
    }

    for (let roomName in Game.rooms) {
        const room = Game.rooms[roomName]
        let spawn = room.find(FIND_MY_SPAWNS)
        room.plan()

        // for (let spot of room.harvestSpots) {
        //     const [bla, bla2, bla3, location] = spot
        //     const pos = location.toPos(room)
        //     const path = room.findPath(room.controller.pos, pos)
        //     const length = path.length
        //     const energy_per_second = 3
        //     const carriers_per_source = 1
        //     const CARRY = energy_per_second * length * 2 / carriers_per_source
        //     const CARRIED = Math.floor(CARRY / 50) * 50
        //     const WASTE = Math.ceil((CARRY - CARRIED) * (300 / (length * 2)))
        //
        //     new RoomVisual(room.name).text(`${length}`, pos, {color: 'green', font: 0.5});
        //
        //
        //
        // }

        room.run()

    }

    for (let creepName in Game.creeps) {
        const creep = Game.creeps[creepName]
        if (creep.spawning === true) {
            continue
        }

        const stateStack = creep.stateStack
        let offset = 0.5
        for (let state of stateStack) {
            offset += 1
            new RoomVisual(creep.room.name).text(state[0], creep.pos.x, creep.pos.y + offset)
        }

        creep.run()
    }

    let room = Game.rooms["sim"]

    const flags = Game.flags
    const flagLocations = []
    for (let index in flags) {
        flagLocations.push(flags[index].pos)
    }

    // room.addLocationsToClusters(flagLocations)

    const locationToCluster = room.clusters
    for (let location in locationToCluster) {
        const cluster = locationToCluster[location]
        new RoomVisual(room.name).text(cluster, location.toPos(room), {color: 'black', font: 1});
    }

    const centers = room.memory.centerClusters
    for (let cluster in centers) {
        const center = centers[cluster]

        new RoomVisual(room.name).text(cluster, center.toPos(room), {color: 'red', font: 1});
    }

    const paths = room.memory.pathClusters
    for (let clusterFrom in paths) {
        for (let clusterTo in paths[clusterFrom]) {
            const pathSerialized = paths[clusterFrom][clusterTo]
            const path = Room.deserializePath(pathSerialized)

            for (let object of path) {
                const pos = new RoomPosition(object.x, object.y, room.name)
                new RoomVisual(room.name).text(clusterFrom + "" + clusterTo, pos, {color: 'blue', font: 0.5});
            }
        }
    }

    const sources = room.find(FIND_SOURCES)
    for (let source of sources) {
        const harvestSpots = source.harvestSpots
        for (let spot of harvestSpots) {
            new RoomVisual(room.name).circle(spot, {fill: 'red'});
        }
    }
}