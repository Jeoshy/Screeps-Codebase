const states = require("states")
const miner = require("miner")
const carrier = require('carrier')

module.exports = {
    "miner": miner,
    "carrier": carrier,
}

Room.prototype.createName = function () {
    return `${this.name} ${Game.time}`
}

Creep.prototype.customMoveTo = function (location, opt = {}) {
    if (typeof location !== "string") {
        throw new Error(`Expected string for location not, ${location}`)
    }

    this.addState("move_by_path")
    this.addState("make_path", {headingTo: location, opt: opt})
    this.run()
    this.run()
}

Creep.prototype.idle = function (idleTime) {
    this.addState("idle", {"idle": Game.time + idleTime})
}

