const states = require("states")
const creep = require("creep")

const SPAWNQUEUE = "spawnQueue"
const HARVESTSPOTS = "harvestSpots"

// -- Increment dictionary-- //
/**
 * Can increment any list
 */

Object.defineProperty(Room.prototype, "incrementals", {
    get: function () {
        if (this.memory.incrementals === undefined) {
            this.memory.incrementals = {}
        }
        return this.memory.incrementals
    }
})

Room.prototype.increment = function (name) {
    if (this.incrementals[name] === undefined) {
        this.incrementals[name] = 0
    }

    this.incrementals[name] += 1
    if (this.incrementals[name] > this[name].length -1) {
        this.incrementals[name] = 0
    }
}

Room.prototype.current = function (name) {
    if (this.incrementals[name] === undefined) {
        this.incrementals[name] = 0
    }

    return this[name][this.incrementals[name]]
}

// --- Spawn process --- //
/**
 * See at spawnIndex timeOfDeath - body.time is smaller or equal to Game.time or undefined
 * If false, give state that idles the stateStack for Game.time - timeOfDeath + body.time
 * If true, get the creep type of spawnIndex in spawnQueue
 * The body and initial memory are in the type's file
 * Spawn the creep
 * If given index is OK, then increment spawnIndex
 * If spawnIndex is bigger than the spawnQueue - 1, then set spawnIndex to 0
 */

Object.defineProperty(Room.prototype, SPAWNQUEUE, {
    get: function () {
        if (this.memory.spawnManager === undefined) {
            this.memory.spawnManager = []
        }

        return this.memory.spawnManager
    }
})

Object.defineProperty(Room.prototype, "creepToSpawn", {
    get: function () {
        // TODO: Change the packed string of body into an array

        return this.spawnQueue[this.incrementals[SPAWNQUEUE]]
    }
})

Room.prototype.addCreepToSpawnQueue = function (type, memory = {}, body = creep[type].createBody(this)) {
    const timeToSpawn = 0

    if (Array.isArray(body) === false) {
        throw Error(`The creep type ${type} has this body ${body}`)
    }
    // TODO: Pack body into string, instead of array

    this.spawnQueue.push([timeToSpawn, type, body, memory])
}


Room.prototype.getAvailableSpawn = function () {
    // TODO: Make filter to get spawns that are not doing something
    return this.find(FIND_MY_SPAWNS)[0]
}

Room.prototype.spawn = function (
    type,
    body = creep[type].createBody(this),
    memory = creep[type].createMemory(this),
    name = `${Game.time}_${type}_${this.name}`,
    spawn = this.getAvailableSpawn(),
) {
    const spawnTime = (creepType, creepMemory) => Game.time + 1500 - creep[creepType].additionalSpawnTime(this, body, memory, name, spawn)

    if (Array.isArray(body) === false || memory === undefined || name === undefined) {
        throw new Error(`Creep ${type} has name: ${name}, body ${body} and memory: ${memory}`)
    }
    const index = spawn.spawnCreep(body, name, {memory: memory})

    if (index === OK || index === ERR_NAME_EXISTS) {
        return [index, spawnTime(type, memory)]
    }

    return [false, false]
}

// --- Add harvestSpots --- //
/**
 * An element in harvestSpot contains:
 * ToHarvest: time to harvest, otherwise continue. Default 0
 * ID: creep or container
 * Location: roomPosition
 *
 * The function beneath calculates the toHarvest time
 */

Room.prototype.addHarvestSpot = function (harvestSpot, id = undefined) {
    let ID = id
    const location = harvestSpot.toString()

    this.harvestSpots.push([ID, location])
}

Object.defineProperty(Room.prototype, HARVESTSPOTS, {
    get: function () {
        if (this.memory.harvestSpots === undefined) {
            this.memory.harvestSpots = []
        }
        return this.memory.harvestSpots
    },
})

// --- Room states --- //
/**
 * The first state get the information for first miner, passes through the spawntime manually and then increments
 * Spawns in 200 energy miner
 * All following carriers are 100 energy
 * Resume normal state
 */

states["startState1"] = function () {
    this.incrementals[SPAWNQUEUE] = 0
    let [spawnTime, creepType, body, memory] = this.current(SPAWNQUEUE)

    const [index, toSpawn] = this.spawn(creepType, body, memory, `firstHarvester${this.name}`)
    if (index === OK || index === ERR_NAME_EXISTS) {
        this.current(SPAWNQUEUE)[0] = toSpawn
        this.increment(SPAWNQUEUE)
        return "busy"
    }
}

states["startState2"] = function () {
    let [spawnTime, creepType, body, memory] = this.current(SPAWNQUEUE)
    body = [CARRY, MOVE]

    const [index, toSpawn] = this.spawn(creepType, body, memory, `firstCarrier${this.name}`)
    if (index === OK || index === ERR_NAME_EXISTS) {
        return "busy"
    }
}

states["normalState"] = function () {
    const [spawnTime, creepType, body, memory] = this.current(SPAWNQUEUE)

    if (creepType === undefined) {
        console.log(`This creep type |${creepType}| is trying to spawn and doesn't exist yet`)
        return
    }

    if (spawnTime <= Game.time) {
        const [index, toSpawn] = this.spawn(creepType, body, memory)

        if (index === OK) {
            this.creepToSpawn[0] = toSpawn
            this.increment(SPAWNQUEUE)
        }
    }
    else
    {
        this.addState("idle", {idle: spawnTime})
    }
}

// --- Make path --- //
Room.prototype.make_path = function (pos, headingTo, lastOpt = {}) {
    const room = this
    const locationToCluster = room.clusters
    const clusterToPath = room.memory.pathClusters
    const locationFrom = pos
    const stringLocationFrom = locationFrom.toString()
    const stringLocationTo = headingTo
    const locationTo = stringLocationTo.toPos(room)
    const opt = {
        maxOps:500,
    }
    lastOpt.costCallBack = function (roomName, costMatrix) {
        const room = Game.rooms[roomName]
        const harvestSpots = room[HARVESTSPOTS]

        for (let spot of harvestSpots) {
            const [toHarvest, timeHarvest, ID, location] = spot
            const pos = location.toPos(room)
            costMatrix.set(pos.x, pos.y, 255)
        }
    }

    let clusterFrom = -1
    let clusterTo = -1
    let pathFromToCluster = ""
    let middlePath = []
    let first = {}
    let last = {}
    let firstPath = []
    let lastPath = []
    let path = []

    // Find clusterFrom and clusterTo
    clusterFrom = locationToCluster[stringLocationFrom]

    clusterTo = locationToCluster[stringLocationTo]
    if (clusterFrom === clusterTo) {
        path = locationFrom.findPathTo(locationTo, lastOpt)
    }
    else if (clusterFrom === undefined || clusterTo === undefined) {
        path = locationFrom.findPathTo(locationTo)
    }
    else {
        // Find path from cluster combination
        pathFromToCluster = clusterToPath[clusterFrom][clusterTo]

        // Deserialize path
        middlePath = Room.deserializePath(pathFromToCluster)

        // Get first and last position of path
        first = middlePath[0]
        last = middlePath[middlePath.length - 1]

        // Make positions
        first = new RoomPosition(first.x, first.y, room.name)
        last = new RoomPosition(last.x, last.y, room.name)

        // Make path from current location to first position
        firstPath = pos.findPathTo(first, opt)

        // Make path from last position to locationTo
        lastPath = last.findPathTo(locationTo, lastOpt)

        // Stitch all paths together
        middlePath.shift()
        path.push(...firstPath)
        path.push(...middlePath)
        path.push(...lastPath)
    }
    return path
}