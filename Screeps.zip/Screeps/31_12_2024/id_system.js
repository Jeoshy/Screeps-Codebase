Object.defineProperty(Room.prototype, "idSystem", {
    get: function () {
        if (this.memory.idSystem === undefined) {
            this.memory.idSystem = {}
        }

        return this.memory.idSystem
    }
})

Room.prototype.makeIdList = function (idList, length) {
    const list = []
    list.length = length
    this.idSystem[idList] = list
}

Room.prototype.fillInId = function (idList, id) {
    const list = this.idSystem[idList]

    for (let index in list) {
        const vacancy = list[index]

        const object = Game.getObjectById(vacancy)

        if (object === undefined || object === null) {
            list[index] = id
            return index
        }
    }

    return undefined
}

Room.prototype.getAvailabeIndex = function (idList) {
    const list = this.idSystem[idList]

    for (let index in list) {
        const vacancy = list[index]
        if (vacancy === "busy") {
            continue
        }

        const object = Game.getObjectById(vacancy)

        if (object === undefined) {
            return index
        }
    }

    return undefined
}