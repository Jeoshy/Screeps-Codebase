const heap = require("minHeap")
const union = require("unions")
const creep = require("creep")
const {insertTimer} = require("./timers");

// ----- transport ----- //

Object.defineProperty(Room.prototype, "reservations", {
    get : function () {
        if (this.memory.reservations === undefined) {
            this.memory.reservations = []
        }

        if (this.proxy_reservations === undefined){
            this.proxy_reservations = true
            for (const reservation of this.memory.reservations) {
                reservation.valueOf = function () {
                    return this.time
                }
            }
        }

        return this.memory.reservations
    }
})

// ----- spawn ----- //

Object.defineProperty(Spawn.prototype, "memorySpawn", {
    configurable:true,
    get: function () {

        if (Memory.spawns[this.name] === undefined) {
            Memory.spawns[this.name] = {}
        }

        return Memory.spawns[this.name]
    },
})

Object.defineProperty(Spawn.prototype, "queue", {
    get: function () {
        if (this.memorySpawn.queue === undefined) {
            this.memorySpawn.queue = []
        }



        if (this.proxy_queue === undefined){
            this.proxy_queue = true
            for (const creep of this.memorySpawn.queue) {
                creep.valueOf = function () {
                    return this.time
                }
            }
        }

        return this.memorySpawn.queue
    }
})

// ----- mineLocations ----- //

Room.prototype.addMineLocation = function (time, source, location, spawn, travelToSpawn) {
    const mineLocation = {
        time: time,
        source: store(source, locationTypes.OBJECT),
        location: store(location, locationTypes.LOCATION),
        spawn: store(spawn, locationTypes.OBJECT),
        travelToSpawn: travelToSpawn,
        valueOf() {
            return this.time
        }
    }

    heap.insert(this.mineLocations, mineLocation)
}

Room.prototype.assignMineLocation = function (mineLocation = this.nextMineLocation, ticksToLive = 1500) {
    // 3 * 24 / this.mineLocations is the time spend on spawning in a miner creep
    // 1 body part takes 3 ticks to spawn in
    // Their needs at least 6 work parts per source with each work part having 1 move part
    // In total 24 parts distributed over a certain amount this.mineLocations. There can be 6, 4 or 2 mineLocations.
    mineLocation.time = Game.time + ticksToLive - 3 * 24 / this.mineLocations.length - mineLocation.travelToSpawn
    heap.minHeapify(this.mineLocations, 0)
    return mineLocation
}

Object.defineProperty(Room.prototype, "mineLocations", {
    get: function () {
        if (this.memory.mineLocations === undefined) {
            this.memory.mineLocations = []
        }

        if (this.proxy_mineLocations === undefined) {
            this.proxy_mineLocations = true
            for (const loc of this.memory.mineLocations) {
                loc.valueOf = function () {
                    return loc.time
                }
            }
        }

        return this.memory.mineLocations
    }
})

Object.defineProperty(Room.prototype, "nextMineLocation", {
    get: function () {
        return this.mineLocations[0]
    }
})