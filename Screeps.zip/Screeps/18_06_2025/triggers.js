// Everytime a room levels up, it has a default trigger plan. A trigger plan is a list of actions
// to be taken by the room. Only the most upper action gets triggered if conditions are met.
// Then the next upper is in line. A trigger is made of a condition and action

const CONDITIONS = {
    SPAWN: "conditionSpawn",
}

const ACTION = {
    MINING_LOCATIONS: "miningLocations"
}

module.exports = {
    [CONDITIONS.SPAWN]: function () {
        const spawn = this.find(FIND_SPAWN)
        return spawn.length > 0
    },
    [ACTION.MINING_LOCATIONS]: function (sorter = defaultSorter) {
        harvestSpotSelection(sorter, 3)
    }

}





const harvestSpotSelection = function (sorter = defaultSorter, max = 3) {
    const sources = this.find(FIND_SOURCES)

    let harvestSpots = []

    for (let s of sources) {
        let spots = sources.harvestSpots
        spots = sorter.apply(this, spots)
        spots.length = max
        harvestSpots.push(spots)
    }

    return harvestSpots
}

const defaultSorter = function (list) {
    return list
}

Room.prototype.addTrigger = function (condition, action) {
    this.triggers.splice(0, 0, [condition, action])
}

Object.defineProperty(Room.prototype, "triggers", {
    get: function () {
        if (!this.memory.triggers) {
            this.memory.triggers = []
        }

        return this.memory.triggers
    }
})

Object.defineProperty(Source.prototype, "harvestSpots", {
    get: function () {
        const harvestSpots = []

        if (!this.memory.harvestSpots) {
            this.memory.harvestSpots = ""
            const x = this.pos.x
            const y = this.pos.y
            const stringifiedPositions = []

            let tiles = this.room.lookAtArea(y - 1, x - 1, y + 1, x + 1, true)
            tiles = tiles.filter((tile) => (tile.type === "terrain" && tile.terrain !== "wall"))
            tiles.forEach((tile) => stringifiedPositions.push(tile.x + "x" + tile.y))

            this.memory.harvestSpots = stringifiedPositions
        }

        this.memory.harvestSpots.forEach((spot) => harvestSpots.push(spot.toPos(this.room)))

        return harvestSpots
    },
    enumerable: true,
    configurable: true
})