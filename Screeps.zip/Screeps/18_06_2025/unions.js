const creepMaker = require("./creep");
const heap = require("minHeap")
const {extractMin} = require("./minHeap");
const missions = require("creepMissions")

const union = {
    miner: {},
    spawn: {},
    carrier: {},
}

// ----- Carrier Union ----- //

global.transportTypes = {
    SUPPLY: "supply",
    DEMAND: "demand"
}

union.carrier.register = function (type, location, base) {
    if (Memory[transportTypes.SUPPLY] === undefined) {
        Memory[transportTypes.SUPPLY] = {}
        Memory[transportTypes.DEMAND] = {}
    }

    const stringlocation = store(location, locationTypes.LOCATION)[0]

    if (typeof base !== "string") {
        console.log("The carrier union did not get a name for base", base, typeof base)
        return false
    }

    Memory[type][stringlocation] = base

    return OK
}

union.carrier.reserve = function (creep, amount) {

}

// ----- Spawn Union ----- //

union.spawn.run = function (room) {
    const spawns = room.find(FIND_MY_SPAWNS)
    for (const spawn of spawns) {
        if (spawn.queue.length > 0) {
            const creep = heap.minimum(spawn.queue)
            const memory = creep.memory
            const body = creep.body
            const name = creep.name

            const response = spawn.spawnCreep(body, name, {memory: memory})
            console.log(response)
            if (response === OK) {
                heap.extractMin(spawn.queue)
            }

        }
    }
}

union.spawn.request = function (spawn, creep, value) {
    // const memory = creep.memory
    // const body = creep.body
    // const name = creep.name
    //
    // const response = spawn.spawnCreep(body, name, {memory: memory})
    // if (response !== OK) {
    //     creep.time = Game.time
    //     heap.insert(spawn.queue, creep)
    // }
    creep.time = value
    creep.valueOf = function () {
        return this.time
    }
    heap.insert(spawn.queue, creep)
}

union.spawn.initialize = function (room) {
    const mineLocation = room.nextMineLocation
    const spawn = retrieve(mineLocation?.spawn)

    const miner = creepMaker[creepTypes.MINER](mineLocation.location, mineLocation.source)
    miner.body = [WORK, MOVE]
    room.assignMineLocation()

    const carrier = creepMaker[creepTypes.CARRIER]()
    carrier.body = [CARRY, CARRY, MOVE, MOVE]

    union.spawn.request(spawn, miner, 0)
    union.spawn.request(spawn, carrier, 1)
}

// ----- Miner Union ----- //

union.miner.run = function (room) {
    const mineLocation = room.nextMineLocation
    if (mineLocation.time < Game.time) {
        const spawn = retrieve(mineLocation?.spawn)
        const creep = creepMaker[creepTypes.MINER](mineLocation.location, mineLocation.source)
        const memory = creep.memory
        const body = creep.body
        const name = creep.name
        if (spawn.spawning === null && spawn.queue.length === 0) {
            if (spawn.spawnCreep(body, name, {memory: memory}) === OK) {
                room.assignMineLocation()
            }
        }
        else
        {
            const mission = missions[creepMissions.SETUPMINING](room)
            memory.missions.splice(memory.missions.length - 1, 0, mission)
            union.spawn.request(spawn, creep, mineLocation.time)
        }
    }

}

union.miner.setMineLocation = function(room, amount) {
    // Clear mineLocations memory
    room.memory.mineLocations = []

    // For each source, get the all the miningLocations and find the closest spawn for each location.
    // Then sort which amount of miningLocations are the closest. Then add them to the room.
    const sources = room.find(FIND_SOURCES)
    for (const source of sources) {
        // First, find all available empty locations next to sources
        // Second, find closest spawn with find closest by path
        // Third, then sort them on travel distance
        // Fourth, store the correct amount

        const x = source.pos.x
        const y = source.pos.y

        let tiles = room.lookAtArea(y - 1, x - 1, y + 1, x + 1, true)
        tiles = tiles.filter((tile) => (tile.type === "terrain" && tile.terrain !== "wall"))
        tiles.forEach((tile) => {
            const pos = new RoomPosition(tile.x, tile.y, room.name)
            const spawn = pos.findClosestByPath(FIND_MY_SPAWNS, {algorithm: "astar"})
            tile.spawn = spawn
            tile.travelTimeToSpawn = pos.findPathTo(spawn).length
            tile.pos = pos
        })
        tiles.sort((a, b) => a.travelTimeToSpawn - b.travelTimeToSpawn)
        tiles.length = amount

        for (const tile of tiles) {
            if (tile === undefined) {
                continue;
            }
            room.addMineLocation(tile.travelTimeToSpawn, source, tile.pos, tile.spawn, tile.travelTimeToSpawn)
        }
    }
}



module.exports = union