global.creepTypes = {
    MINER: "miner",
    CARRIER: "carrier",
}

const missions = require("creepMissions")
const creepStates = require("./creepStates");

module.exports = {
    run: function (creep) {

        if (creep.missions.length === 0) {
            return undefined
        }
        else if (creep.state === undefined) {
            creep.nextMission()
            creep.memory = {missions: creep.missions, logging: creep.logging}
            Object.assign(creep.memory, creep.missionMemory)
            creep.logging = "-"
            this.run(creep)
        }
        else if (creepStates[creep.state] !== undefined)
        {
            const response = creepStates[creep.state].apply(creep, [])
            if (response === OK || response === true) {
                creep.logging = creep.nextState()
                this.run(creep)
            }
        }
    },
    [creepTypes.MINER]: function (mineLocation, source) {
        const creep = createNewCreep("miner")
        const harvestMission = missions[creepMissions.HARVEST](mineLocation, source)
        addMission(harvestMission, creep)

        // TODO: Add body based on room level
        addBody([MOVE], creep)

        return finishCreep(creep)
    },
    [creepTypes.CARRIER]: function () {
        const creep = createNewCreep("carrier")
        const transportMission = missions[creepMissions.TRANSPORT]()
        addMission(transportMission, creep)
        return finishCreep(creep)
    }
}

const createNewCreep = function (extra = "") {
    // Todo: Generate name
    const randomName = "dsjfsdjf" + String(Game.time) + String(extra)

    return {memory:{missions:[]}, body: [], name: randomName}
}
const finishCreep = function (creep) {
    addMission(missions[creepMissions.INITIAL](), creep)
    return creep
}
global.addMission = function (mission, creep) {
    creep.memory.missions.push(mission)
}

global.addBody = function (body, creep) {
    creep.body = body
}