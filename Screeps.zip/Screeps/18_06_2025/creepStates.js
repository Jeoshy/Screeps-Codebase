global.creepStates = {
    MOVETO: "moveTo",
    MINE: "mine",
    SETUP: "setup",
    SETUPMINING: "mineLocationSetup"
}

const heap = require("minHeap")

module.exports = {
    [creepStates.SETUP]: function () {
        return OK
    },
    [creepStates.SETUPMINING]: function () {
        console.log("hello", this.timer, this.name)
        if (this.timer !== undefined) {
            this.timer.time = Game.time + this.ticksToLive - this.timer.travelToSpawn
            this.timer.valueOf = function () {
                return this.time
            }
            const roomName = this.timer.location[0].split("x")[2]
            heap.insert(Game.rooms[roomName].mineLocations, this.timer)
            return OK
        }
        console.log("where is timer???")
    },
    [creepStates.MOVETO]: function () {
        this.moveTo(this.destination)

        // TODO: Tell creeps in the way to dismantle themselves on final destination

        return this.pos.isEqualTo(this.destination)
    },
    [creepStates.MINE]: function () {
        this.harvest(this.source)

        // Register a succesful harvest
    }
}