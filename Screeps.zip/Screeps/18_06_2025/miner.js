const {insertTimer} = require("timers")
require("roomPlanning")
require("creepMemory")

module.exports = {
    assignMineLocation: function () {
        if (this.room.nextMineLocation && Game.time >= this.room.nextMineLocation.time) {
            const mineLocation = this.room.mineLocations.pop()

            // mineLocation.time = Game.time + this.ticksToLive - this.body.length * 3 - mineLocation.travelTimeToClosestSpawn
            mineLocation.time = Game.time + this.ticksToLive - mineLocation.travelTimeToClosestSpawn
            insertTimer(this.room.mineLocations, mineLocation)

            this.source = [mineLocation.source, locationTypes.ID]
            this.destination = [mineLocation.loc, locationTypes.STRING]

        }
    }
}