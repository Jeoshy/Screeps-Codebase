
// ----- Log ----- //

Object.defineProperty(Creep.prototype, "logging", {
    get: function () {
        if (this.memory.logging === undefined) {
            this.memory.logging = "Sequence:"
        }

        return this.memory.logging
    },
    set: function (value) {
        this.memory.logging = `${this.logging} ${value}`
    }
})

// ----- Missions ----- //

Creep.prototype.nextMission = function () {
    return this.missions.pop()
}
Creep.prototype.nextState = function () {
    return this.states.pop()
}
Object.defineProperty(Creep.prototype, "missionMemory", {
    get: function () {
        return this.mission.memory
    }
})
Object.defineProperty(Creep.prototype, "states", {
    get: function () {
        return this.mission?.states
    }
})
Object.defineProperty(Creep.prototype, "state", {
    get: function () {
        return this.states?.[this.states.length - 1]
    }
})
Object.defineProperty(Creep.prototype, "mission", {
    get: function () {
        return this.missions?.[this.missions.length - 1]
    }
})
Object.defineProperty(Creep.prototype, "missions", {
    get: function () {
        if (this.memory.missions === undefined) {
            this.memory.missions = []
        }

        return this.memory.missions
    }
})

// ----- Locations ----- //

global.creepMemory = {
    PICKUP: "pickupLocation",
    TRANSFER: "transferLocation",
    DESTINATION: "destination",
    SOURCE: "source",
    TIMER: "timer"
}

global.locationTypes = {
    ID: "id",
    OBJECT: "object",
    LOCATION: "location",
    STRING: "string",
    STRINGLOCATION: "stringLoc",
    ENTITY: "entity"
}

Object.defineProperty(Creep.prototype, "creepMemory", {
    get: function () {
        if (this.memory.creepMemory === undefined) {
            this.memory.creepMemory = []
        }

        return this.memory.creepMemory
    }
})
for (const key in creepMemory) {
    const location = creepMemory[key]

    Object.defineProperty(Creep.prototype, location, {
        get: function () {
            if (this.memory[location] === undefined) {
                return undefined
            }
            else {
                return retrieve(this.memory[location])
            }
        },
        set: function (data) {
            const loc = data.loc
            const type = data.type

            this.memory[location] = store(loc, type)
        }
    })
}

global.store = function (location, type) {
    let loc = location

    // if (type === locationTypes.ID) {
    //     loc = loc
    // }
    if (type === locationTypes.OBJECT) {
        loc = loc.id
        type = locationTypes.ID
    }
    if (type === locationTypes.LOCATION) {
        loc = String(loc.x) + "x" + String(loc.y) + "x" + String(loc.roomName)
        type = locationTypes.STRINGLOCATION
    }
    // if (type === locationTypes.STRING) {
    //     loc =  loc
    // }
    // if (type === locationTypes.STRINGLOCATION) {
    //     loc =  loc
    // }

    return [loc, type]
}

global.retrieve = function (data) {
    const type = data[1]
    const loc = data[0]

    if (type === undefined) {
        return data
    }
    if (type === locationTypes.ID) {
        return Game.getObjectById(loc)
    }
    if (type === locationTypes.STRINGLOCATION) {
        const xyroom = loc.split("x")
        return new RoomPosition(xyroom[0], xyroom[1], xyroom[2])
    }
    if (type === locationTypes.STRING) {
        return loc
    }
    return loc
}