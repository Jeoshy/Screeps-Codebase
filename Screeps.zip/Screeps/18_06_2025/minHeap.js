const left = function (i) {
    return ((i + 1) * 2) - 1
}
const right = function (i) {
    return ((i + 1) * 2)
}

const parent = function (i) {
    return Math.floor((i+1) / 2) - 1
}

const minHeapify = function (A, i) {
    // In context of parent and its two children
    let smallest = i
    if (left(i) <= A.length && A[left(i)] < A[i]) {
        smallest = left(i)
    }
    if (right(i) <= A.length && A[right(i)] < A[smallest]) {
        smallest = right(i)
    }
    if (smallest !== i) {
        [A[i], A[smallest]] = [A[smallest], A[i]]
        // The current index of i is on index right(i) or index left(i) not on i anymore. So don't take i and smallest serious
        minHeapify(A, smallest)
    }
}

const minimum = function (A) {
    return A[0]
}

const extractMin = function (A) {
    if (A.length < 1) {
        return undefined
    }
    if (A.length  === 1) {
        return A.pop()
    }
    min = A[0]
    A[0] = A.pop()
    minHeapify(A, 0)
    return min
}

const insert = function (A, value) {
    A.push(Game.time + 99999999999)
    decreaseValue(A, A.length -1, value)
}

const decreaseValue = function (A, i, newValue) {
    if (A[i] < newValue) {
        throw Error("Tried to increase a value in maxHeap")
    }

    A[i] = newValue
    while (i > 0 && A[parent(i)] > A[i]) {
        [A[i], A[parent(i)]] = [A[parent(i)], A[i]]
        i = parent(i)
    }
}

const increaseValue = function (A, i, newValue) {
    A[i] = newValue
    while (A[right(i)] < A[i] || A[left(i)] < A[i]) {
        if (A[left(i)] < A[i]) {
            [A[i], A[left(i)]] = [A[left(i)], A[i]]
            i = left(i)
        }
        else
        {
            [A[i], A[right(i)]] = [A[right(i)], A[i]]
            i = right(i)
        }
    }
}

const search = function (A, i, limit) {
    if (A[i] < limit) {
        // return [...A[i], ...search(A, limit, right(i)), ...search(A, limit, left(i))]
        return [A[i]].concat(search(A, left(i), limit)).concat(search(A, right(i), limit))
    }
    else
    {
        return []
    }
}

module.exports = {
    minimum: minimum,
    extractMin: extractMin,
    insert: insert,
    decreaseValue: decreaseValue,
    increaseValue: increaseValue,
    search: search,
    minHeapify:minHeapify,
}

