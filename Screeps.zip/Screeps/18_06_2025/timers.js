module.exports = {
    insertTimer: function (arr, timer, memoryLocation = arr) {
        let i = 0
        let j = arr.length - 1
        let index = 0
        const time = timer.time

        while (j-i > 1) {
            index = (i+j) /2
            if (time < arr[Math.ceil(index)].time) {
                i = Math.ceil(index)
            }
            else if (time > arr[Math.floor(index)].time) {
                j = Math.floor(index)
            }
            else
            {
                i = Math.floor(index)
                j = Math.ceil(index)
            }

        }

        if (time > arr[j].time) {
            if (time > arr[i].time)
            {
                memoryLocation.splice(i, 0, timer)
            }
            else
            {
                memoryLocation.splice(j, 0, timer)
            }
        }
        else
        {
            memoryLocation.splice(j + 1, 0, timer)
        }
    }
}

const sourceTimers = function (sources) {
    for (source of sources) {
        update_list(source.timers)
    }
}

const update_list = function (list_of_timers) {
    return checkTime(list_of_timers[0])
}

const checkTime = function (timer) {
    return timer.time <= Game.time;
}