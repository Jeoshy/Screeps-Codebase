const {extractMin} = require("./minHeap");
global.creepMissions = {
    HARVEST: "harvest",
    TRANSPORT: "transport",
    INITIAL: "initial",
    SETUPMINING: "setupmining",
}

module.exports = {
    [creepMissions.INITIAL]: function () {
        const mission = createNewMission()
        addState(creepStates.SETUP, {}, mission)
        return mission
    },
    [creepMissions.SETUPMINING]: function (room) {
        const mission = createNewMission()
        const timer = extractMin(room.mineLocations)

        addState(creepStates.SETUPMINING, {[creepMemory.TIMER]: timer}, mission)
        return mission
    },
    [creepMissions.HARVEST]: function (mineLocation, source) {
        const mission = createNewMission()
        addState(creepStates.MINE, {[creepMemory.SOURCE]: source}, mission)
        addState(creepStates.MOVETO, {[creepMemory.DESTINATION]: mineLocation}, mission)
        return mission
    },
    [creepMissions.TRANSPORT]: function () {
        const mission = createNewMission()

        return mission
    }
}

const createNewMission = function () {
    return {states: [], memory: {}}
}
global.addState = function (stateName, memory, mission) {
    // AddState assumes that all the memory added is already been processed by store

    Object.assign(mission.memory, memory)
    mission.states.push(stateName)
}


