require("roomPlanning")
require("creepMemory")
require("roomMemory")
const heap = require("minHeap")
const union = require("unions")

const creepMaker = require("creep")

const switchArr = function (arr, i, j, memoryLocation = undefined) {
    [arr[i], arr[j]] = [arr[j], arr[i]]

    if (memoryLocation !== undefined) {
        memoryLocation = arr
    }
}

// const creep = Game.creeps["Test"]
// creep.missions[0] = {states: ["mine", "moveTo"], memory: {}}
// creep.destination = {type: "string", loc: "34x21xsim"}
// creep.source = {type: "id", loc: "0453ca7f5c5c4d34769f5a75"}

// const miner = creepMaker.miner(
//     {type: locationTypes.STRINGLOCATION, loc: "34x21xsim"},
//     {type: locationTypes.ID, loc: "b101b2d166f8c16f383209f1"}
// )
//
// const test = Game.creeps["Test"]
// test.memory = miner.memory

// Memory.rooms["sim"] = {}
const room = Game.rooms["sim"]
if (room.mineLocations.length === 0) {
    union.miner.setMineLocation(room, 3)
}

console.log("global reset")

module.exports.loop = function () {
    console.log("---", Game.time)

    if (room.memory.initial === undefined) {
        room.memory.initial = true
        union.spawn.initialize(room)
    }

    union.miner.run(room)
    union.spawn.run(room)

    const mineLocations = room.mineLocations
    for (const index in mineLocations) {
        const loc = mineLocations[index]
        const location = retrieve(loc.location)
        Game.map.visual.circle(location);
        Game.map.visual.text(index, location)
    }

    for (const creepName in Game.creeps) {
        let creep = Game.creeps[creepName]

        creepMaker.run(creep)
    }

}
