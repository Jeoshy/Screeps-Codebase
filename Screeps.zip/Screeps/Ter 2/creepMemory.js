module.exports = {
    harvester: function(){
        return  {
            memory: {
                role: "harvester",
                task: null
            }
        }
    },

    carrier: function(){
        return {
            memory: {
                role: "carrier",
                task: null
            }
        }
    }
}