module.exports = {
    creepCheck: function(c){
        if(c.memory.initialized != true){
            Memory.rooms.claimed[c.memory.born].creeps[c.memory.role].push(c.id)
            c.memory.initialized = true
            Game.Cb[c.memory.role](c)
        }
        if(c.memory.task == null){
            Game.Tm.getTask(c)
        } else {
            Game.Cf[c.memory.task.core](c, c.memory.task)
        }
    },

    harvester: function(c){
        if (!c.memory.task.arrived){
            Game.Tm.addToTaskList(
                c.memory.born,
                "carrier",
                {core: "pull", creepID: c.id, done: c.memory.task.hPos}
                )
            c.memory.task.arrived = true
        }
    },
    
    carrier: function(c){
    }
}