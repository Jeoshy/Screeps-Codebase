var getOpt = require("creepMemory")

module.exports = {
    update: function(){
        checkTasks()
        checkSpawning()
        checkDropped()
    },

    addToTaskList: function(room, whichCreepType, taskType,  task, place){
        if (taskType != "list"){
            task.occupied = false
            task.done = false
        }
        Memory.rooms.claimed[room].taskLists[whichCreepType][place](task)
    },

    addToSpawnList: function(room, opt){
        Memory.rooms.claimed[room].spawnList.push({room: room, opt: opt})
    },

    getTask: function(creep){
        let room = creep.memory.born
        let role = creep.memory.role
        let tasks = Memory.rooms.claimed[room].taskLists[role]

        for (let index in tasks){
            let task = tasks[index]

            switch (task.taskType){
                case "list":
                    creep.memory.task = [task.check](task)
                    break;
                case "singular":
                    if(!task.occupied && !task.done){
                        task.occupied = true
                        creep.memory.task = task
                    }
                    break;
            }
        }
    },

    checkSources : function(task, roomName, creepType){
        //Task - Only for spawnable creeps
        if (task.workParts < 6){
            for (let i in task.positions){
                let p = task.positions[i]
                if (p.occupied == false){
                    p.occupied = true
                    p.spawnedCreep = true
                    let opt = getOpt[creepType]()
                    opt.memory.task = {core: "harvest", source: task.source, hPos: p.pos, arrived: false, occupied: p.occupied, spawnCreep: p.spawnCreep}
                    Game.Tm.addToSpawnList(roomName, opt)
                }
            }
        }
    }
}

var checkTasks = function(){
    for (let roomName in Memory.rooms.claimed){
        let roomMemory = Memory.rooms.claimed[roomName]
        for (let creepTypeList in roomMemory.taskList){
            let taskList = creepTypeList
            _.forEach(taskList, function(task){
                if (task.check != undefined){
                    Game.Tm[task.check](task, roomName, creepTypeList)
                } else {
                    if (!task.spawnedCreep){
                        task.spawnedCreep = true
                        let opt = getOpt[creepTypeList]()
                        opt.memory.task = task
                        Game.Tm.addToSpawnList(roomName, opt)
                    }
                }
            })
        }
    }
}

var checkSpawning = function(){
    _.forEach(Memory.rooms.claimed, function(r){
        if (r.spawnList.length != 0){
            let creep = r.spawnList[0]
            for (var i in r.spawns){
                let s = Game.getObjectById(r.spawns[i])
                if (s.spawning == null){
                    let role = creep.opt.memory.role
                    let body = Game.Dm.getBody(role, creep.room)
                    creep.opt.memory.born = creep.room
                    creep.opt.memory.initialized = false
                    if (s.spawnCreep(body, role + Game.time, creep.opt) == 0){
                        r.spawnList.shift()
                        Game.Dm.checkCavities(creep.room)
                        break;
                    }
                }
            }
        }
    })
}

var checkDropped = function(){
    for (let roomName in Game.temp){
        let dropped = Game.temp[roomName].dropped
        let m = Memory.rooms.claimed[roomName]
        _.forEach(dropped, function(d){
            if (!(d.id in m.dropped)){
                m.dropped[d.id] = {occupied: true}
                Game.Tm.addToTaskList(
                    roomName, 
                    "carrier",
                    "singular",
                    {core: "carry", action: "pickup", secondary: "fill", id: d.id, full: false, room: roomName}),
                    "unshift"
            }
        })
    }
}


