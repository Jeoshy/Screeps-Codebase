Game.Dm = require("DataManager")
Game.Tm = require("TaskManager")
Game.Cb = require("creepBrains")
Game.Cf = require("creepFunctions")

Game.Dm.update()
Game.Tm.update()

_.forEach(Game.creeps, function(c){
    if(!c.spawning){
        Game.Cb.creepCheck(c)
    }
})