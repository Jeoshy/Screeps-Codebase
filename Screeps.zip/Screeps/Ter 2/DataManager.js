module.exports = {
    update: function(){
        checkFlags()
        checkBasics()
        checkDestroyed()
    },

    getBody: function(creepType, room){
        let info = Game.temp[room]
        let body = []
        let basicBody = Memory.creepBodies[creepType][info.level]
        let cost = 0

        _.forEach(basicBody, function(bPart){
            cost += BODYPART_COST[bPart]
        })

        _.times(Math.floor(info.energyAvailable / cost, body.push(basicBody)))
        return [].concat(...body)
    },

    getObjectToFill: function(task, creep){
        let room = task.room
        
        let used = creep.store.energy
        let id = Memory.rooms.claimed[room].capacity[0]
        if (id == undefined){
            return id
        }
        let object = Game.getObjectById(id)
        if (object.store.getFreeCapacity(RESOURCE_ENERGY) < used){
            Memory.rooms.claimed[room].capacity.shift()
        }
        return id
    },

    checkCavities: function(room){
        let list = Game.rooms[room].find(FIND_MY_STRUCTURES)

        _.forEach(list, function(s){
            let type = s.structureType
            if (type != STRUCTURE_CONTROLLER && s.store.getFreeCapacity(RESOURCE_ENERGY) > 0){
                if (type == STRUCTURE_SPAWN || type == STRUCTURE_EXTENSION){
                    Memory.rooms.claimed[room].capacity.unshift(s.id)
                } else {
                    Memory.rooms.claimed[room].capacity.push(s.id)
                }
            }
        })
    },

    remove: function(room, reference, type, item){
        let memory = Memory.rooms.claimed[room][reference]
        switch(type){
            case "object":
                delete memory[item]
                break;
            case "list":
                memory.remove(item)
                break;
        }
    }
}

var checkFlags = function(){
    _.forEach(Game.flags, function(f){
        f.remove()
        switch (f.color){
            case COLOR_WHITE:
                //Makes memory aka start flag
                //RawMemory.set("{}");
                Memory.creeps = {}
                Memory.spawns = {}
                Memory.rooms = {enemies: [], claim: [], claimed: {}}
                Memory.flags = {}
                Memory.creepIDNeeded = {}
                Memory.creepIDNeeded.sources = {}
                Memory.creepBodies = {}
                f.pos.createFlag("", COLOR_GREEN)
                initializeBody()
                break;
            case COLOR_RED:
                //Adds room to enemy list
                Memory.rooms.enemies.push(f.room.name)
                break;
            case COLOR_ORANGE:
                //Adds room to claim list
                Memory.rooms.claim.push(f.room.name)
                break;
            case COLOR_GREEN:
                //Removes from claim list
                //Adds to claimed list
                InitializeClaimedRoom(f);
                break;
        }
    })
}

var checkBasics = function(){
    Game.temp = {}
    _.forEach(Memory.rooms.claimed, function(n){
        var r = Game.rooms[n.name]
        Game.temp[n.name] = {
            energyAvailable: r.energyAvailable,
            capacityAvailable: r.energyCapacityAvailable,
            level: r.controller.level,
            dropped: r.find(FIND_DROPPED_RESOURCES),
            capacity: r.find()
        }
    })
}

var checkDestroyed = function(){

}

var creepTypes = ["harvester", "carrier"]
function initializeBody(){
    console.log("--------------------")
    _.forEach(creepTypes, function(t){
        Memory.creepBodies[t] = {}
    })

    for (let i = 1; i <= 8; i++){
        Memory.creepBodies['harvester'][i] = [WORK, WORK]
        Memory.creepBodies["carrier"][i] = [CARRY, MOVE]
    }
}

function InitializeClaimedRoom(f) {
    console.log("New room has been claimed");
    delete Memory.rooms.claim[f.room.name];
    delete Memory.rooms.claimed[f.room.name];
    let roomMemory = Memory.rooms.claimed[f.room.name] = {}
    roomMemory.name =  f.room.name;

    
    //Initialize resources in room
    roomMemory.creeps = {}
    roomMemory.dropped = {}
    roomMemory.taskList = {}
    _.forEach(creepTypes, function(c){
        roomMemory.taskList[c] = []
        roomMemory.creeps[c] = []
    })

    roomMemory.capacity = []
    roomMemory.spawnList = []
    roomMemory.spawns = []
    _.forEach(f.room.find(FIND_MY_SPAWNS), function (s) {
        roomMemory.spawns.push(s.id)
    })

    roomMemory.sources = []
    _.forEach(f.room.find(FIND_SOURCES), function (s) {
        let x = s.pos.x;
        let y = s.pos.y;
        let positions = [];
        _.forEach(f.room.lookAtArea(y - 1, x - 1, y + 1, x + 1, true), function (t) {
            if (t.type == "terrain" && (t.terrain == "swamp" || t.terrain == "plain")) {
                positions.push({
                    pos: f.room.getPositionAt(t.x, t.y),
                    occupied: false,
                    spawnedCreep: false
                });
            }
        });
        Game.Tm.addToTaskList(
            f.room.name, 
            "harvester",
            "list",
            {source: s.id, workParts: 0, room: f.room.name, positions: positions, check: "checkSources"},
            "push"
        )
    });
}