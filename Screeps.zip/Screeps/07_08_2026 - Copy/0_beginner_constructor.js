const {inheritCreep, basicCreep} = require("0_basic_creep")
const beginner_harvester = require("0_beginner_harvester")
const room_command = require("1_room_commands")
const PHASES = require("0_PHASES")
const ROLES = require("0_ROLES")
const STRATEGIES = require("1_STRATEGIES")

function beginner_constructor () {
    this.role = ROLES.BEGINNER_CONSTRUCTOR
    this.body = [WORK, WORK, CARRY, CARRY]
    this.memory = {}
    this.strategy = STRATEGIES.BEGINNER
    this.energy_needed = 300
}

inheritCreep(beginner_constructor)

/*
-----------
 Planning 
-----------
Interacts with room and strategy
*/

beginner_constructor.prototype.planned = beginner_harvester.prototype.planned

beginner_constructor.prototype.spawn = beginner_harvester.prototype.spawn

/*
-------------
     RUN
-------------
Only part where creep object is mandatory to pass
*/

beginner_constructor.prototype.alive = function (creep) {
    if (Number.isFinite(creep.memory.pull_location)) {
        console.log("Nothing here :(")

        if (!creep.memory.direction_of_energy) {
            const {x, y, roomName} = creep.pos
            const creeps = creep.room.lookForAtArea(LOOK_CREEPS, y-1, x-1, y+1, x+1, true)
            const energy_creeps = []
            
            creeps.forEach(c => {
                if (c.creep.store.getUsedCapacity() > 0 && c.creep.name != creep.name) {
                    energy_creeps.push(c.creep)
                }
            })

            if (energy_creeps.length > 0) {
                creep.memory.direction_of_energy = creep.pos.getDirectionTo(energy_creeps[0].pos)
            }
        }
        else
        {
            if (creep.memory.hungry == true) {
                const direction = creep.memory.direction_of_energy
                const location = global.direction_to_pos(direction, creep.pos)
                const creep_spotted = creep.room.lookForAt(LOOK_CREEPS, location.x, location.y)[0]
                if (creep_spotted) {
                    creep_spotted.transfer(creep, RESOURCE_ENERGY)
                }

                if (creep.store.getUsedCapacity() == 0) {
                    creep.memory.hungry = false
                }
            }
            else 
            {
                if (!creep.memory.construction) {
                    const constructions = creep.room.lookForAtArea(LOOK_CONSTRUCTION_SITES, y-3, x-3, y+3, x+3, true)

                    if (constructions.length == 0) {
                        for (let x = -3; x < 3; i++) {
                            for (let y = -3; y < 3; i++) {
                                
                            }
                        }
                    }
                }




                creep.memory.hungry = true
            }
        }

    }
    else
    {
        // - if no source_id, then find constructor location and source_id via strategy and add source_id
        if (!Number.isFinite(creep.memory.pull_location)) {
            creep.memory.pull_location = creep.room.get_constructor_location()
        }
        
        // - Add a request for transport to constructor location
        if (!creep.memory.request) {
            const rc = new room_command().from_room(creep.room)
            rc.add_pull_request(creep.room, this)
            
            this.creep_planning.request = true
        }
    }
}

module.exports = beginner_constructor