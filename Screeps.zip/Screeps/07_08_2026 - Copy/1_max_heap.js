const max_heap = function (A) {
    this.max_heap = A || []
}

max_heap.prototype.create = function (array) {
    for (let i = 0; i < array.length; i++) {
        this.insert(array[i])
    }
}

max_heap.prototype.get_value = function (index, A = this.max_heap) {
    throw new Error("Did not implement the max_heap get_value function")
}

max_heap.prototype.length = function () {
    return this.max_heap.length
}

max_heap.prototype.left = function (i) {
	return ((i + 1) * 2) - 1
}

max_heap.prototype.right = function (i) {
	return ((i + 1) * 2)
}

max_heap.prototype.parent = function (i) {
	return Math.floor((i + 1) / 2) - 1
}

max_heap.prototype.maxHeapify = function (i) {
	let largest = i
	const l = this.left(i)
	const r = this.right(i)

	if (l < this.length() && this.get_value(this.max_heap[l]) > this.get_value(this.max_heap[largest])) {
		largest = l
	}
	if (r < this.length() && this.get_value(this.max_heap[r]) > this.get_value(this.max_heap[largest])) {
		largest = r
	}
	if (largest !== i) {
		[this.max_heap[i], this.max_heap[largest]] = [this.max_heap[largest], this.max_heap[i]]
		this.maxHeapify(largest)
	}
}

max_heap.prototype.maximum = function () {
	return this.max_heap[0]
}

max_heap.prototype.extract_max = function () {
	if (this.length < 1) {
		return undefined
	}
	if (this.length === 1) {
		return this.max_heap.pop()
	}

	const max = this.max_heap[0]
	this.max_heap[0] = this.max_heap.pop()
	this.maxHeapify(0)
	return max
}

max_heap.prototype.insert = function (key) {
	this.max_heap.push(-Infinity)
	this.increaseValue(this.max_heap.length - 1, key)
}

max_heap.prototype.increaseValue = function (i, new_key) {
	if (this.max_heap[i] > new_key) {
		throw Error("Tried to decrease a value in maxHeap")
	}

	this.max_heap[i] = new_key
	while (i > 0 && this.get_value(this.max_heap[this.parent(i)]) < this.get_value(this.max_heap[i])) {
		[this.max_heap[i], this.max_heap[this.parent(i)]] = [this.max_heap[this.parent(i)], this.max_heap[i]]
		i = this.parent(i)
	}
}

max_heap.prototype.decreaseValue = function (i, new_key) {
	if (this.get_value(this.max_heap[i]) < this.get_value(new_key)) {
		throw Error("Tried to increase a value in maxHeap")
	}
	this.max_heap[i] = new_key
	this.maxHeapify(i)
}

max_heap.prototype.search = function (i, limit) {
	if (i >= this.max_heap.length || this.max_heap[i] <= limit) {
		return []
	}
	return [this.max_heap[i]]
		.concat(this.search(this.left(i), limit))
		.concat(this.search(this.right(i), limit))
}

module.exports = max_heap
