const phases = {
    PLANNED: "planned",
    SPAWN: "spawn",
    ALIVE: "alive",
    TRASH: "trash",
    DEAD: "dead"
}

module.exports = phases