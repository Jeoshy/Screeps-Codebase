const strategies = {
    BEGINNER: "beginner",
    INTERMEDIATE: "intermediate"
}

module.exports = strategies