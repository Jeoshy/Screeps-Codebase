const create_creep = require("0_creep_handler")
const create_strategy = require("1_strategy_handler")
const ROLES = require("0_ROLES")
const PHASES = require("0_PHASES")
const {inheritCreep, basic_creep} = require("0_basic_creep")
const beginner_harvester = require("0_beginner_harvester")
const max_heap = require("1_max_heap")

const room = Game.rooms["sim"]

if (!room.memory.strategy) {
    // RawMemory.set("{}")
    Memory.rooms = {}
    Memory.creeps = {}
    Memory.creeps_planning = {}
    Memory.locations = {}
    Memory.locations_counter = 0
    
    for (const phase in PHASES) {
        const name = PHASES[phase]
        room.memory[name] = []
    }
    room.memory.strategy = "beginner"
}

const splitter = "!"

global.register_room_position = function (room_position, linked_id) {
    global.register_location(room_position.x, room_position.y, room_position.roomName, linked_id)
}

global.register_location = function (x, y, room_name, linked_id) {
    if (x instanceof RoomPosition) {
        global.register_room_position(x, linked_id)
    }
    else 
    {
        Memory.locations[Memory.locations_counter] = x + splitter + y + splitter + room_name + splitter + linked_id
    }
    Memory.locations_counter++

    return Memory.locations_counter - 1
}

global.get_location = function (location_id) {
    if (!Number.isFinite(location_id)) {throw new Error("Location_id is undefined")}   
    const [x, y, room_name, linked_id] = Memory.locations[location_id].split(splitter)
    return new RoomPosition(x, y, room_name)
}

global.get_linked_object = function (location_id) {
    if (!Number.isFinite(location_id)) {throw new Error("Location_id is undefined")}   
    const [x, y, room_name, linked_id] = Memory.locations[location_id].split(splitter)
    return Game.getObjectById(linked_id)
}

module.exports.loop = function () {

    for (let x = -3; x < 3; i++) {
        for (let y = -3; y < 3; i++) {
            console.log(x, y)
        }
    }


    /*
    ----------------------
    Generates commands
    ----------------------
    This sections combs through the data and generates commands.
    Only generates commands that are executed this tick.
    We can use strategy design pattern easier as generating commands and execution 
    are separated. 
    Each command has an execution and data handler. The data handler changes the data
    based on the execution result.
    */

    for (const room_name in Game.rooms) {
        const room = Game.rooms[room_name]

        if (!room.memory.strategy) {
            continue;
        }

        const strategy = create_strategy(room.memory.strategy, room.name)
        strategy.perform_initialization(room)
        // strategy.movement_cost_matrix(room)
        strategy.switch(room)

        // Move the lowest priority creep to spawn list
        const planned_creep_name = room.memory.planned[0]
        const creep = create_creep(planned_creep_name, room.name)
        if (creep.planned(room, strategy) == OK) {
            creep.switch(PHASES.SPAWN)
            const planned_creep_name_second = room.memory.planned[0]
            const creep_second = create_creep(planned_creep_name, room.name)
            if (creep_second.planned(room, strategy) == OK) {
                creep_second.switch(PHASES.SPAWN)
            }
        }

        // Spawn creep
        for (let i = 0; i < room.spawn_spots; i++) {
            const spawn_creep_name = room.memory.spawn[i]
            const creep = create_creep(spawn_creep_name, room.name)
            
            if (!creep.creep_planning.spawn_spot) {
                creep.creep_planning.spawn_spot = room.memory.spawns[i]
            }
            
            if (creep.spawn(room, strategy) != OK) {
                continue;
            }

            // Do the actual spawning and spawn to BOTTOM
            const spawn = global.get_linked_object(room.memory.spawns[i])
            const index = spawn.spawnCreep(
                creep.creep_planning.body,
                creep.name,
                {
                    memory: creep.creep_planning.memory,
                    directions: creep.directions,
                    dryRun: true
                }
            )

            if (index == OK) {
                spawn.spawnCreep(
                    creep.creep_planning.body,
                    creep.name,
                    {
                        memory: creep.creep_planning.memory,
                        directions: creep.directions,
                        dryRun: false
                    }
                )
            }

            if (!spawn.spawning) {
                creep.switch(PHASES.ALIVE)
            }
        }
    }
        
    /*
    ----------------------
        Executes commands
    ----------------------
    Fixed order
    - Global level
    - Room level
    - Creep level
    */

    for (const room_name in Game.rooms) {
        const room = Game.rooms[room_name]
        for (const alive_creep_name of room.memory.alive) {
            const creep_plan = create_creep(alive_creep_name, room.name)
            const creep = Game.creeps[alive_creep_name]
            if (creep) {
                creep_plan.alive(creep, room)
            }
        }
        for (let x = 0; x < 50; x++) {
            for (let y = 0; y < 50; y++) {
                // let value = room.constructors.get(x, y)
                // let value = room.routes.get(x, y)
                // let value = room.linked_locations.get(x, y)
                let value = room.constructions.get(x, y)
                if(value != 255 && value) {
                    new RoomVisual("sim").text(value, x, y)
                }
                value = room.constructors.get(x, y)
                if(value != 255 && value) {
                    new RoomVisual("sim").text(value, x, y, {color:"red"})
                }
            }
        }

        // Serialize costMatrix if anything changed
        room.serialize_costMatrices()
    }
    
}