const {inheritCreep, basicCreep} = require("0_basic_creep")
const PHASES = require("0_PHASES")
const ROLES = require("0_ROLES")

/*
The beginner harvester
- spawns in with either 3 WORK as body
- requests a transport request
- knows request is done when location condition is fulfilled
- starts harvesting after locatio condition
*/

function intermediate_harvester () {
    this.role = ROLES.INTERMEDIATE_HARVESTER
    this.body = [WORK, WORK, WORK]
    this.memory = {}
}

inheritCreep(intermediate_harvester)

intermediate_harvester.prototype.make_ready_to_spawn = function (priority = 0) {
    this.use_body(this.body).use_memory(this.memory).generate_name().add_priority(priority)
}

intermediate_harvester.prototype.planned = function () {
    this.creep_planning = Memory.creep_planning[this.name]
    if (!this.creep_planning.timer || this.creep_planning.timer >= Game.time) {
        this.switch(PHASES.SPAWN)
    }

    return this
}