const {inheritCreep, basicCreep} = require("0_basic_creep")
const PHASES = require("0_PHASES")
const ROLES = require("0_ROLES")
const STRATEGIES = require("1_STRATEGIES")
const beginner_harvester = require("0_beginner_harvester")

function beginner_carrier () {
    this.role = ROLES.BEGINNER_CARRIER
    this.body = [MOVE, CARRY]
    this.memory = {}
    this.strategy = STRATEGIES.BEGINNER
    this.energy_needed = 100
}

inheritCreep(beginner_carrier)

/*
-----------
 Planning 
-----------
Interacts with room and strategy
*/

beginner_carrier.prototype.planned = beginner_harvester.prototype.planned

beginner_carrier.prototype.spawn = function (room, strategy) {
    // No specific location needed for spawning
    this.directions = [TOP]

    return OK
}

/*
------------
    RUN
------------
Interacts with creep and room
*/

beginner_carrier.prototype.alive = function (creep, room) {
    // Perform action of square
    this.move(creep)
    this.get_action(creep)

    // For now if there is a pull request, get the creep itself and move toward the creep
    if (creep.memory.pull && !room.memory.spawn.includes(creep.memory.pull)) {
        const creep_to_pull = Game.creeps[creep.memory.pull]

        if (!creep_to_pull) {
            creep.memory.pull = undefined
        }
        else
        {
            const pull_location = global.get_location(creep_to_pull.memory.pull_location)

            if (creep_to_pull.pos.isEqualTo(pull_location)) {
                creep.memory.pull = undefined
            }
            else
            {
                if (creep.action == "choose") {
                    creep.move(creep.room.routes.get(pull_location.x, pull_location.y))
                }
                else if (creep.pos.inRangeTo(pull_location, 1)) {
                    creep.move(creep.pos.getDirectionTo(pull_location))
                }
                else{
                    this.move(creep)
                }
                let index = creep.pull(creep_to_pull)
                if (index == OK) {
                    creep_to_pull.move(creep)
                }
                else if (index == ERR_INVALID_TARGET){
                    creep.cancelOrder("move")
                }
            }
        }
    }

    if (!creep.memory.pull) {
        this.move(creep)
    }
}

beginner_carrier.prototype.choose = function (creep) {
    const spawns = creep.room.find(FIND_MY_SPAWNS)
    const index = creep.transfer(spawns[0], RESOURCE_ENERGY)
    if (index != OK) {
        creep.drop(RESOURCE_ENERGY)
    }

    if (!creep.memory.pull && this.room.pull_requests.length > 0) {
        const creep_to_pull = Game.creeps[this.room.memory.pull_requests[0]]
        if (!creep_to_pull) {
            this.room.memory.pull_requests.shift()
        }
        if (!creep_to_pull.spawning) {
            creep.memory.pull = this.room.memory.pull_requests.shift()
        }
    }

    if (!creep.memory.pull) {

        if (creep.memory.direction == 0) {
            creep.memory.direction = 2
        }
        creep.move(creep.memory.direction)
    }
}

beginner_carrier.prototype.withdraw_creep = function (creep) {
    const creep_that_transfers = creep.linked_location.lookFor(LOOK_CREEPS)[0]

    if (creep_that_transfers && !creep.memory.pull) {
        creep_that_transfers.transfer(creep, RESOURCE_ENERGY)
    }
}

module.exports = beginner_carrier