const {inheritCreep, basicCreep} = require("0_basic_creep")
const room_command = require("1_room_commands")
const PHASES = require("0_PHASES")
const ROLES = require("0_ROLES")
const STRATEGIES = require("1_STRATEGIES")

function beginner_harvester () {
    this.role = ROLES.BEGINNER_HARVESTER
    this.body = [WORK, CARRY, CARRY]
    this.memory = {}
    this.strategy = STRATEGIES.BEGINNER
    this.energy_needed = 200
    this.generates = 2
}

inheritCreep(beginner_harvester)

/*
-----------
 Planning 
-----------
Interacts with room and strategy
*/

beginner_harvester.prototype.planned = function (room, strategy) {
    if ((!this.creep_planning.timer || this.creep_planning.timer >= Game.time) && room.energyAvailable >= this.energy_needed) {
        return OK
    }
}

beginner_harvester.prototype.spawn = function (room, strategy) {
    // Initialize specific for spawn
    this.directions = [LEFT]

    return OK
}

/*
-------------
     RUN
-------------
Only part where creep object is mandatory to pass

The harvester tries to harvest every tick
If the harvester can harvest, it has reached the destination
When it has reached the destination, then a few things happen
- if respawn = true, then respawn = false
- Runs respawn script, first checks hardcoded constraints - is strategy beginner_strategy?
- Sets new creep this.timer = 2 * remaining_ticks + 1500 - body.length * 2 + Game.time 
r + (r - 1500) = 1500
*/
beginner_harvester.prototype.alive = function (creep) {
    if (Number.isFinite(creep.memory.pull_location)) {
        const source = global.get_linked_object(creep.memory.pull_location)
        const index = creep.harvest(source)
        
        if (index == OK) {      
            // Beginner harvester will not respawn though
            this.respawn(creep)
        }
    }
    else
    {
        // - if no source_id, then find harvest_location and source_id via strategy and add source_id
        if (!Number.isFinite(creep.memory.pull_location)) {
            creep.memory.pull_location = creep.room.get_harvest_location()
        }
        
        // - Add a request for transport to harvest_location
        if (!creep.memory.request) {
            const rc = new room_command().from_room(creep.room)
            rc.add_pull_request(creep.room, this)
            
            this.creep_planning.request = true
        }
    }
}

beginner_harvester.prototype.respawn = function (creep) {
    if (creep.memory.respawn && this.room.strategy == this.strategy) {
        creep.memory.respawn = false
        const replacement = new beginner_harvester()
        replacement.memory = {
            pull_location: creep.memory.pull_location
        }
        this.make_ready_to_spawn()

        // Add timer lol

    }
}



module.exports = beginner_harvester
