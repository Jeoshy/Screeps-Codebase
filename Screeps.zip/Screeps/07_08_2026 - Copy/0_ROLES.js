roles = {
    BEGINNER_HARVESTER: "beginner_harvester",
    BEGINNER_CARRIER: "beginner_carrier",
    BEGINNER_CONSTRUCTOR: "beginner_constructor",
    INTERMEDIATE_HARVESTER: "intermediate_harvester",
}

module.exports = roles