/*
Each creep:
- has a specific function
- requires a spawn and thrash conditions
- has its own run code
*/

const ROLES = require("0_ROLES")
const {inheritCreep, basic_creep} = require("0_basic_creep")
const beginner_harvester = require("0_beginner_harvester") 
const beginner_carrier = require("0_beginner_carrier") 
const beginner_constructor = require("0_beginner_constructor")

const create_creep = function (name, room_name) {
    const role = Memory.creeps_planning[name]?.role ?? "undefined"
    
    // Initialize role
    let creep = undefined
    switch(role){
        case ROLES.BEGINNER_HARVESTER:
            creep = new beginner_harvester()
            break;
        case ROLES.BEGINNER_CARRIER:
            creep = new beginner_carrier()
            break;
        case ROLES.BEGINNER_CONSTRUCTOR:
            creep = new beginner_constructor()
            break;
        case "undefined":
            console.log("This creep", name, "has no role. In room", room_name)
            creep = new basic_creep()
            break;
        default:
            throw new Error("This role " + role + " is not found in create_creep")
    }

    // Add initialization
    creep.called(name).from_room_name(room_name).add_memory_with_name(name)
    return creep
}

module.exports = create_creep