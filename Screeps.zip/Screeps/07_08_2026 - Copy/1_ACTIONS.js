const actions = {
    PICKUP: 1,
    WITHDRAW_CREEP: 2,
    DROP: 3,
    TRANSFER: 4,
    CHOOSE: 5,
    WAIT: 6
}

module.exports = actions