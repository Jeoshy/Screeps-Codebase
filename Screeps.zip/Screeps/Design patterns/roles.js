const {creepROLES} = require("./constants");

function AbstractRole () {
    this.body;
    this.role;
}

function Harvester () {
    AbstractRole.apply(this, arguments)
    // this.body = function
}

module.exports = {
    [creepROLES.HARVESTER]: Harvester
}