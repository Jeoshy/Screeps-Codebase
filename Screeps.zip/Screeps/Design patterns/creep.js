function CreepDecorator (creep) {
    this.creep = creep
    this.harvest
}

function CreepTaskDecorator (creep, task) {
    CreepDecorator.apply(this, creep)
    this.task = task
}