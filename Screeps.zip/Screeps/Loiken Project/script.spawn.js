
/*var spawnFunction = {
    run: function(nameCreep, room){
        var energy = this.room.energyAvailable;
        var energyCapacity = this.room.energyCapacityAvailable;
        console.log('Trying to spawn ' + role)
        if(maxEnergy <= energyCapacity && this.room.memory.creepCounts.queen > 0 && this.room.memory.creepCounts.harvester > 0){
            energy = maxEnergy;
        }
        else if(energy > maxEnergy){
            energy = maxEnergy;
        }
        else if(energy < this.room.memory.energyCosts[role] && this.room.memory.energyCosts[role] != 0 || maxEnergy <= energyCapacity && energy < maxEnergy && this.room.memory.creepCounts.queen > 0 && this.room.memory.creepCounts.harvester > 0){
            console.log('spawnDenied')
            return;
        }
    }
}*/

module.exports = function () {
    
    Room.prototype.bodyFunction = function(nameCreep){
        switch(nameCreep){
            case 'H':
                return [WORK, WORK, MOVE, CARRY]
            case 'B':
                return [WORK, MOVE, CARRY]
            case 'C':
                return [MOVE, CARRY]
        }
    }
    
    Room.prototype.maxEnergy = function(nameCreep){
        switch(nameCreep){
            case 'H':
                return 1400
            case 'B':
                return 2000
            case 'C':
                return 1000
        }
    }
    
    Room.prototype.spawnFunction = function(nameCreep){
        var bodyArray = this.bodyFunction(nameCreep)
        var maxEnergy = this.maxEnergy(nameCreep)
        var energyCost = 0;
        var bodyFinal = [];
        for(var body of bodyArray){
            switch(body){
                case TOUGH:
                    energyCost += 10;
                    break;
                case MOVE:
                    energyCost += 50;
                    break;
                case CARRY:
                    energyCost += 50;
                    break;
                case WORK:
                    energyCost += 100;
                    break;
                case ATTACK:
                    energyCost += 80;
                    break;
                case RANGED_ATTACK:
                    energyCost += 150;
                    break;
                case HEAL:
                    energyCost += 250;
                    break;
                case CLAIM:
                    energyCost += 600;
                    break;
            }
        }
        
        this.memory.spawnList.push({nameCreep: nameCreep, maxEnergy: maxEnergy, bodyArray: bodyArray, energyCost: energyCost})
        this.memory.priorization = null
    };
    
    Room.prototype.spawningFunction = function(id){
        var nameCreep = this.memory.resources.spawns[id].spawn.nameCreep
        var maxEnergy = this.memory.resources.spawns[id].spawn.maxEnergy
        var bodyArray = this.memory.resources.spawns[id].spawn.bodyArray
        var energyCost = this.memory.resources.spawns[id].spawn.energyCost
        var energy = this.energyAvailable;
        var bodyFinal = [];
        
        if(energy < energyCost){
            return;
        }
        
        if(energy > maxEnergy){
            energy = maxEnergy
        }
        
        var numberParts = Math.floor(energy/energyCost)
        for(var bodyPart of bodyArray){
            for(var i = 0; i < numberParts; i++){
                bodyFinal.push(bodyPart);
            }
        }
        
        var index = Game.getObjectById(id).spawnCreep(bodyFinal, Game.time + nameCreep, {memory: {room: this.name, role: nameCreep, harvesting: true}/*, directions: direction*/})
        if(index == 0){
            this.room.memory.creepCounts[nameCreep]++;
        }
    }
};
