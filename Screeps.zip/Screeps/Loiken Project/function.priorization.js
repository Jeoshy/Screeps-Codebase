module.exports = function () {
    
    Room.prototype.priorizationList = function(){
        for(var index in this.memory.priorizationList){
            var list = this.memory.priorizationList[index]
            var lengthList = list.length
            
            if(lengthList > 0){
                this.memory.priorization = list[0];
                list.splice(0,1)
                break;
            }
        }
    };
    
    Creep.prototype.priorizationList = function(){
        for(var index in this.memory.priorizationList){
            var list = this.memory.priorizationList[index]
            var lengthList = list.length
            
            if(lengthList > 0){
                this.memory.priorization = list[0];
                list.splice(0,1)
                break;
            }
        }
    };
    
    Room.prototype.spawnList = function(idSpawn){
        if(this.memory.spawnList.length > 0){
            var unit = this.memory.spawnList[0];
            this.memory.resources.spawns[idSpawn].spawn = unit;
            this.memory.spawnList.splice(0,1)
        }
    };
    
};