require('function.priorization')()
require('script.spawn')()

var roomFunction = {
    run: function(nameRoom){
        var room = Game.rooms[nameRoom]
        
        var roomCheck = function(){
            var energySources = room.find(FIND_SOURCES);
            if(energySources.length <= 0){
                room.memory.roomGood = false;
            }
            else if(energySources.length <= 2){
                room.memory.roomGood = true;
                room.memory.priorizationList = [['SH','SC', 'SH','SC', 'SB']]
                room.memory.priorization = null
                room.memory.spawnList = []
                room.memory.creepCounts = {'H': 0, 'B': 0, 'C': 0}
                room.memory.resources = {}
                room.memory.resources.sources = []
                room.memory.resources.numberSpawn = 0;
                room.memory.resources.spawns = {}
                for(var index in energySources){
                    var source = energySources[index].id
                    room.memory.resources.sources[index] = source
                }
            }
            room.memory.roomCheck = true
        }
        
        if(room.memory.roomCheck != true){
            roomCheck()
        }
        else if(room.memory.priorization == null){
            room.priorizationList(nameRoom)
        }
        else{
            switch(room.memory.priorization[0]){
                case 'S':
                    room.spawnFunction(room.memory.priorization[1])
                    break;
            }
        }
        
        var enemies = room.find(FIND_HOSTILE_CREEPS)
        var spawns = room.find(FIND_MY_SPAWNS)
        
        if((spawns.length != 0 && room.memory.resources.numberSpawn != spawns.length) || enemies.length > 0){
            room.memory.resources.numberSpawn = spawns.length
            for(var id in room.memory.resources.spawns){
                if(Game.getObjectById(id) == undefined){
                    room.memory.resources.spawns[id] = undefined;
                }
            }
            for(var index in spawns){
                var spawn = spawns[index];
                var idSpawn = spawn.id;
                if(room.memory.resources.spawns[idSpawn] == undefined){
                    room.memory.resources.spawns[idSpawn] = {numberSpawn: index, spawn: null}
                }
            }
        }
        
        if(Game.time % 5 == 0){
            for(var id in room.memory.resources.spawns){
                var spawn = room.memory.resources.spawns[id]
                if(spawn.spawn == null){
                    room.spawnList(id);
                }
                else {
                    room.spawningFunction(id);
                }
            }
        }
        
        
        
        
    }
};

module.exports = roomFunction;