var roomFunction = require('script.room')

module.exports.loop = function () {
    for(var name in Game.rooms) {
        var room = Game.rooms[name];
        if(room.memory.roomGood != false){
            roomFunction.run(name)
        }
        else {
            
        }
    }
}