var reverse = {
    1: BOTTOM,
    2: BOTTOM_LEFT,
    3: LEFT,
    4: TOP_LEFT,
    5: TOP,
    6: TOP_RIGHT,
    7: RIGHT,
    8: BOTTOM_RIGHT
}


module.exports = {
    pull: function(c, task){
        if (task.setup == undefined){
            let target = Game.getObjectById(task.creepID)
            if (!c.pos.inRangeTo(target, 1)){
                Game.Cf.moveC(c, task, target)
            } else {
                task.setup = true
                task.path = undefined
            }
        } else {
            if (task.path == undefined){
                task.path = c.pos.findPathTo(task.done.x, task.done.y)
                let two = task.path[task.path.length - 1]
                let last = Object.assign({}, task.path[task.path.length - 1])
                last.dx *= -1
                last.dy *= -1
                last.x += last.dx
                last.y += last.dy
                last.direction = reverse[two.direction]
                task.path.push(last)
            } else {
                let c2 = Game.getObjectById(task.creepID)
                if (!(c2.pos.x == task.done.x && c2.pos.y == task.done.y)){
                    c.moveByPath(task.path)
                    if (c.pull(c2) != 0){
                        task.setup = undefined
                        c.memory.previousID = null
                    }
                    c2.move(c), c.name
                    
                } else {
                    c.memory.task = null
                }
            }
        }
    },

    harvest: function(c, task){
        c.harvest(Game.getObjectById(task.source))
        c.drop()
    },

    carry: function(c, task){
        if (!task.full){
            let target = Game.getObjectById(task.id)
            if (target == null){
                Game.Dm.remove(task.room, "dropped", "object", task.id)
                c.memory.task = null
                return;
            }

            if (!c.pos.inRangeTo(target, 1)){
                Game.Cf.moveC(c, task, target)
            } else {
                Game.Cf[task.action](c, task)
            }
        } else {
            Game.Cf[task.secondary](c, task)
        }
    },

    pickup: function(c, task){
        let target = Game.getObjectById(task.id)
        let index = c.pickup(target)

        Game.Tm.addToTaskList(
            task.room, 
            "carrier",
            {core: "carry", action: "pickup", secondary: "fill", id: task.id, full: false, room: task.room})

        if (index == 0){
            task.full = true
        } else {
            c.memory.task = null
        }
    },

    fill: function(c, task){
        if (task.fillID == undefined){
            task.fillID = Game.Dm.getObjectToFill(task, c)
            if (task.fillID == undefined){
                c.memory.task = null
                return;
            }
        }

        let target = Game.getObjectById(task.fillID)
        if (!c.pos.inRangeTo(target, 1)){
            Game.Cf.moveC(c, task, target)
        } else {
            let index = c.transfer(target, RESOURCE_ENERGY)
            if (index == 0){
                c.memory.task = null
            } else {
                task.fillID = undefined
            }
        }
    },

    moveC: function(c, task, object){
        if (c.memory.previousID != object.id || task.path == undefined){
            task.path = c.pos.findPathTo(object)
        } else {
            c.moveByPath(task.path)
        }
        c.memory.previousID = object.id
    }
}
