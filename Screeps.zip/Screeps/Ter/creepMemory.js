module.exports = {
    harvester: function(p, key){
        return  {
            memory: {
                role: "harvester",
                task: {core: "harvest", source: key, hPos: p.pos, arrived: false}
            }
        }
    },

    carrier: function(){
        return {
            memory: {
                role: "carrier",
                task: null
            }
        }
    }
}