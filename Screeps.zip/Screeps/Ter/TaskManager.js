var getMemory = require("creepMemory")

module.exports = {
    update: function(){
        checkSources()
        checkSpawning()
        checkDropped()
    },

    addToTaskList: function(room, whichCreepType,  task){
        Memory.rooms.claimed[room].taskList[whichCreepType].push(task)
    },

    addToSpawnList: function(room, opt){
        Memory.rooms.claimed[room].spawnList.push({room: room, opt: opt})
    },

    getTask: function(creep){
        let room = creep.memory.born
        let role = creep.memory.role
        let task = Memory.rooms.claimed[room].taskList[role][0]
        if (task != undefined){
            if (!task.loop || Game.getObjectById(task.id) == undefined){
                Memory.rooms.claimed[room].taskList[role].shift()
            }
            creep.memory.task = Object.assign({}, task)
        }
    }
}

var checkSources = function(){
    for (let key in Memory.creepIDNeeded.sources){
        let s = Memory.creepIDNeeded.sources[key]
        if (s.workParts < 6 && s.numberOfCreeps < s.positions.length){
            for (let i in s.positions){
                let p = s.positions[i]
                if (p.occupied == false){
                    Game.Tm.addToSpawnList(s.hub, getMemory["harvester"](p, key))
                    Game.Tm.addToSpawnList(s.hub, getMemory["carrier"]())
                    p.occupied = true
                    s.numberOfCreeps += 1
                    break;
                }
            }
        }
    }
}

var checkSpawning = function(){
    _.forEach(Memory.rooms.claimed, function(r){
        if (r.spawnList.length != 0){
            let creep = r.spawnList[0]
            for (var i in r.spawns){
                let s = Game.getObjectById(r.spawns[i])
                if (s.spawning == null){
                    let role = creep.opt.memory.role
                    let body = Game.Dm.getBody(role, creep.room)
                    creep.opt.memory.born = creep.room
                    creep.opt.memory.initialized = false
                    if (s.spawnCreep(body, role + Game.time, creep.opt) == 0){
                        r.spawnList.shift()
                        Game.Dm.checkCavities(creep.room)
                        break;
                    }
                }
            }
        }
    })
}

var checkDropped = function(){
    for (let roomName in Game.temp){
        let dropped = Game.temp[roomName].dropped
        let m = Memory.rooms.claimed[roomName]
        _.forEach(dropped, function(d){
            if (!(d.id in m.dropped)){
                m.dropped[d.id] = {occupied: true}
                Game.Tm.addToTaskList(
                    roomName, 
                    "carrier",
                    {core: "carry", action: "pickup", secondary: "fill", id: d.id, full: false, room: roomName})
            }
        })
    }
}


