const mainSpawn = Game.spawns[Object.keys(Game.spawns)[0]];
const mainRoom = Game.spawns[mainSpawn.name].room

require ("cache")
require ("wrapper")
require ("object_functions")
require ("jobs")
require ("jobs_functions")
require ("creeps")
require ("room_standard")
require ("rooms")

module.exports.loop = function () {

    _.forEach(Game.rooms, (room) => room.update())

    console.log("In total used this tick \n", Game.cpu.getUsed(), "\nTotal in bucket left \n", Game.cpu.bucket)
}

Memory.cache = Cache

