function TemplateCreep (name, room_name, type, body, maxCost) {
    this.name = name + type
    this.memory = {room_name: room_name, type: type}
    this.body = body
    this.maxCost = maxCost
    this.bodyCost = _.reduce(body, (total, part) => {return total + BODYPART_COST[part]}, 0)
    this.spawned = false
}

global.harvester = function (room_name, i) {
    TemplateCreep.call(this, room_name + i, room_name, "harvester", [WORK, WORK], 600)
}

global.carrier = function (room_name, i) {
    TemplateCreep.call(this, room_name + i, room_name, "carrier", [CARRY, MOVE], 2000)
}

global.upgrader = function (room_name, i) {
    TemplateCreep.call(this, room_name + i, room_name, "upgrader", [CARRY, CARRY, WORK, WORK], 5000)
}