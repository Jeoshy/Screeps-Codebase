// Cache
function newCache () {
    for (const roomName in Memory.rooms) {
        this[roomName] = {job_count: 0, jobs: [], spawns: [], resetted: false}
    }
    console.log("Cache has been resetted")
}

global.Cache = new newCache()

// module.exports = {
//     Cache: new newCache()
// }
