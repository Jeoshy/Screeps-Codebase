RoomPosition.prototype.workspaces_in_area = function ({range = 1} = {}) {
    const {x, y, roomName} = this
    const room = Game.rooms[roomName]
    
    const arrayOfArea = room.lookAtArea(
        y - range, 
        x - range, 
        y + range, 
        x + range,
        true)
    
    const tiles = arrayOfArea.reduce((arrayOfTile, element) => {
        let {type, terrain, x, y} = element
        
        // Check whether it is a plain
        if (type == "terrain" && terrain != "wall") {
            return arrayOfTile.concat(new RoomPosition(x, y, roomName))
        }
        
        // No plain, return the array without adding
        return arrayOfTile
    }, [])
    
    return tiles
}