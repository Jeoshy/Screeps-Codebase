global.Job = function (creep_type) {
    this.creep_type = creep_type
    this.memory = {}
}

global.Harvest = function (source_id, workspace) {
    Job.call(this, "harvester")
    this.source_id = source_id
    this.workspace = workspace
    this.run = profiler(profiler.SHOW, function creep_harvest(creep) {
        const {source_id, workspace} = this

        // Phase 2: harvest resource
        if (creep.harvest(Game.getObjectById(source_id)) == OK){
            return
        }
        
        // Phase 1: go to spot
        if (creep.pos.x == workspace.x && creep.pos.y == workspace.y) {
            this.memory.createJobToMove = true
            return
        }
        
        if (!this.memory.createJobToMove) {
            creep.room.add_job(new CreepMove(this.id, position))
            this.memory.createJobToMove = true
        }
    })
}

global.Upgrader = function (workspace) {
    Job.call(this, "upgrader")
    this.workspace = workspace
    this.run = profiler(profiler.SHOW, function creep_upgrade(creep) {
        const {workspace} = this

        // Phase 3: upgrade controller
        if (creep.memory.busy) {
            let index = creep.upgradeController(creep.room.controller)
            if (index == ERR_NOT_ENOUGH_RESOURCES) {
                creep.memory.busy = false
            }
            
            return
        }
        
        // Phase 2: pickup resource
        let {x, y} = creep.room.memory.dropPoints["upgrader"]
        let resource = creep.room.lookForAt(LOOK_RESOURCES, x, y)[0]
        let index = creep.pickup(resource)
        
        if (index == OK || index == ERR_FULL){
            creep.memory.busy = true
            return
        }
        
        // Phase 1: go to spot
        if (creep.pos.x == workspace.x && creep.pos.y == workspace.y) {
            creep.memory.createJobToMove = true
            return
        }
        
        if (!creep.memory.createJobToMove) {
            creep.room.addJob(new CreepMove(creep.id, position))
            creep.memory.createJobToMove = true
        }
    })
}

global.CreepMove = function (creep_id, workspace, range) {
    Job.call(this, "carrier")
    this.creep_id = creep_id
    this.drop_at_workspace = workspace
    this.range = range
    this.run = profiler(profiler.SHOW, function creep_puller(creep) {
        const {creep_id, drop_at_workspace, range} = this
        const creep_to_pull = Game.getObjectById(creep_id)
    
        if (!creep_to_pull) {
            this.done()
            return
        }
        
        let index1 = creep_to_pull.move(creep)
        let index2 = creep.pull(creep_to_pull)
        
        if (!drop_at_workspace) {
            this.done()
            return
        }
        
        if (index1 == OK && index2 == OK) {
            if (creep.pos.inRangeTo(drop_at_workspace.x, drop_at_workspace.y, range)) {
                this.memory.reached = OK
                return
            }

            if (this.memory.reached == OK && creep.moveTo(creep_to_pull) == OK) {
                this.done()
                return
            }
            
            this.moveTo(drop_at_workspace.x, drop_at_workspace.y)
            return
        }
        
        creep.moveTo(creep_to_pull)
    })
}