Job.prototype.done = function () {
    this.done = true
}