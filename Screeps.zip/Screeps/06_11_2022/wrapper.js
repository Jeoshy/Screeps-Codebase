global.profiler = function (show, func) {
    const funcName = func.name;

    if (typeof func !== "function") {
        console.log(funcName, "is not a function")
        return
    }

    function profiler () {
        for (let element in func) {
            if (func.hasOwnProperty(element)) {
                this[element] = func[element]
            }
        }

        let cpu = Game.cpu.getUsed()
        const result = func.apply(this, arguments)
        if (show) {console.log(funcName, "used cpu:", Game.cpu.getUsed() - cpu)}
        return result
    }

    return profiler
}

global.profiler.SHOW = true
global.profiler.HIDE = false