Room.prototype.standard = profiler(profiler.SHOW, function initialization_standard_room() {
    switch(this.memory.level) {
        case 1:
            const count_harvest = this.add_harvest_jobs(3)
            this.add_spawn(["harvester", "carrier"], {count: count_harvest})

            const count_upgrader = this.add_upgrader_jobs(count_harvest)
            this.add_spawn(["upgrader"], {count: count_upgrader})
            break;
    }
})

Room.prototype.add_harvest_jobs = profiler(profiler.HIDE, function add_harvest_jobs(count_per_source = 1) {
    const {harvest_spots} = this.memory
    
    let count = 0
    for (const source_id in harvest_spots) {
        let workspaces = harvest_spots[source_id]

        if (workspaces.length > count_per_source) {
            workspaces.length = count_per_source
        }

        for (const workspace of workspaces) {
            this.add_job(new Harvest(source_id, workspace))
            count++
        }
    }

    return count
})

Room.prototype.add_upgrader_jobs = profiler(profiler.HIDE, function add_upgrader_jobs(count_upgrader) {
    const {upgrade_spots} = this.memory

    for (let i = 0; i < count_upgrader; i++) {
        this.add_job(new Upgrader(upgrade_spots[i]))
    }
})

Room.prototype.add_job = profiler(profiler.HIDE, function add_job (job, {count = 1} = {}) {
    const room_cache = Cache[this.name]
    job.room_name = this.name
    job.id = room_cache.job_count

    for (let i = 0; i < count; i++) {
        //room_cache.jobs[room_cache.job_count] = job
        room_cache.jobs.push(job)
        room_cache.job_count++
    }
})

Room.prototype.add_spawn = profiler(profiler.HIDE, function add_spawn (creep_names, {count = 1} = {}) {
    const room_cache = Cache[this.name]

    for (let i = 0; i < count; i++) {
        for (const name of creep_names) {
            const creep_template = new global[name](this.name, i)
            //room_cache.spawns[creep_template.name] = creep_template
            room_cache.spawns.push(creep_template)
        }
    }
})