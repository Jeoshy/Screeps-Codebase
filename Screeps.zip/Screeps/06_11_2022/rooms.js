Room.prototype.STANDARD = "standard"
Room.prototype.RAPID = "rapid"

Room.prototype.initialize = profiler(profiler.SHOW, function room_initialize () {
    // && false
    if (Cache[this.name].resetted && this.memory.level === this.controller.level) {
        return
    }

    Cache[this.name].resetted = true
    //Cache[this.name] = {job_count: 0, jobs: [], spawns: {}}

    const m = this.memory
    m.level = this.controller.level
    
    if (!m.roomType) {m.roomType = this.STANDARD}
    m.jobs = []
    m.droppoints = {}
    m.upgrade_spots = this.find_upgrade_spots()
    m.harvest_spots = this.find_harvest_spots()

    this[this.memory.roomType]()
})

Room.prototype.update = profiler(profiler.SHOW, function room_update () {
    this.initialize()
    this.creep_spawn()
})

Room.prototype.creep_spawn = profiler(profiler.SHOW, function creep_spawn () {
    const spawns = this.find(FIND_MY_SPAWNS)
    const spawn = spawns.find((s) => {return s.spawning == null})
    
    if (!spawn) {
        return
    }
    
    let creep = Cache[this.name].spawns.find((c) => {return !c.spawned})
    if (!creep){
        return
    }
    
    let {body, bodyCost, maxCost, memory, name} = creep
    if (Game.creeps[name] != undefined) {
        creep.spawned = true
        return
    }

    let full_body = []
    let energy = this.energyAvailable
    
    if (this.energyCapacityAvailable < maxCost) {
        maxCost = this.energyCapacityAvailable
    }
    
    let minimalCost = (this.find(FIND_MY_CREEPS).length - 1) * this.controller.level * 100
    
    if (this.energyCapacityAvailable < minimalCost) {
        minimalCost = this.energyCapacityAvailable
    }
    
    if (energy < minimalCost) {
        return
    }
    
    if (energy < bodyCost) {
        return
    }
    
    if (energy > maxCost) {
        energy = maxCost
    }
    
    for (i = 0; i < Math.floor(energy / bodyCost); i++) {
        full_body = full_body.concat(body)
    }
    
    let index = spawn.spawnCreep(full_body, name, {memory})
    console.log(index, name)
    if (index == OK) {
        creep.spawned = true
    }
})


Room.prototype.find_upgrade_spots = profiler(profiler.SHOW, function find_upgrade_spots () {
    const workspaces_around_controller = this.controller.pos.workspaces_in_area({range: 3})

    for (const center of workspaces_around_controller) {
        // The function workspaces_in_area spit out RoomPositions
        let workspaces = center.workspaces_in_area()
        

        if (workspaces.length === 9) {
            // Remove center piece as that is the droppoint
            this.add_to_droppoints(workspaces.splice(4, 1)[0], "upgrader")
            // Sort them from closest to controller to furthest. (a, b) are both already RoomPositions
            workspaces = workspaces.sort((a, b) => a.getRangeTo(this.controller) - b.getRangeTo(this.controller))
            return workspaces
        }
    }
})

Room.prototype.find_harvest_spots = profiler(profiler.SHOW, function find_harvest_spots () {
    const sources = this.find(FIND_SOURCES)

    let harvest_spots = {}
    for (const source of sources) {
        const workspaces = source.pos.workspaces_in_area()

        harvest_spots[source.id] = workspaces
    }
    return harvest_spots
})

Room.prototype.add_to_droppoints = profiler(profiler.SHOW, function add_to_droppoints (position, key) {
    const m = this.memory
    m.droppoints[key] = position
})

