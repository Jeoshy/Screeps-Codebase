

module.exports.loop = function () {
    room = Game.rooms["sim"]

    // Find mineable places around source
    sources = room.find(FIND_SOURCES)
    const find_mineable_around_pos = function (position) {
        const x = position.x
        const y = position.y
        const room = Game.rooms[position.roomName]

        // 3x3 area
        const TOP = y-1
        const LEFT = x-1
        const BOTTOM = y+1
        const RIGHT = x+1
        const look = room.lookAtArea(TOP, LEFT, BOTTOM, RIGHT, true)

        // Mineable
        const mineable = look.filter((pos) => {

            // Position must be around position
            if (pos.x === x && pos.y === y){
                return false
            }

            // Position must be walkable
            if (pos.terrain === "wall"){
                return false
            }

            return true
        })

        // Get array of positions
        const positions = mineable.map((pos) => {
            return new RoomPosition(pos.x, pos.y, position.roomName)
        })

        return positions
    }
    mineable = []
    for (const source of sources) {
        positions = find_mineable_around_pos(source.pos)
        mineable.push(...positions)
    }

    // Find cost of path to controller from minePos
    controller = room.controller
    const costs_and_pos = []
    costs_and_pos.length = mineable.length
    for (const index in mineable) {
        const minePos = mineable[index]

        path = room.findPath(controller.pos, minePos, {
            ignoreCreeps:true,
            ignoreDestructibleStructures:true,
        })

        cost = path.reduce((accumulater, currentValue) => {
            const look = room.lookForAt(LOOK_TERRAIN)
            let value = 0
            if (look == "plain") {
                value = 1
            }
            if (look == "swamp") {
                value = 5
            }
            if (look == "wall") {
                value = 99
            }
            return accumulater + value
        }, 0)

        costs_and_pos[index] = [cost, mineable[index]]
    }

    // Sort them based on cost of path to controller
    const compare_pos = function (a, b) {
        return a[0] - b[0]
    }
    costs_and_pos.sort(compare_pos)

    // Make the spot able to track energy and add a -50 buffer
    
}