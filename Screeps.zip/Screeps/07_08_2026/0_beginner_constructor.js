const {inheritCreep, basicCreep} = require("0_basic_creep")
const beginner_harvester = require("0_beginner_harvester")
const room_command = require("1_room_commands")
const PHASES = require("0_PHASES")
const ROLES = require("0_ROLES")
const STRATEGIES = require("1_STRATEGIES")

function beginner_constructor () {
    this.role = ROLES.BEGINNER_CONSTRUCTOR
    this.body = [WORK, CARRY, CARRY]
    this.memory = {}
    this.strategy = STRATEGIES.BEGINNER
    this.energy_needed = 200
}

inheritCreep(beginner_constructor)

/*
-----------
 Planning 
-----------
Interacts with room and strategy
*/

beginner_constructor.prototype.planned = beginner_harvester.prototype.planned

beginner_constructor.prototype.spawn = beginner_harvester.prototype.spawn

/*
-------------
     RUN
-------------
Only part where creep object is mandatory to pass
*/

beginner_constructor.prototype.alive = function (creep, room) {
    if (creep.memory.time_to_build) {

        // No energy line
        if (!creep.memory.direction_of_energy) {
            const {x, y, roomName} = creep.pos
            const creeps = room.lookForAtArea(LOOK_CREEPS, y-1, x-1, y+1, x+1, true)
            const energy_creeps = []
            
            creeps.forEach(c => {
                if (c.creep.store.getUsedCapacity() > 0 && c.creep.name != creep.name) {
                    energy_creeps.push(c.creep)
                }
            })

            if (energy_creeps.length > 0) {
                creep.memory.direction_of_energy = creep.pos.getDirectionTo(energy_creeps[0].pos)
            }
        }
        
        // Has energy line
        if (creep.memory.direction_of_energy) {


            if (creep.store.getUsedCapacity() < 50) {
                const direction = creep.memory.direction_of_energy
                const location = global.direction_to_pos(direction, creep.pos)
                const creep_spotted = room.lookForAt(LOOK_CREEPS, location.x, location.y)[0]
                if (creep_spotted) {
                    creep_spotted.transfer(creep, RESOURCE_ENERGY)
                }
                else if (Game.time % 50 == 0 && creep.store.getUsedCapacity() == 0)
                {
                    creep.memory.direction_of_energy = undefined
                }
            }
            
            if (!Number.isFinite(creep.memory.construction)) {
                const spaces = room.lookAtArea(
                    Math.max(0, creep.pos.y - 3), 
                    Math.max(0, creep.pos.x - 3), 
                    Math.min(49, creep.pos.y + 3), 
                    Math.min(49, creep.pos.x + 3), 
                    true
                )
                
                for (const space of spaces) {
                    const construction = room.constructions.get(space.x, space.y)
                    if (construction == 2) {
                        const index = room.createConstructionSite(space.x, space.y, STRUCTURE_ROAD)

                        if (index == OK) {
                            creep.memory.construction = global.register_location(space.x, space.y, room.name)
                            break;
                        }

                        if (index == ERR_INVALID_TARGET) {
                            const construction_site = room.lookForAt(LOOK_CONSTRUCTION_SITES, space.x, space.y)[0]
                            if (construction_site && construction_site.structureType == STRUCTURE_ROAD) {
                                creep.memory.construction = global.register_location(space.x, space.y, room.name)
                                break;
                            }
                        }
                    }
                }

                if (!Number.isFinite(creep.memory.construction)) {
                    creep.memory.time_to_build = false
                    creep.memory.pull_location = undefined
                    creep.memory.request = false
                    creep.memory.direction_of_energy = undefined
                    creep.drop(RESOURCE_ENERGY)
                }
            }
            else {
                const construction_location = global.get_location(creep.memory.construction)
                const construction = room.lookForAt(LOOK_CONSTRUCTION_SITES, construction_location.x, construction_location.y)[0]
                const index = creep.build(construction)

                if (index == ERR_INVALID_TARGET) {
                    creep.memory.construction = undefined
                }
            }

        }

    }
    else
    {
        // if no pull_location, then get constructor location
        if (!Number.isFinite(creep.memory.pull_location)) {
            creep.memory.pull_location = room.get_constructor_location()
        }
        
        // Add a request for transport to constructor location
        if (!creep.memory.request) {
            const rc = new room_command().from_room(room)
            rc.add_pull_request(room, this)
            
            creep.memory.request = true
        }

        // Did constructor arrive yet?
        if (creep.memory.pull_location) {
            const pull_location = global.get_location(creep.memory.pull_location)
            if (creep.pos.isEqualTo(pull_location)) {
                creep.memory.time_to_build = true
            }
        }
    }
}

module.exports = beginner_constructor