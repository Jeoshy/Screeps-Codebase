/*
-------------------------
    BEGINNER STRATEGY
-------------------------
- The beginner strategy spawns a harvester [WORK, CARRY, CARRY] and carrier [MOVE, CARRY] for each open_location at source
- It will switch to intermediate strategy when all creeps are spawned
- The beginner strategy initializes all harvest locations, costmatrices and construction sites for the room
*/

const room_command = require("1_room_commands") 
const STRATEGY = require("1_STRATEGIES")
const ACTION = require("1_ACTIONS")
const beginner_harvester = require("0_beginner_harvester")
const beginner_carrier = require("0_beginner_carrier")
const beginner_constructor = require("0_beginner_constructor")
const {PRIORITIES, CONSTRUCTIONS} = require("1_CONSTRUCTIONS")

const beginner_strategy = function () {
    this.strategy = STRATEGY.BEGINNER
}

beginner_strategy.prototype.from_room = function(room) {
    this.room_name = room.name
    this.room = room
    return this
}
beginner_strategy.prototype.from_room_name = function (room_name) {
    this.room_name = room_name
    this.room = Game.rooms[room_name]
    return this
}

beginner_strategy.prototype.create_room_command = function() {
    const new_room_command = new room_command ()
    new_room_command.with_carry_capacity(50)
    new_room_command.and_open_space_generating_per_second(2)
    
    return new_room_command 
}

/*
---------------------
Interacts with room
---------------------
*/
beginner_strategy.prototype.perform_initialization = function (room) {
    if (!room.memory.initialization || room.memory.initialization != this.strategy) {
        this.harvest_locations(room)
        this.movement_cost_matrix(room)
        this.calculate_harvesters_and_carriers(room)
        // this.add_constructors(room) // Will probably be moved to intermediate strategy
    }
    if (room.memory.planned.length != 0) {
        room.memory.initialization = this.strategy
    }
}

beginner_strategy.prototype.harvest_locations = function (room) {
    const room_command = this.create_room_command()
    const sources = room.find(FIND_SOURCES)
    const command = room_command.from_room(room).use_object(room.controller).get_X(8).in_range(1)
    this.open_space_around_sources  = room_command.closest_open_spaces_from_objects(sources).execute()
    room.harvest_locations = []

    for (const source of sources) {
        const open_spaces = room_command.closest_open_spaces_from_object(source).execute()
        open_spaces.reverse()

        if (open_spaces.length <= 1) {
            continue;
        }

        open_spaces.forEach(open_space => {
            const index = global.register_location(
                open_space.x, 
                open_space.y, 
                source.room.name,
                source.id
            )
            room.harvest_locations.push(index)
        });

    }
}

beginner_strategy.prototype.calculate_harvesters_and_carriers = function(room) {
    const open_space_around_sources = this.open_space_around_sources
    const creeps = []
    total_carriers = 0
    const index = 0
    const first_open_space = open_space_around_sources[0]
    const last_open_space = open_space_around_sources[open_space_around_sources.length -1]
    // To intialize correctly lol
    room.spawns
    const spawn_location = global.get_location(room.spawns[0])

    // Add a carrier before harvester
    let carrier = new beginner_carrier()
    carrier.make_ready_to_spawn(index)
    carrier.memory.pull = "wait"
    carrier.memory.direction = room.routes.get(first_open_space.x, first_open_space.y)
    creeps.push(carrier)
    
    for (const open_space of open_space_around_sources) {
        let path = undefined
        if (open_space instanceof RoomPosition) {
            path = room.findPath(spawn_location, open_space.pos)
        }
        else 
        {
            const pos = new RoomPosition(open_space.x, open_space.y, room.name)
            path = room.findPath(spawn_location, pos)
        }

        // Hardcoded energy per second
        total_carriers += 2 / (50 / path.length / 2)
        
        const harvester = new beginner_harvester()
        harvester.make_ready_to_spawn(index)
        creeps.push(harvester)
            
        while (total_carriers > 1) {
            carrier = new beginner_carrier()
            carrier.make_ready_to_spawn(index)
            carrier.memory.direction = room.routes.get(open_space.x, open_space.y)
            creeps.push(carrier)
            total_carriers--
        }
    } 

    carrier = new beginner_carrier()
    carrier.make_ready_to_spawn(index)
    carrier.memory.direction = room.routes.get(last_open_space.x, last_open_space.y)
    creeps.push(carrier)
        
    for (const creep of creeps) {
        creep.add_to_planned(room)
    }
}

beginner_strategy.prototype.switch = function (room) {
    if (room.memory.planned.length == 0) {
        room.memory.strategy = STRATEGY.INTERMEDIATE
    }
}

global.find_path = function(from_pos, to_pos) {
    return PathFinder.search(from_pos, { pos: to_pos, range: 0 }, {
        // 2. Pass the roomCallback function
        roomCallback: function(roomName) {
            let room = Game.rooms[roomName];
            if (!room) return; // Returns undefined if no visibility, defaulting to raw terrain

            // 3. Instantiate a fresh CostMatrix
            let costs = room.costs

            // 4. Block structures (impassable = 255)
            room.find(FIND_STRUCTURES).forEach(function(struct) {
                if (struct.structureType !== STRUCTURE_CONTAINER && 
                        (struct.structureType !== STRUCTURE_RAMPART || !struct.my)) {
                    // Block walls, spawns, extensions, and enemy ramparts
                    costs.set(struct.pos.x, struct.pos.y, 255);
                }
            });

            // 5. Avoid pull spawn spot
            for (const location_id of room.spawns) {
                const location = global.get_location(location_id)
                costs.set(location.x - 1, location.y, 255)
            }

            const harvest_locations = room.harvest_locations
            for (const location_id of harvest_locations) {
                const location = global.get_location(location_id)
                costs.set(location.x, location.y, 255)
            }

            // 6. Return the populated matrix to the pathfinder
            return costs;
        },
        // Optional configuration
        plainCost: 5,
        swampCost: 10    
    });
}

beginner_strategy.prototype.movement_cost_matrix = function (room) {
    /*
    The creep can move by looking at its current location and read a number between 1-8
    Some tiles numbered with a nine, require the room to send a number between 1-8
    Those tiles change the trajectory of a creep
    
    Assume open_locations are close together. Each source has at max 2 open_locations
    First, create a path until first open_location. Find another path to second open_location
    These paths see open_locations as impassable. Then from last open_location, find path back to drop_off/spawn point

    if source != known_source and previous_location == undefined, then find path from spawn_point to first open_location
    if source = known_source, then find path from open_location to next open_location
    if source != known_source, thenf find from previous open_location back to spawn_point and find path from spawn_point to next open_location
    */
    
    room.costs = new PathFinder.CostMatrix()
    const harvest_locations = room.harvest_locations
    const spawn = global.get_location(room.spawns[0])
    const spawn_point = new RoomPosition(spawn.x, spawn.y-1, "sim")
    const sources = room.find(FIND_SOURCES)

    room.register_action(spawn_point.x, spawn_point.y, ACTION.CHOOSE)
    room.register_no_constructor_site(spawn.x, spawn.y -1, ACTION.CHOOSE)
    room.register_no_constructor_site(spawn.x -1, spawn.y, ACTION.CHOOSE)

    const source_to_location = {}
    for (const location_id of harvest_locations) {
        const location = global.get_location(location_id)
        const source = global.get_linked_object(location_id)
        room.costs.set(location.x, location.y, 255)
        room.register_no_constructor_site(location.x, location.y)
        room.register_construction_site(location.x, location.y, STRUCTURE_CONTAINER)
        
        if (!source_to_location[source.id]) {
            source_to_location[source.id] = []
        }
        
        source_to_location[source.id].push(location)
    }

    const source_to_keeper = {}
    for (const source of sources) {
        if (!(source.id in source_to_location)) {
            continue;
        }


        const {x, y, name} = source.pos
        const spaces = room.lookAtArea(
            Math.max(0, y - 2), 
            Math.max(0, x - 2), 
            Math.min(50, y + 2), 
            Math.min(50, x + 2), 
            true
        )
        const open_spaces = spaces.filter((space) => (
            space.type === "terrain" && space.terrain !== "wall" && room.costs.get(space.x, space.y) != 255
        ))

        const locations = source_to_location[source.id]

        for (const space of open_spaces) {
            space.pos = new RoomPosition(space.x, space.y, "sim")
            let value = 0
            for (const location of locations) {
                value += global.find_path(location, space.pos).path.length
            }
            space.value = value
        }
        open_spaces.sort((a, b) => a.value - b.value)

        let count = 0 
        source_to_keeper[source.id] = []
        while (locations.length > count) {
            open_space = open_spaces.shift()
            room.costs.set(open_space.x, open_space.y, 1)

            const x = open_space.x
            const y = open_space.y
            const spaces = room.lookAtArea(
                Math.max(0, y - 1), 
                Math.max(0, x - 1), 
                Math.min(50, y + 1), 
                Math.min(50, x + 1), 
                true
            )
            const harvest_spots = spaces.filter((space) => (
                room.costs.get(space.x, space.y) == 255
            ))

            for (const harvest_spot of harvest_spots) {
                room.costs.set(harvest_spot.x, harvest_spot.y, 254)
                count++
                source_to_keeper[source.id].push(open_space)
                room.register_action(open_space.x, open_space.y, ACTION.WITHDRAW_CREEP)
                // room.register_action(open_space.x, open_space.y, ACTION.PICKUP)
                const direction = new RoomPosition(open_space.x, open_space.y, room.name).getDirectionTo(harvest_spot.x, harvest_spot.y)
                room.register_linked_location(open_space.x, open_space.y, direction)

                // Here I can connect open_space with harvest spotds
                break;
            }
        }
    }

    // Connect all keepers with paths
    source_to_path = {}
    for (const source_id in source_to_keeper) {
        const locations = source_to_keeper[source_id]
        let path = []
        for (let i = 1; i < locations.length; i++) {
            const previous_location = locations[i -1]
            const location = locations[i]
            path.push(...global.find_path(previous_location.pos, location.pos).path)  
        }
        for (const tile of path) {
            room.costs.set(tile.x, tile.y, 1)
        }
        source_to_path[source_id] = path
    }

    for (const source_id in source_to_keeper) {
        const locations = source_to_keeper[source_id]
        for (const location of locations) {
            const x = location.x
            const y = location.y
            const spaces = room.lookAtArea(
                Math.max(0, y - 1), 
                Math.max(0, x - 1), 
                Math.min(50, y + 1), 
                Math.min(50, x + 1), 
                true
            )
            location.connections = spaces.filter((space) => (
                room.costs.get(space.x, space.y) == 1
            )).length
        }

        // Sort who has the least connections, signalling endpoints. Only need a in and out point
        locations.sort((a, b) => a.connections - b.connections)
        locations.length = locations.length < 2? locations.length : 2
        
        // Find which one of the endpoints is closer to spawnpoint
        locations.forEach(location => {
            location.distance = global.find_path(location.pos, spawn_point).path.length
        });
        locations.sort((a, b) => a.distance - b.distance)
        

        room.costs.set(locations[0].x, locations[0].y, 1)
        if (locations.length == 1) {
        }
        else 
        {
            room.costs.set(locations[1].x, locations[1].y, 1)
            const path_between = global.find_path(locations[0].pos, locations[1].pos)
            let count = 0
            for (const tile of path_between.path) {
                room.costs.set(tile.x, tile.y, 255)
                
                if (count > 4) {
                    room.register_legal_constructor_site(tile.x, tile.y)
                }
                count++
            }
            const path_to = global.find_path(spawn_point, locations[0].pos)
            for (const tile of path_to.path) {
                room.costs.set(tile.x, tile.y, 255)
                // new RoomVisual("sim").circle(tile.x, tile.y, {fill:"purple"})

                const [x, y] = [tile.x, tile.y]
                const spaces = room.lookAtArea(
                    Math.max(0, y - 2), 
                    Math.max(0, x - 2), 
                    Math.min(50, y + 2), 
                    Math.min(50, x + 2), 
                    true
                )

                spaces.forEach((space) => {
                    if(tile.inRangeTo(space.x, space.y, 2) && room.costs.get(space.x, space.y) != 255 && space.type === "terrain" && space.terrain !== "wall") {
                        const value = Math.max(room.costs.get(space.x, space.y) - 2, 1)
                        room.costs.set(space.x, space.y, value)
                    }
                })

            }
            const path_from = global.find_path(locations[1].pos, spawn_point)
            for (const tile of path_from.path) {
                // new RoomVisual("sim").circle(tile.x, tile.y, {fill:"green"})
                room.register_legal_constructor_site(tile.x, tile.y)
            }
            const final_path = [...path_to.path, ...path_between.path, ...path_from.path]

            const tile_before_entering = final_path[final_path.length -2]
            const direction_to_entering = tile_before_entering.getDirectionTo(spawn_point)
            room.register_action(tile_before_entering.x, tile_before_entering.y, ACTION.WAIT)
            room.register_linked_location(tile_before_entering.x, tile_before_entering.y, direction_to_entering)

            const direction_route = spawn_point.getDirectionTo(final_path[0])
            for (let i = 0; i < final_path.length -1; i++) {
                const current_tile = final_path[i]
                const next_tile = final_path[i+1]
                const current_direction = current_tile.getDirectionTo(next_tile)
                room.register_direction(current_tile.x, current_tile.y, current_direction)
                room.register_construction_site(current_tile.x, current_tile.y, STRUCTURE_ROAD)
                room.register_no_constructor_site(current_tile.x, current_tile.y)
                room.register_route(current_tile.x, current_tile.y, direction_route)

                // Register for each tile without direction to point to current_tile with adjacent tiles
                const [x, y] = [current_tile.x, current_tile.y]
                const spaces = room.lookAtArea(
                    Math.max(0, y - 1), 
                    Math.max(0, x - 1), 
                    Math.min(50, y + 1), 
                    Math.min(50, x + 1), 
                    true
                )

                for (const space of spaces) {
                    const direction = room.directions.get(space.x, space.y)
                    if (!direction) {
                        const outside_tile = new RoomPosition(space.x, space.y, room.name)
                        const direction_in = outside_tile.getDirectionTo(current_tile.x, current_tile.y)
                        room.register_direction(space.x, space.y, direction_in)
                        room.register_route(space.x, space.y, direction_route)
                    }
                }
            }
        }
    }

    room.register_direction(spawn_point.x, spawn_point.y, 0)
    room.register_route(spawn_point.x, spawn_point.y, 0)

    room.serialize_costMatrices()
    room.create_constructor_locations()
}


module.exports = beginner_strategy
