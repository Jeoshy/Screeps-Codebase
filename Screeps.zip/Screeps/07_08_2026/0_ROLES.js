roles = {
    BEGINNER_HARVESTER: "beginner_harvester",
    BEGINNER_CARRIER: "beginner_carrier",
    BEGINNER_CONSTRUCTOR: "beginner_constructor",
    INTERMEDIATE_HARVESTER: "intermediate_harvester",
    INTERMEDIATE_CARRIER: "intermediate_carrier",
    INTERMEDIATE_CONSTRUCTOR: "intermediate_constructor",
}

module.exports = roles