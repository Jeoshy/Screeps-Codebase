const PHASES = require("0_PHASES")
const missing_function = (creepName, functionName) => {console.log(creepName, "has no", functionName, "function yet")}
const ACTION = require("1_ACTIONS")

/*
This is planning phase code of every creep
The actual creep entity in game is separated from these functions
Therefore, the initialization does not need the creep entity
*/
function basic_creep () {
}

/*
--------------------
Initialization LOGIC
--------------------
*/
basic_creep.prototype.called = function (name) {
    this.name = name
    return this
}
basic_creep.prototype.from_room = function (room) {
    this.room_name = room.name
    this.room = room
    return this
}
basic_creep.prototype.from_room_name = function (room_name) {
    this.room_name = room_name
    this.room = Game.rooms[room_name]
    return this
}
basic_creep.prototype.add_memory_with_name = function (name) {
    if (!(name in Memory.creeps_planning)) {
        Memory.creeps_planning[name] = {}
    }
    if (!("memory" in Memory.creeps_planning[name])) {
        Memory.creeps_planning[name].memory = {}
    }
    if (!this.creep_planning) {
        this.creep_planning = Memory.creeps_planning[name]
    }
    return this
}
basic_creep.prototype.initialize_for_spawn = function () {
    throw new Error("The role", this.role, "has no initialization for spawn")
}
basic_creep.prototype.check_body = function (body) {
    if (body instanceof Array) {
        return this
    }
    throw new Error("Tried to make a body that is not an Array, but: " + body, " in role " + this.role)
}
basic_creep.prototype.check_memory = function (memory) {
    if (memory instanceof Object) {
        return this
    }
    throw new Error("Tried to make a memory that is not an Object, but: " + memory, " in role " + this.role)
}
basic_creep.prototype.check_priority = function (priority) {
    if (Number.isFinite(priority)) {
        return this
    }
    throw new Error("Tried to make a priority that is not an Number, but: " + priority.constructor.name + " in role " + this.role)
}
basic_creep.prototype.use_body = function (body) {
    this.check_body(body)
    this.body = body
    return this
}
basic_creep.prototype.use_memory = function (memory) {
    this.check_memory(memory)
    this.memory = memory
    return this
}
basic_creep.prototype.add_priority = function (priority = 999) {
    this.check_priority(priority)
    this.priority = priority
    return this
}
basic_creep.prototype.allowed_to_respawn = function () {
    this.memory.respawn = true
    return this
}
basic_creep.prototype.generate_name = function () {
    const vowels = ['a', 'e', 'i', 'o', 'u'];
    const consonants = ['b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z'];
    const max_length = 50
    const min_length = 5

    // Random length between 5 and 20
    let name = ""
    let i = 0

    while (i < min_length || name in Memory.creeps_planning) {
        if (i % 2 === 0) {
        // Even index: consonant
        name += consonants[Math.floor(Math.random() * consonants.length)];
        } else {
        // Odd index: vowel
        name += vowels[Math.floor(Math.random() * vowels.length)];
        }
        i++
    }

    // Capitalize the first letter
    this.name = name.charAt(0).toUpperCase() + name.slice(1);

    return this 
}
basic_creep.prototype.make_ready_to_spawn = function (priority = 0) {
    this.use_body(this.body).use_memory(this.memory).generate_name().add_priority(priority)
}

/*
-----------------
   SPAWN LOGIC
-----------------
Each creep has digital copy linked with their name and role from memory
This copy can find itself in either of the 5 lists:
- planned
- spawn
- alive
- trash
- dead 
Each list has a corresponding function with conditions to tell where what needs to go and what to perform
Each strategy introduces the creeps into the planned
*/
basic_creep.prototype[PHASES.PLANNED] = function () {
    /*
    Planned function gets pre-determined and/or a list of executables initialized from strategy
    The list of executables represents functions that are dependent on the state of the room
    The pre-determined has to with the strategy taken and ought not to change
    */
    missing_function(this.name, PHASES.PLANNED)
    return this
}
basic_creep.prototype[PHASES.SPAWN] = function () {
    missing_function(this.name, PHASES.SPAWN)
    return this
}
basic_creep.prototype[PHASES.ALIVE] = function () {
    missing_function(this.name, PHASES.ALIVE)
    return this
}
basic_creep.prototype[PHASES.TRASH] = function () {
    missing_function(this.name, PHASES.TRASH)
    return this
}
basic_creep.prototype[PHASES.DEAD] = function () {
    missing_function(this.name, PHASES.DEAD)
    return this
}
basic_creep.prototype.spawn_at_room_capacity = function (energy) {
    this.creep_planning.room_capacity = energy

    return this
}
basic_creep.prototype.add_to_planned = function(room) {
    /*
    As this code influences the game, the data send needs to fulfill certain assumptions
    A few checks:
    - Does the creep have a room?
    - Does the creep have a name?
    - Does the creep have a unique name? (not in creeps_planning yet)
    - Does the creep have a memory?
    - Does the creep have a body in creeps_planning?
    - Does the creep have a role?

    Then, perform:
    - Add creep name to current room planned
    - Add memory, body and role to creeps_planning
    */

    if (!room || !(room.name in Game.rooms)) {
        throw new Error("Trying to add new creep without assigning a room")
    }
    if (!this.name) {
        throw new Error("Trying to add new creep in room", this.room.name)
    }
    if (this.name in Memory.creeps_planning) {
        throw new Error("Trying to add new creep", name, "in room", room, "with non-unique name")
    }
    if (!this.memory) {
        throw new Error("Trying to add new creep", name, "in room", room, "with no memory")
    }
    if (!this.body) {
        throw new Error("Trying to add new creep", name, "in room", room, "with no body")
    }
    if (!this.role) {
        throw new Error("Trying to add new creep", name, "in room", room, "with no role")
    }
    if (!Number.isFinite(this.priority)) {
        this.priority = 999
    }

    Memory.creeps_planning[this.name] = {}
    this.creep_planning = Memory.creeps_planning[this.name]
    this.creep_planning.memory = this.memory
    this.creep_planning.body = this.body
    this.creep_planning.role = this.role
    this.creep_planning.priority = this.priority
    room.memory.planned.push(this.name)
}
basic_creep.prototype.switch = function (new_list) {
    const list_names = [PHASES.PLANNED, PHASES.SPAWN, PHASES.ALIVE, PHASES.TRASH, PHASES.DEAD]
    const room = Game.rooms[this.room_name]

    // General checks
    if (new_list == PHASES.SPAWN && this.room.memory[PHASES.SPAWN].length >= this.room.spawn_spots) {
        return
    }

    // Find the list and index where the creep is currently in
    let found = false
    let found_list = undefined;
    let index_creep = undefined;
    for (const list_name of list_names) {
        const list = room.memory[list_name]
        for (const index in list) {
            const creep_name = list[index]
            if (creep_name == this.name) {
                found = true
                index_creep = index
                break;
            }
        }
        if (found == true) {
            found_list = list
            break;
        }
    }

    // If found remove from current list
    if (found) {
        found_list.splice(index_creep, 1)
    }
    // Always add to new list
    room.memory[new_list].push(this.name)

    return this
}

// These are basic actions from costmatrix 'actions'
// These can be placed in the alive to allow for flexibility to which creep it does apply which it doesnt
Object.defineProperty(Creep.prototype, "action", {
    get: function () {
        const {x, y, _} = this.pos
        return function_names[this.room.actions.get(x, y)]
    }
})

basic_creep.prototype.get_action = function (creep) {
    if (creep.action) {
        this[creep.action](creep)
    }
}

Object.defineProperty(Creep.prototype, "linked_location", {
    get: function () {
        const {x, y, roomName} = this.pos
        return global.direction_to_pos(this.room.linked_locations.get(x, y), this.pos)
    }
})

/*
----------------
      CREEP
----------------
*/

global.direction_to_pos = function (direction, current_pos) {

    if (!current_pos instanceof RoomPosition) {
        throw new Error("In the global function direction_to_pos a non_RoomPosition object was passed through")
    }

    const {x, y, roomName} = current_pos
    switch (direction) {
        case 1:
            return new RoomPosition(x, y - 1, roomName)
        case 2:
            return new RoomPosition(x + 1, y -1, roomName)
        case 3:
            return new RoomPosition(x + 1, y, roomName)
        case 4:
            return new RoomPosition(x + 1, y + 1, roomName)
        case 5:
            return new RoomPosition(x, y + 1, roomName)
        case 6:
            return new RoomPosition(x - 1, y + 1, roomName)
        case 7:
            return new RoomPosition(x - 1, y, roomName)
        case 8:
            return new RoomPosition(x - 1, y - 1, roomName)
    }
}

const function_names = {
    1: "pickup",
    2: "withdraw_creep",
    3: "drop",
    4: "transfer",
    5: "choose",
    6: "wait"
}
basic_creep.prototype.pickup = function (creep) {
    const resources = creep.linked_location.lookFor(LOOK_RESOURCES)
    const energy = resources.find(r => r.resourceType === RESOURCE_ENERGY);

    creep.pickup(energy)
}
basic_creep.prototype.withdraw_creep = function (creep) {
    const creep_that_transfers = creep.linked_location.lookFor(LOOK_CREEPS)[0]

    if (creep_that_transfers) {
        creep_that_transfers.transfer(creep, RESOURCE_ENERGY)
    }
}
basic_creep.prototype.drop = function (creep) {
    creep.drop(RESOURCE_ENERGY)
}
basic_creep.prototype.move = function (creep) {
    const {x, y, _} = creep.pos
    creep.move(creep.room.directions.get(x, y))

    if (creep._cancelOrder) {
        const already_a_creep = creep.linked_location.lookFor(LOOK_CREEPS)[0]

        if (already_a_creep) {
            creep.cancelOrder('move');
        }
    }
}
basic_creep.prototype.wait = function (creep) {
    creep._cancelOrder = true
}
basic_creep.prototype.choose = function (creep) {
    if (creep.memory.recycle) {
        creep.drop(RESOURCE_ENERGY)
        const spawn = creep.pos.findClosestByRange(FIND_MY_SPAWNS)
        spawn.recycleCreep(creep)
    }
}

function inheritCreep (creep) {
    creep.prototype = Object.create(basic_creep.prototype)
}

module.exports = {inheritCreep, basic_creep}

