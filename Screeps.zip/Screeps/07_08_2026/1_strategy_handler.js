// Collects all strategies and generates commands based on strategy chosen
// The strategy chosen affects used roomcommands from the corresponding strategy

const STRATEGIES = require("1_STRATEGIES")
const beginner = require("1_strategy_beginner_room")
const intermediate = require("1_strategy_intermediate_room")

const create_strategy = function (strategy_name, room_name) {
    
    // Initialize role
    let strategy = undefined
    switch(strategy_name) {
        case STRATEGIES.BEGINNER:
            strategy = new beginner()
            break;
        case STRATEGIES.INTERMEDIATE:
            strategy = new intermediate()
            break;
    }

    if (!(strategy instanceof Object)) {
        throw new Error("Room " + room_name + " has an undefined strategy: " + strategy_name)
    }

    // Add initialization
    strategy.from_room_name(room_name)
    return strategy
}

module.exports = create_strategy