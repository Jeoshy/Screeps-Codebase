const max_heap = require("1_max_heap")
const [PRIORITIES, CONSTRUCTIONS] = require("1_CONSTRUCTIONS")

const room_command = function () {
    this.carry_capacity = 150
    this.max_energy_per_tick_open_space = 5
}

room_command.prototype.execute = function () {
    return this.result
}

room_command.prototype.from_room = function (room) {
    this.room = room
    return this
}
room_command.prototype.from_room_name = function (room_name) {
    this.room = Game.rooms[room_name]
    return this
}
room_command.prototype.use_location = function (location) {
    // Must be a location ofcourse
    if ((location instanceof RoomPosition) == false) {
        throw new Error ("In room_command.prototype.use_location, location is not a RoomPosition class", location)
    }
    this.location = location
    return this
}
room_command.prototype.use_object = function (object) {
    this.object = object
    this.location = object.pos
    return this
}
room_command.prototype.get_X = function (amount) {
    this.amount = amount
    return this
}
room_command.prototype.in_range = function (range) {
    this.range = range
    return this
}
room_command.prototype.closest_open_spaces_from_object = function (object) {
    const {x, y, _} = object.pos
    const spaces = this.room.lookAtArea(
        Math.max(0, y - this.range), 
        Math.max(0, x - this.range), 
        Math.min(50, y + this.range), 
        Math.min(50, x + this.range), 
        true
    )
    const open_spaces = spaces.filter((space) => (space.type === "terrain" && space.terrain !== "wall"))

    open_spaces.forEach((open_space) => {
        open_space.distance = this.location.getRangeTo(open_space)
    })
    open_spaces.sort((a, b) => a.distance - b.distance)
    open_spaces.length = open_spaces.length < this.amount ? open_spaces.length : this.amount
    
    this.result = open_spaces
    return this
}
room_command.prototype.closest_open_spaces_from_objects = function (objects) {
    objects.forEach((object) => {
        object.distance = this.location.getRangeTo(object)
    })
    objects.sort((a, b) => a.distance - b.distance)

    const open_spaces_list = []
    
    for (let object of objects) {
        this.closest_open_spaces_from_object(object)
        if (this.result.length == 0) {
            continue;
        }
        open_spaces_list.push(...this.result)
    }

    this.result = _.compact(open_spaces_list)
    return this
}
room_command.prototype.with_carry_capacity = function (number) {
    this.carry_capacity = number
    return this
}
room_command.prototype.and_open_space_generating_per_second = function (energy) {
    this.max_energy_per_tick_open_space = energy
    return this
}
room_command.prototype.calculate_carriers = function (open_spaces) {
    total_carriers = 0
    for (const open_space of open_spaces) {
        let path = undefined
        if (open_space instanceof RoomPosition) {
            path = this.room.findPath(this.location, open_space.pos)
        }
        else 
        {
            const pos = new RoomPosition(open_space.x, open_space.y, this.room.name)
            path = this.room.findPath(this.location, pos)
        }
        
        total_carriers += this.max_energy_per_tick_open_space / (this.carry_capacity / path.length / 2)
    }
    
    this.result = Math.ceil(total_carriers)
    return this
}

/*
------------------------
        SPAWNS
------------------------
*/
Object.defineProperty(Room.prototype, "spawn_spots", {
    get: function () {
        if (!this.memory.spawn_spots || Game.tick % 100 == 0) {
            this.memory.spawn_spots = this.find(FIND_MY_SPAWNS).length
        }
        
        return this.memory.spawn_spots
    }
})

Object.defineProperty(Room.prototype, "spawns", {
    get: function () {
        if (!this.memory.spawns) {
            const spawns = this.find(FIND_MY_SPAWNS)
            this.memory.spawns = []
            
            spawns.forEach(spawn => {
                const index = global.register_location(
                    spawn.pos.x, 
                    spawn.pos.y, 
                    spawn.room.name,
                    spawn.id
                )
                this.memory.spawns.push(index)
            });
        }
        
        return this.memory.spawns
    }
})

Object.defineProperty(Room.prototype, "recycle_spots", {
    get: function () {
        if (!this.memory.recycle_spots) {
            const spawns = this.find(FIND_MY_SPAWNS)
            this.memory.recycle_spots = []
            
            spawns.forEach(spawn => {
                const index = global.register_location(
                    spawn.pos.x, 
                    spawn.pos.y - 1, 
                    spawn.room.name,
                    spawn.id
                )
                this.memory.recycle_spots.push(index)
            });
        }
        
        return this.memory.recycle_spots
    }
})

/*
------------------------
        PULLING
------------------------
*/
Object.defineProperty(Room.prototype, "pull_requests", {
    get: function () {
        if (!this.memory.pull_requests) {
            this.memory.pull_requests = []
        }
        
        return this.memory.pull_requests
    }
})

room_command.prototype.add_pull_request = function (room, creep_digital) {
    const spawn_spot = creep_digital.creep_planning.spawn_spot
    if (!Number.isFinite(spawn_spot)){
        throw new Error("In add_pull_request of room_commands, no valid number given for spawn_spot")
    }

    room.pull_requests.push(creep_digital.name)
}

/*
------------------------
        HARVEST
------------------------
Create a defineproperty function that cycles through open_harvest location ids
*/
Object.defineProperty(Room.prototype, "harvest_locations", {
    get: function () {
        if (!this.memory.harvest_locations) {
            this.memory.harvest_locations = []
        }
        
        return this.memory.harvest_locations
    }
})

Room.prototype.get_harvest_location = function () {
    if (!Number.isFinite(this.memory.cycle_harvest_location) || this.memory.cycle_harvest_location >= this.memory.harvest_locations.length) {
        this.memory.cycle_harvest_location = 0
    }
    this.memory.cycle_harvest_location++
    return this.memory.harvest_locations[this.memory.cycle_harvest_location -1]
}

/*
-----------------------------
       CONSTRUCTION
-----------------------------
TODO:
- Code a max-heap for all constructor locations
- The max-heap ignores locations not adjacent to carry energy lines
- The max-heap ignores locations with 255 as value
- Code when giving it to a constructor the root gets removed 
- Code when constructor dies, the location gets put back
- Code when constructor checks for construction sites, but can't find any, it will delete location and ofcourse request a new one

Max-heap sudo code

*/
Object.defineProperty(Room.prototype, "constructor_locations", {
    get: function () {
        if (!this.memory.constructor_locations) {
            this.memory.constructor_locations = []
        }

        return this.memory.constructor_locations
    }
})

Room.prototype.create_constructor_heap = function () {
    const heap = new max_heap()
    heap.get_value = function (i) {

        if (heap.constructors == undefined) {
            throw new Error("In create_constructor_heap, heap.constructors is undefined")
        }

        const [x, y] = i.split("x")
        return this.constructors.get(x, y)
    }
    return heap
}

Room.prototype.create_constructor_locations = function () {
    this.memory.constructor_locations = []

    
    // Clone all legal constructor locations
    const road_constructor_locations = this.constructors.clone()
    const construction_locations = this.constructions.clone()
    const heap = this.create_constructor_heap()
    heap.max_heap = []
    heap.constructors = road_constructor_locations

    // First, rank all legal constructor locations that are not 255, and are adjacent to carry energy lines
    for (let x = 0; x < 50; x++) {
        for (let y = 0; y < 50; y++) {
            const construction = construction_locations.get(x, y)

            // Skip if construction doesn't exist
            if (PRIORITIES[construction] === undefined) {
                continue;
            }

            const spaces = this.lookAtArea(
                Math.max(0, y - 3), 
                Math.max(0, x - 3), 
                Math.min(49, y + 3), 
                Math.min(49, x + 3), 
                true
            )

            spaces.forEach((space) => {
                if (road_constructor_locations.get(space.x, space.y) > 0 && road_constructor_locations.get(space.x, space.y) < 255) {
                    let change = construction
                    const value = Math.min(road_constructor_locations.get(space.x, space.y) + change, 254)
                    road_constructor_locations.set(space.x, space.y, value)
                }
            })
        }
    }

    // Second, rank all legal constructor locations
    for (let x = 0; x < 50; x++) {
        for (let y = 0; y < 50; y++) {
            const value = road_constructor_locations.get(x, y)
            if (value > 0 && value < 255) {
                heap.insert(x + "x" + y)
            }
        }
    }

    // Third, pick highest, then scan all nearby construction and constructors
    // Give in build radius constructors locations illegal status by -1
    // And for each construction it gives minus construction number to each nearby constructor
    // This gives illegal constructor sites still points to be chosen when ranked
    // Then refresh heap and rank it again
    // This continues until heap is empty

    count = 16
    while (count > 0 && heap.max_heap.length > 0) {
        let [x, y] = heap.extract_max().split("x")
        const location_id = global.register_location(x, y, this.name)
        this.memory.constructor_locations.push(location_id)
        x = Number(x)
        y = Number(y)

        // Mark the location as used
        road_constructor_locations.set(x, y, 0)

        // Look around location
        // Mark locations within build radius illegal
        // And every construction site nearby will give minus points to nearby constructor locations
        const spaces = this.lookAtArea(
            Math.max(0, y - 3), 
            Math.max(0, x - 3), 
            Math.min(49, y + 3), 
            Math.min(49, x + 3), 
            true
        )
        spaces.forEach((space) => {
            if (road_constructor_locations.get(space.x, space.y) > 0 && road_constructor_locations.get(space.x, space.y) < 255) {
                const illegal = road_constructor_locations.get(space.x, space.y) - 1
                road_constructor_locations.set(space.x, space.y, illegal)
                
            }

            if (construction_locations.get(space.x, space.y) > 0 && construction_locations.get(space.x, space.y) < 255) {
                const around = this.lookAtArea(
                    Math.max(0, space.y - 3), 
                    Math.max(0, space.x - 3), 
                    Math.min(49, space.y + 3), 
                    Math.min(49, space.x + 3), 
                    true
                )

                around.forEach((around_space) => {
                    if (road_constructor_locations.get(around_space.x, around_space.y) > 0 && road_constructor_locations.get(around_space.x, around_space.y) < 255) {
                        const illegal = road_constructor_locations.get(around_space.x, around_space.y) - construction_locations.get(space.x, space.y)
                        road_constructor_locations.set(around_space.x, around_space.y, illegal)
                    }
                })
            }
        })

        // Rank the heap again, and continue until heap is empty
        const new_heap = this.create_constructor_heap()
        new_heap.constructors = road_constructor_locations
        new_heap.max_heap = []
        for (let x = 0; x < 50; x++) {
            for (let y = 0; y < 50; y++) {
                const value = road_constructor_locations.get(x, y)
                if (value > 0 && value < 255) {
                    new_heap.insert(x + "x" + y)
                }
            }
        }

        // Count is hear to avoid infinite loops :)
        heap.max_heap = new_heap.max_heap
        count--
    }
}

global.reverse_directions = {
    1: 5,
    2: 6,
    3: 7,
    4: 8,
    5: 1,
    6: 2,
    7: 3,
    8: 4
}

Room.prototype.get_constructor_location = function () {
    if (this.constructor_locations.length > 0) {
        const location_id = this.constructor_locations.shift()
    
        return location_id
    }

    return undefined
}

// Room.prototype.return_construction_location = function (location_id) {
//     const heap = this.create_constructor_heap()

//     if (heap.length() == 0) {
//         return undefined
//     }

//     const location = global.get_location(location_id)
//     const compressed =location.x + "x" + location.y
//     heap.insert(compressed)

//     // Remove registered_location in Memory.locations
// }

/*
------------------------
       COSTMATRICES
------------------------
*/
Object.defineProperty(Room.prototype, "directions", {
    get: function () {
        if (!this.memory.directions) {
            this.memory.directions = new PathFinder.CostMatrix().serialize()
        }

        if (!this._directions) {
            this._directions = PathFinder.CostMatrix.deserialize(this.memory.directions)
        }

        return this._directions
    }
})

Object.defineProperty(Room.prototype, "actions", {
    get: function () {
        if (!this.memory.actions) {
            this.memory.actions = new PathFinder.CostMatrix().serialize()
        }

        if (!this._actions) {
            this._actions = PathFinder.CostMatrix.deserialize(this.memory.actions)
        }

        return this._actions
    }
})

Object.defineProperty(Room.prototype, "linked_locations", {
    get: function () {
        if (!this.memory.linked_locations) {
            this.memory.linked_locations = new PathFinder.CostMatrix().serialize()
        }

        if (!this._linked_locations) {
            this._linked_locations = PathFinder.CostMatrix.deserialize(this.memory.linked_locations)
        }

        return this._linked_locations
    }
})

Object.defineProperty(Room.prototype, "routes", {
    get: function () {
        if (!this.memory.routes) {
            this.memory.routes = new PathFinder.CostMatrix().serialize()
        }

        if (!this._routes) {
            this._routes = PathFinder.CostMatrix.deserialize(this.memory.routes)
        }

        return this._routes
    }
})

Object.defineProperty(Room.prototype, "constructions", {
    get: function () {
        if (!this.memory.constructions) {
            this.memory.constructions = new PathFinder.CostMatrix().serialize()
        }

        if (!this._constructions) {
            this._constructions = PathFinder.CostMatrix.deserialize(this.memory.constructions)
        }

        return this._constructions
    }
})

Object.defineProperty(Room.prototype, "constructors", {
    get: function () {
        if (!this.memory.constructors) {
            this.memory.constructors = new PathFinder.CostMatrix().serialize()
        }

        if (!this._constructors) {
            this._constructors = PathFinder.CostMatrix.deserialize(this.memory.constructors)
        }

        return this._constructors
    }
})

Room.prototype.to_serialize = {}

Room.prototype.register_action = function (x, y, action) {
    this.actions.set(x, y, action)
    this.to_serialize["actions"] = true
}

Room.prototype.register_direction = function (x, y, direction) {
    if (!Number.isFinite(direction)) {
        throw new Error("In register_direction, did not give a direction, but this: " + direction)
    }
    this.directions.set(x, y, direction)
    this.to_serialize["directions"] = true
}

Room.prototype.register_linked_location = function (x, y, direction) {
    if (!Number.isFinite(direction)) {
        throw new Error("In register_linked_location, did not give a direction, but this: " + direction)
    }
    if (this.linked_locations.get(x, y) != 0) {
        return ERR_FULL
    }

    // Links locations with direction, so can only link locations adjacent to eachother
    this.linked_locations.set(x, y, direction)
    this.to_serialize["linked_locations"] = true
}

Room.prototype.register_route = function (x, y, direction) {
    if (!Number.isFinite(direction)) {
        throw new Error("In register_route, did not give a direction, but this: " + direction)
    }
    // Links locations with direction, so can only link locations adjacent to eachother
    this.routes.set(x, y, direction)
    this.to_serialize["routes"] = true
}

Room.prototype.register_construction_site = function (x, y, type) {
    if (type in CONSTRUCTIONS) {
        this.constructions.set(x, y, CONSTRUCTIONS[type])
    }
    else 
    {
        throw new Error("In register_construction_site, type is not in 1_CONSTRUCTIONS, but this: " + type)
    }

    this.to_serialize["constructions"] = true
}

Room.prototype.register_no_constructor_site = function (x, y) {
    this.constructors.set(x, y, 255)

    this.to_serialize["constructors"] = true
}

Room.prototype.register_legal_constructor_site = function (x, y) {
    const spaces = this.lookAtArea(
        Math.max(0, y - 1), 
        Math.max(0, x - 1), 
        Math.min(50, y + 1), 
        Math.min(50, x + 1), 
        true
    )

    spaces.forEach((space) => {
        if (space.type !== "terrain" || space.terrain === "wall") {
            this.constructors.set(space.x, space.y, 255)
        }

        if (this.constructors.get(space.x, space.y) > 1) {
            return
        }
        this.constructors.set(space.x, space.y, 1)
    })
}

Room.prototype.serialize_costMatrices = function () {
    for (const list_name in this.to_serialize) {
        if (this.to_serialize[list_name]) {
            this.memory[list_name] = this[list_name].serialize()
            this.to_serialize[list_name] = false
        }
    }
}

/*
-----------------------------
       SOURCE MEMORY
-----------------------------
*/
Object.defineProperty(Source.prototype, "memory", {
    configurable:true,
    get: function () {
        if (_.isUndefined(Memory.sources)) {
            Memory.sources = {}
        }
        if (!_.isObject(Memory.sources)) {
            return undefined
        }

        return Memory.sources[this.id] = Memory.sources[this.id] || {}
    },
    set: function(value) {
        if (_.isUndefined(Memory.sources)) {
            Memory.sources = {}
        }
        if (!_.isObject(Memory.sources)) {
            throw new Error('Could not set source memory');
        }

        Memory.sources[this.id] = value
    }
})

Object.defineProperty(Source.prototype, "generated", {
    configurable:true,
    get: function () {
        if (!this.memory.generated) {
            this.memory.generated = 0
        }

        if (!this.generated) {
            this.generated = this.memory.generated
        }

        return this.generated
    },
    set: function (value) {
        if (!this.memory.generated) {
            this.memory.generated = 0
        }

        this.memory.generated += value
    }
})

module.exports = room_command