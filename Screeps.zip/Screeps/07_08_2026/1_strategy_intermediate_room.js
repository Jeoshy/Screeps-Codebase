/*
-------------------------
  INTERMEDIATE STRATEGY
-------------------------
*/

const room_command = require("1_room_commands") 
const STRATEGY = require("1_STRATEGIES")
const intermediate_harvester = require("0_intermediate_harvester")
const intermediate_carrier = require("0_intermediate_carrier")
const beginner_constructor = require("0_beginner_constructor")

const intermediate_strategy = function () {
    this.strategy = STRATEGY.INTERMEDIATE
    this.with_carry_capacity = 150
    this.and_open_space_generating_per_second = 4
}

intermediate_strategy.prototype.from_room = function(room) {
    this.room_name = room.name
    this.room = room
    return this
}
intermediate_strategy.prototype.from_room_name = function (room_name) {
    this.room_name = room_name
    this.room = Game.rooms[room_name]
    return this
}

intermediate_strategy.prototype.create_room_command = function() {
    const new_room_command = new room_command ()

    
    return new_room_command 
}

/*
---------------------
Interacts with room
---------------------
*/
intermediate_strategy.prototype.perform_initialization = function (room) {
    if (!room.memory.initialization || room.memory.initialization != this.strategy) {
        this.harvest_locations(room)
        this.calculate_harvesters_and_carriers(room)
        this.add_constructors(room) // Will probably be moved to intermediate strategy
    }
    if (room.memory.planned.length != 0) {
        room.memory.initialization = this.strategy
    }
}

intermediate_strategy.prototype.add_constructors = function (room) {
    for (let i = 0; i < 3; i++) {
        const constructor = new beginner_constructor()
        constructor.make_ready_to_spawn(i)
        constructor.add_to_planned(room)
    }
}

intermediate_strategy.prototype.harvest_locations = function (room) {
    const room_command = this.create_room_command()
    const sources = room.find(FIND_SOURCES)

    // Basically only 3 open_locations for each source
    const command = room_command.from_room(room).use_object(room.controller).get_X(3).in_range(1)
    this.open_space_around_sources  = room_command.closest_open_spaces_from_objects(sources).execute()
    room.harvest_locations = []

    for (const source of sources) {
        const open_spaces = room_command.closest_open_spaces_from_object(source).execute()
        open_spaces.reverse()

        if (open_spaces.length <= 1) {
            continue;
        }

        open_spaces.forEach(open_space => {
            const index = global.register_location(
                open_space.x, 
                open_space.y, 
                source.room.name,
                source.id
            )
            room.harvest_locations.push(index)
        });

    }
}

intermediate_strategy.prototype.calculate_harvesters_and_carriers = function(room) {
    const open_space_around_sources = this.open_space_around_sources
    const creeps = []
    total_carriers = 0
    const index = 0
    const first_open_space = open_space_around_sources[0]
    const last_open_space = open_space_around_sources[open_space_around_sources.length -1]
    // To intialize correctly lol
    room.spawns
    const spawn_location = global.get_location(room.spawns[0])

    // Add a carrier before harvester
    let carrier = new intermediate_carrier()
    carrier.make_ready_to_spawn(index)
    carrier.memory.direction = room.routes.get(first_open_space.x, first_open_space.y)
    creeps.push(carrier)
    
    for (const open_space of open_space_around_sources) {
        let path = undefined
        if (open_space instanceof RoomPosition) {
            path = room.findPath(spawn_location, open_space.pos)
        }
        else 
        {
            const pos = new RoomPosition(open_space.x, open_space.y, room.name)
            path = room.findPath(spawn_location, pos)
        }

        total_carriers += this.and_open_space_generating_per_second / (this.with_carry_capacity / path.length / 2)
        
        const harvester = new intermediate_harvester()
        harvester.make_ready_to_spawn(index)
        creeps.push(harvester)
            
        while (total_carriers > 1) {
            carrier = new intermediate_carrier()
            carrier.make_ready_to_spawn(index)
            carrier.memory.direction = room.routes.get(open_space.x, open_space.y)
            creeps.push(carrier)
            total_carriers--
        }
    } 

    carrier = new intermediate_carrier()
    carrier.make_ready_to_spawn(index)
    carrier.memory.direction = room.routes.get(last_open_space.x, last_open_space.y)
    creeps.push(carrier)
        
    for (const creep of creeps) {
        creep.add_to_planned(room)
    }
}

intermediate_strategy.prototype.switch = function (room) {

}

module.exports = intermediate_strategy