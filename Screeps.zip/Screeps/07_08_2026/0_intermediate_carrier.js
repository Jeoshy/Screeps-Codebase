const {inheritCreep, basicCreep} = require("0_basic_creep")
const PHASES = require("0_PHASES")
const ROLES = require("0_ROLES")
const beginner_harvester = require("0_beginner_harvester")
const beginner_carrier = require("0_beginner_carrier")
const STRATEGIES = require("1_STRATEGIES")

/*
The beginner harvester
- spawns in with either 3 WORK as body
- requests a transport request
- knows request is done when location condition is fulfilled
- starts harvesting after locatio condition
*/

function intermediate_carrier () {
    this.role = ROLES.INTERMEDIATE_CARRIER
    this.body = [CARRY, CARRY, CARRY, MOVE, MOVE, MOVE]
    this.memory = {}
    this.strategy = STRATEGIES.INTERMEDIATE
    this.energy_needed = 300
}

inheritCreep(intermediate_carrier)

intermediate_carrier.prototype.planned = beginner_harvester.prototype.planned

intermediate_carrier.prototype.spawn = function (room, strategy) {
    // Spawn direction
    this.directions = [TOP]

    // Recycle some carriers from previous strategy
    let count = 0
    const creeps_alive = room.memory.alive
    for (const creep_name of creeps_alive) {
        console.log(creep_name)
        const creep_planning = Memory.creeps_planning[creep_name]
        const creep = Game.creeps[creep_name]
        if (
            creep && 
            !creep.memory.recycle && 
            creep_planning.role == ROLES.BEGINNER_CARRIER && 
            creep_planning.memory.direction ==  Memory.creeps_planning[this.name].memory.direction
        ) {
            creep.memory.recycle = true
            count++
        }

        if (count >= 3) {
            break;
        }
    }

    return OK
}

intermediate_carrier.prototype.alive = beginner_carrier.prototype.alive

// Make the intermediate carrier switch routes every time it is going of choose
intermediate_carrier.prototype.choose = beginner_carrier.prototype.choose
intermediate_carrier.prototype.withdraw_creep = beginner_carrier.prototype.withdraw_creep

module.exports = intermediate_carrier