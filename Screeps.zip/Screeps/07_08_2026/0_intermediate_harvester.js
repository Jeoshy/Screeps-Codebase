const {inheritCreep, basicCreep} = require("0_basic_creep")
const PHASES = require("0_PHASES")
const ROLES = require("0_ROLES")
const beginner_harvester = require("0_beginner_harvester")
const STRATEGIES = require("1_STRATEGIES")

/*
The intermediate harvester
- spawns in with either 2 WORK as body
- requests a transport request
- knows request is done when location condition is fulfilled
- starts harvesting after locatio condition
*/

function intermediate_harvester () {
    this.role = ROLES.INTERMEDIATE_HARVESTER
    this.body = [WORK, WORK, CARRY, CARRY]
    this.memory = {}
    this.strategy = STRATEGIES.INTERMEDIATE
    this.energy_needed = 300
    this.generates = 4
}

inheritCreep(intermediate_harvester)

intermediate_harvester.prototype.planned = beginner_harvester.prototype.planned

intermediate_harvester.prototype.spawn = function (room, strategy) {
    // Spawn direction
    this.directions = [LEFT]

    // Recycle some carriers from previous strategy
    let count = 0
    const creeps_alive = room.memory.alive
    for (const creep_name of creeps_alive) {
        const creep_planning = Memory.creeps_planning[creep_name]
        const creep = Game.creeps[creep_name]
        if (
            creep && 
            !creep.memory.recycle && 
            creep_planning.role == ROLES.BEGINNER_HARVESTER
        ) {
            creep.memory.recycle = true
            Memory.creep_planning[creep_name].pull_location = creep_planning.pull_location
            const rc = new room_command().from_room(creep.room)
            rc.add_pull_request(creep.room, this)
            creep.memory.pull_location = room.recycle_spots[0]
            count++
        }

        if (count >= 1) {
            break;
        }
    }

    return OK
}

intermediate_harvester.prototype.alive = beginner_harvester.prototype.alive

module.exports = intermediate_harvester